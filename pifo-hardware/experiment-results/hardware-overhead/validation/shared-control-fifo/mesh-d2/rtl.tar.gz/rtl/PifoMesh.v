// Generator : SpinalHDL v1.12.3    git head : 591e64062329e5e2e2b81f4d52422948053edb97
// Component : PifoMesh
// Git hash  : d5a10e8bacd8cdfbbd545d033e01f06a853312c6

`timescale 1ns/1ps

module PifoMesh (
  input  wire          io_dataRequest_valid,
  output wire          io_dataRequest_ready,
  input  wire [1:0]    io_dataRequest_payload_engineId,
  input  wire [2:0]    io_dataRequest_payload_vPifoId,
  output wire          io_pop_valid,
  input  wire          io_pop_ready,
  output wire [1:0]    io_pop_payload_engineId,
  output wire [2:0]    io_pop_payload_vPifoId,
  input  wire          io_insert_0_valid,
  output wire          io_insert_0_ready,
  input  wire [1:0]    io_insert_0_payload_engineId,
  input  wire [2:0]    io_insert_0_payload_vPifoId,
  input  wire          io_insert_1_valid,
  output wire          io_insert_1_ready,
  input  wire [1:0]    io_insert_1_payload_engineId,
  input  wire [2:0]    io_insert_1_payload_vPifoId,
  input  wire          io_controlRequest_valid,
  output wire          io_controlRequest_ready,
  input  wire [2:0]    io_controlRequest_payload_command,
  input  wire [1:0]    io_controlRequest_payload_engineId,
  input  wire [2:0]    io_controlRequest_payload_vPifoId,
  input  wire [4:0]    io_controlRequest_payload_flowId,
  input  wire [31:0]   io_controlRequest_payload_data,
  output wire          io_commitReady,
  output wire          io_pifo_0_push1_valid,
  output wire [7:0]    io_pifo_0_push1_payload_priority,
  output wire [4:0]    io_pifo_0_push1_payload_data,
  output wire [2:0]    io_pifo_0_push1_payload_port,
  output wire          io_pifo_0_push2_valid,
  output wire [7:0]    io_pifo_0_push2_payload_priority,
  output wire [4:0]    io_pifo_0_push2_payload_data,
  output wire [2:0]    io_pifo_0_push2_payload_port,
  output wire          io_pifo_0_popRequest_valid,
  output wire [2:0]    io_pifo_0_popRequest_payload_port,
  input  wire          io_pifo_0_popResponse_valid,
  input  wire          io_pifo_0_popResponse_payload_exist,
  input  wire [7:0]    io_pifo_0_popResponse_payload_priority,
  input  wire [4:0]    io_pifo_0_popResponse_payload_data,
  input  wire [2:0]    io_pifo_0_popResponse_payload_port,
  input  wire          io_pifo_0_popPortEmpty,
  input  wire          io_pifo_0_portDrained_valid,
  input  wire [2:0]    io_pifo_0_portDrained_payload,
  output wire          io_pifo_1_push1_valid,
  output wire [7:0]    io_pifo_1_push1_payload_priority,
  output wire [4:0]    io_pifo_1_push1_payload_data,
  output wire [2:0]    io_pifo_1_push1_payload_port,
  output wire          io_pifo_1_push2_valid,
  output wire [7:0]    io_pifo_1_push2_payload_priority,
  output wire [4:0]    io_pifo_1_push2_payload_data,
  output wire [2:0]    io_pifo_1_push2_payload_port,
  output wire          io_pifo_1_popRequest_valid,
  output wire [2:0]    io_pifo_1_popRequest_payload_port,
  input  wire          io_pifo_1_popResponse_valid,
  input  wire          io_pifo_1_popResponse_payload_exist,
  input  wire [7:0]    io_pifo_1_popResponse_payload_priority,
  input  wire [4:0]    io_pifo_1_popResponse_payload_data,
  input  wire [2:0]    io_pifo_1_popResponse_payload_port,
  input  wire          io_pifo_1_popPortEmpty,
  input  wire          io_pifo_1_portDrained_valid,
  input  wire [2:0]    io_pifo_1_portDrained_payload,
  output wire          io_replayBusy,
  output wire [1:0]    io_replayLogAvailable,
  input  wire          clk,
  input  wire          reset
);
  localparam ControlCommand_UpdateMapperPre = 3'd0;
  localparam ControlCommand_UpdateMapperPost = 3'd1;
  localparam ControlCommand_UpdateMapperNonExist = 3'd2;
  localparam ControlCommand_CommitMapper = 3'd3;
  localparam ControlCommand_UpdateBrainEngine = 3'd4;
  localparam ControlCommand_UpdateBrainState = 3'd5;
  localparam ControlCommand_UpdateBrainFlowState = 3'd6;

  reg                 replayControl_io_pop_ready;
  wire       [0:0]    streamDemux_4_io_select;
  wire                xbar_io_inputs_0_ready;
  wire                xbar_io_inputs_1_ready;
  wire                xbar_io_inputs_2_ready;
  wire                xbar_io_outputs_0_valid;
  wire       [1:0]    xbar_io_outputs_0_payload_engineId;
  wire       [2:0]    xbar_io_outputs_0_payload_vPifoId;
  wire                xbar_io_outputs_1_valid;
  wire       [1:0]    xbar_io_outputs_1_payload_engineId;
  wire       [2:0]    xbar_io_outputs_1_payload_vPifoId;
  wire                xbar_io_outputs_2_valid;
  wire       [1:0]    xbar_io_outputs_2_payload_engineId;
  wire       [2:0]    xbar_io_outputs_2_payload_vPifoId;
  wire                pifoEngines_0_io_enqueRequest_ready;
  wire                pifoEngines_0_io_dequeueRequest_ready;
  wire                pifoEngines_0_io_dequeueResponse_valid;
  wire       [1:0]    pifoEngines_0_io_dequeueResponse_payload_engineId;
  wire       [2:0]    pifoEngines_0_io_dequeueResponse_payload_vPifoId;
  wire                pifoEngines_0_io_control_ready;
  wire                pifoEngines_0_io_commitReady;
  wire                pifoEngines_0_io_pifo_push1_valid;
  wire       [7:0]    pifoEngines_0_io_pifo_push1_payload_priority;
  wire       [4:0]    pifoEngines_0_io_pifo_push1_payload_data;
  wire       [2:0]    pifoEngines_0_io_pifo_push1_payload_port;
  wire                pifoEngines_0_io_pifo_push2_valid;
  wire       [7:0]    pifoEngines_0_io_pifo_push2_payload_priority;
  wire       [4:0]    pifoEngines_0_io_pifo_push2_payload_data;
  wire       [2:0]    pifoEngines_0_io_pifo_push2_payload_port;
  wire                pifoEngines_0_io_pifo_popRequest_valid;
  wire       [2:0]    pifoEngines_0_io_pifo_popRequest_payload_port;
  wire                pifoEngines_1_io_enqueRequest_ready;
  wire                pifoEngines_1_io_dequeueRequest_ready;
  wire                pifoEngines_1_io_dequeueResponse_valid;
  wire       [1:0]    pifoEngines_1_io_dequeueResponse_payload_engineId;
  wire       [2:0]    pifoEngines_1_io_dequeueResponse_payload_vPifoId;
  wire                pifoEngines_1_io_control_ready;
  wire                pifoEngines_1_io_commitReady;
  wire                pifoEngines_1_io_pifo_push1_valid;
  wire       [7:0]    pifoEngines_1_io_pifo_push1_payload_priority;
  wire       [4:0]    pifoEngines_1_io_pifo_push1_payload_data;
  wire       [2:0]    pifoEngines_1_io_pifo_push1_payload_port;
  wire                pifoEngines_1_io_pifo_push2_valid;
  wire       [7:0]    pifoEngines_1_io_pifo_push2_payload_priority;
  wire       [4:0]    pifoEngines_1_io_pifo_push2_payload_data;
  wire       [2:0]    pifoEngines_1_io_pifo_push2_payload_port;
  wire                pifoEngines_1_io_pifo_popRequest_valid;
  wire       [2:0]    pifoEngines_1_io_pifo_popRequest_payload_port;
  wire                replayControl_io_push_ready;
  wire                replayControl_io_pop_valid;
  wire       [2:0]    replayControl_io_pop_payload_command;
  wire       [1:0]    replayControl_io_pop_payload_engineId;
  wire       [2:0]    replayControl_io_pop_payload_vPifoId;
  wire       [4:0]    replayControl_io_pop_payload_flowId;
  wire       [31:0]   replayControl_io_pop_payload_data;
  wire                replayControl_io_replaying;
  wire       [1:0]    replayControl_io_available;
  wire                streamDemux_4_io_input_ready;
  wire                streamDemux_4_io_outputs_0_valid;
  wire       [2:0]    streamDemux_4_io_outputs_0_payload_command;
  wire       [1:0]    streamDemux_4_io_outputs_0_payload_engineId;
  wire       [2:0]    streamDemux_4_io_outputs_0_payload_vPifoId;
  wire       [4:0]    streamDemux_4_io_outputs_0_payload_flowId;
  wire       [31:0]   streamDemux_4_io_outputs_0_payload_data;
  wire                streamDemux_4_io_outputs_1_valid;
  wire       [2:0]    streamDemux_4_io_outputs_1_payload_command;
  wire       [1:0]    streamDemux_4_io_outputs_1_payload_engineId;
  wire       [2:0]    streamDemux_4_io_outputs_1_payload_vPifoId;
  wire       [4:0]    streamDemux_4_io_outputs_1_payload_flowId;
  wire       [31:0]   streamDemux_4_io_outputs_1_payload_data;
  wire                io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_input_ready;
  wire                io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_valid;
  wire       [2:0]    io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_command;
  wire       [1:0]    io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_engineId;
  wire       [2:0]    io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_vPifoId;
  wire       [4:0]    io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_flowId;
  wire       [31:0]   io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_data;
  wire                io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_valid;
  wire       [2:0]    io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_command;
  wire       [1:0]    io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_engineId;
  wire       [2:0]    io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_vPifoId;
  wire       [4:0]    io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_flowId;
  wire       [31:0]   io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_data;
  wire                streamArbiter_9_io_inputs_0_ready;
  wire                streamArbiter_9_io_inputs_1_ready;
  wire                streamArbiter_9_io_output_valid;
  wire       [2:0]    streamArbiter_9_io_output_payload_command;
  wire       [1:0]    streamArbiter_9_io_output_payload_engineId;
  wire       [2:0]    streamArbiter_9_io_output_payload_vPifoId;
  wire       [4:0]    streamArbiter_9_io_output_payload_flowId;
  wire       [31:0]   streamArbiter_9_io_output_payload_data;
  wire       [0:0]    streamArbiter_9_io_chosen;
  wire       [1:0]    streamArbiter_9_io_chosenOH;
  wire                streamArbiter_10_io_inputs_0_ready;
  wire                streamArbiter_10_io_inputs_1_ready;
  wire                streamArbiter_10_io_output_valid;
  wire       [2:0]    streamArbiter_10_io_output_payload_command;
  wire       [1:0]    streamArbiter_10_io_output_payload_engineId;
  wire       [2:0]    streamArbiter_10_io_output_payload_vPifoId;
  wire       [4:0]    streamArbiter_10_io_output_payload_flowId;
  wire       [31:0]   streamArbiter_10_io_output_payload_data;
  wire       [0:0]    streamArbiter_10_io_chosen;
  wire       [1:0]    streamArbiter_10_io_chosenOH;
  wire       [1:0]    _zz_io_select;
  wire                _zz_io_commitReady;
  wire                io_pop_fork2_outputs_0_valid;
  reg                 io_pop_fork2_outputs_0_ready;
  wire       [2:0]    io_pop_fork2_outputs_0_payload_command;
  wire       [1:0]    io_pop_fork2_outputs_0_payload_engineId;
  wire       [2:0]    io_pop_fork2_outputs_0_payload_vPifoId;
  wire       [4:0]    io_pop_fork2_outputs_0_payload_flowId;
  wire       [31:0]   io_pop_fork2_outputs_0_payload_data;
  wire                io_pop_fork2_outputs_1_valid;
  reg                 io_pop_fork2_outputs_1_ready;
  wire       [2:0]    io_pop_fork2_outputs_1_payload_command;
  wire       [1:0]    io_pop_fork2_outputs_1_payload_engineId;
  wire       [2:0]    io_pop_fork2_outputs_1_payload_vPifoId;
  wire       [4:0]    io_pop_fork2_outputs_1_payload_flowId;
  wire       [31:0]   io_pop_fork2_outputs_1_payload_data;
  reg                 io_pop_fork2_logic_linkEnable_0;
  reg                 io_pop_fork2_logic_linkEnable_1;
  wire                when_Stream_l1253;
  wire                when_Stream_l1253_1;
  wire                io_pop_fork2_outputs_0_fire;
  wire                io_pop_fork2_outputs_1_fire;
  wire                when_Stream_l581;
  reg                 io_pop_fork2_outputs_0_throwWhen_valid;
  wire                io_pop_fork2_outputs_0_throwWhen_ready;
  wire       [2:0]    io_pop_fork2_outputs_0_throwWhen_payload_command;
  wire       [1:0]    io_pop_fork2_outputs_0_throwWhen_payload_engineId;
  wire       [2:0]    io_pop_fork2_outputs_0_throwWhen_payload_vPifoId;
  wire       [4:0]    io_pop_fork2_outputs_0_throwWhen_payload_flowId;
  wire       [31:0]   io_pop_fork2_outputs_0_throwWhen_payload_data;
  wire                when_Stream_l581_1;
  reg                 io_pop_fork2_outputs_1_takeWhen_valid;
  wire                io_pop_fork2_outputs_1_takeWhen_ready;
  wire       [2:0]    io_pop_fork2_outputs_1_takeWhen_payload_command;
  wire       [1:0]    io_pop_fork2_outputs_1_takeWhen_payload_engineId;
  wire       [2:0]    io_pop_fork2_outputs_1_takeWhen_payload_vPifoId;
  wire       [4:0]    io_pop_fork2_outputs_1_takeWhen_payload_flowId;
  wire       [31:0]   io_pop_fork2_outputs_1_takeWhen_payload_data;
  wire                _zz_io_pop_fork2_outputs_1_takeWhen_ready;
  wire                io_pop_fork2_outputs_1_takeWhen_haltWhen_valid;
  wire                io_pop_fork2_outputs_1_takeWhen_haltWhen_ready;
  wire       [2:0]    io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_command;
  wire       [1:0]    io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_engineId;
  wire       [2:0]    io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_vPifoId;
  wire       [4:0]    io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_flowId;
  wire       [31:0]   io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_data;
  wire                io_output_combStage_valid;
  wire                io_output_combStage_ready;
  wire       [2:0]    io_output_combStage_payload_command;
  wire       [1:0]    io_output_combStage_payload_engineId;
  wire       [2:0]    io_output_combStage_payload_vPifoId;
  wire       [4:0]    io_output_combStage_payload_flowId;
  wire       [31:0]   io_output_combStage_payload_data;
  wire                io_output_combStage_valid_1;
  wire                io_output_combStage_ready_1;
  wire       [2:0]    io_output_combStage_payload_command_1;
  wire       [1:0]    io_output_combStage_payload_engineId_1;
  wire       [2:0]    io_output_combStage_payload_vPifoId_1;
  wire       [4:0]    io_output_combStage_payload_flowId_1;
  wire       [31:0]   io_output_combStage_payload_data_1;
  `ifndef SYNTHESIS
  reg [159:0] io_controlRequest_payload_command_string;
  reg [159:0] io_pop_fork2_outputs_0_payload_command_string;
  reg [159:0] io_pop_fork2_outputs_1_payload_command_string;
  reg [159:0] io_pop_fork2_outputs_0_throwWhen_payload_command_string;
  reg [159:0] io_pop_fork2_outputs_1_takeWhen_payload_command_string;
  reg [159:0] io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_command_string;
  reg [159:0] io_output_combStage_payload_command_string;
  reg [159:0] io_output_combStage_payload_command_1_string;
  `endif


  assign _zz_io_select = (io_pop_fork2_outputs_0_throwWhen_payload_engineId - 2'b01);
  MessageCrossBar xbar (
    .io_inputs_0_valid             (io_dataRequest_valid                                  ), //i
    .io_inputs_0_ready             (xbar_io_inputs_0_ready                                ), //o
    .io_inputs_0_payload_engineId  (io_dataRequest_payload_engineId[1:0]                  ), //i
    .io_inputs_0_payload_vPifoId   (io_dataRequest_payload_vPifoId[2:0]                   ), //i
    .io_inputs_1_valid             (pifoEngines_0_io_dequeueResponse_valid                ), //i
    .io_inputs_1_ready             (xbar_io_inputs_1_ready                                ), //o
    .io_inputs_1_payload_engineId  (pifoEngines_0_io_dequeueResponse_payload_engineId[1:0]), //i
    .io_inputs_1_payload_vPifoId   (pifoEngines_0_io_dequeueResponse_payload_vPifoId[2:0] ), //i
    .io_inputs_2_valid             (pifoEngines_1_io_dequeueResponse_valid                ), //i
    .io_inputs_2_ready             (xbar_io_inputs_2_ready                                ), //o
    .io_inputs_2_payload_engineId  (pifoEngines_1_io_dequeueResponse_payload_engineId[1:0]), //i
    .io_inputs_2_payload_vPifoId   (pifoEngines_1_io_dequeueResponse_payload_vPifoId[2:0] ), //i
    .io_outputs_0_valid            (xbar_io_outputs_0_valid                               ), //o
    .io_outputs_0_ready            (io_pop_ready                                          ), //i
    .io_outputs_0_payload_engineId (xbar_io_outputs_0_payload_engineId[1:0]               ), //o
    .io_outputs_0_payload_vPifoId  (xbar_io_outputs_0_payload_vPifoId[2:0]                ), //o
    .io_outputs_1_valid            (xbar_io_outputs_1_valid                               ), //o
    .io_outputs_1_ready            (pifoEngines_0_io_dequeueRequest_ready                 ), //i
    .io_outputs_1_payload_engineId (xbar_io_outputs_1_payload_engineId[1:0]               ), //o
    .io_outputs_1_payload_vPifoId  (xbar_io_outputs_1_payload_vPifoId[2:0]                ), //o
    .io_outputs_2_valid            (xbar_io_outputs_2_valid                               ), //o
    .io_outputs_2_ready            (pifoEngines_1_io_dequeueRequest_ready                 ), //i
    .io_outputs_2_payload_engineId (xbar_io_outputs_2_payload_engineId[1:0]               ), //o
    .io_outputs_2_payload_vPifoId  (xbar_io_outputs_2_payload_vPifoId[2:0]                ), //o
    .clk                           (clk                                                   ), //i
    .reset                         (reset                                                 )  //i
  );
  PifoEngine pifoEngines_0 (
    .io_enqueRequest_valid                (io_insert_0_valid                                     ), //i
    .io_enqueRequest_ready                (pifoEngines_0_io_enqueRequest_ready                   ), //o
    .io_enqueRequest_payload_engineId     (io_insert_0_payload_engineId[1:0]                     ), //i
    .io_enqueRequest_payload_vPifoId      (io_insert_0_payload_vPifoId[2:0]                      ), //i
    .io_dequeueRequest_valid              (xbar_io_outputs_1_valid                               ), //i
    .io_dequeueRequest_ready              (pifoEngines_0_io_dequeueRequest_ready                 ), //o
    .io_dequeueRequest_payload_engineId   (xbar_io_outputs_1_payload_engineId[1:0]               ), //i
    .io_dequeueRequest_payload_vPifoId    (xbar_io_outputs_1_payload_vPifoId[2:0]                ), //i
    .io_dequeueResponse_valid             (pifoEngines_0_io_dequeueResponse_valid                ), //o
    .io_dequeueResponse_ready             (xbar_io_inputs_1_ready                                ), //i
    .io_dequeueResponse_payload_engineId  (pifoEngines_0_io_dequeueResponse_payload_engineId[1:0]), //o
    .io_dequeueResponse_payload_vPifoId   (pifoEngines_0_io_dequeueResponse_payload_vPifoId[2:0] ), //o
    .io_control_valid                     (io_output_combStage_valid                             ), //i
    .io_control_ready                     (pifoEngines_0_io_control_ready                        ), //o
    .io_control_payload_command           (io_output_combStage_payload_command[2:0]              ), //i
    .io_control_payload_engineId          (io_output_combStage_payload_engineId[1:0]             ), //i
    .io_control_payload_vPifoId           (io_output_combStage_payload_vPifoId[2:0]              ), //i
    .io_control_payload_flowId            (io_output_combStage_payload_flowId[4:0]               ), //i
    .io_control_payload_data              (io_output_combStage_payload_data[31:0]                ), //i
    .io_commitReady                       (pifoEngines_0_io_commitReady                          ), //o
    .io_pifo_push1_valid                  (pifoEngines_0_io_pifo_push1_valid                     ), //o
    .io_pifo_push1_payload_priority       (pifoEngines_0_io_pifo_push1_payload_priority[7:0]     ), //o
    .io_pifo_push1_payload_data           (pifoEngines_0_io_pifo_push1_payload_data[4:0]         ), //o
    .io_pifo_push1_payload_port           (pifoEngines_0_io_pifo_push1_payload_port[2:0]         ), //o
    .io_pifo_push2_valid                  (pifoEngines_0_io_pifo_push2_valid                     ), //o
    .io_pifo_push2_payload_priority       (pifoEngines_0_io_pifo_push2_payload_priority[7:0]     ), //o
    .io_pifo_push2_payload_data           (pifoEngines_0_io_pifo_push2_payload_data[4:0]         ), //o
    .io_pifo_push2_payload_port           (pifoEngines_0_io_pifo_push2_payload_port[2:0]         ), //o
    .io_pifo_popRequest_valid             (pifoEngines_0_io_pifo_popRequest_valid                ), //o
    .io_pifo_popRequest_payload_port      (pifoEngines_0_io_pifo_popRequest_payload_port[2:0]    ), //o
    .io_pifo_popResponse_valid            (io_pifo_0_popResponse_valid                           ), //i
    .io_pifo_popResponse_payload_exist    (io_pifo_0_popResponse_payload_exist                   ), //i
    .io_pifo_popResponse_payload_priority (io_pifo_0_popResponse_payload_priority[7:0]           ), //i
    .io_pifo_popResponse_payload_data     (io_pifo_0_popResponse_payload_data[4:0]               ), //i
    .io_pifo_popResponse_payload_port     (io_pifo_0_popResponse_payload_port[2:0]               ), //i
    .io_pifo_popPortEmpty                 (io_pifo_0_popPortEmpty                                ), //i
    .io_pifo_portDrained_valid            (io_pifo_0_portDrained_valid                           ), //i
    .io_pifo_portDrained_payload          (io_pifo_0_portDrained_payload[2:0]                    ), //i
    .clk                                  (clk                                                   ), //i
    .reset                                (reset                                                 )  //i
  );
  PifoEngine_1 pifoEngines_1 (
    .io_enqueRequest_valid                (io_insert_1_valid                                     ), //i
    .io_enqueRequest_ready                (pifoEngines_1_io_enqueRequest_ready                   ), //o
    .io_enqueRequest_payload_engineId     (io_insert_1_payload_engineId[1:0]                     ), //i
    .io_enqueRequest_payload_vPifoId      (io_insert_1_payload_vPifoId[2:0]                      ), //i
    .io_dequeueRequest_valid              (xbar_io_outputs_2_valid                               ), //i
    .io_dequeueRequest_ready              (pifoEngines_1_io_dequeueRequest_ready                 ), //o
    .io_dequeueRequest_payload_engineId   (xbar_io_outputs_2_payload_engineId[1:0]               ), //i
    .io_dequeueRequest_payload_vPifoId    (xbar_io_outputs_2_payload_vPifoId[2:0]                ), //i
    .io_dequeueResponse_valid             (pifoEngines_1_io_dequeueResponse_valid                ), //o
    .io_dequeueResponse_ready             (xbar_io_inputs_2_ready                                ), //i
    .io_dequeueResponse_payload_engineId  (pifoEngines_1_io_dequeueResponse_payload_engineId[1:0]), //o
    .io_dequeueResponse_payload_vPifoId   (pifoEngines_1_io_dequeueResponse_payload_vPifoId[2:0] ), //o
    .io_control_valid                     (io_output_combStage_valid_1                           ), //i
    .io_control_ready                     (pifoEngines_1_io_control_ready                        ), //o
    .io_control_payload_command           (io_output_combStage_payload_command_1[2:0]            ), //i
    .io_control_payload_engineId          (io_output_combStage_payload_engineId_1[1:0]           ), //i
    .io_control_payload_vPifoId           (io_output_combStage_payload_vPifoId_1[2:0]            ), //i
    .io_control_payload_flowId            (io_output_combStage_payload_flowId_1[4:0]             ), //i
    .io_control_payload_data              (io_output_combStage_payload_data_1[31:0]              ), //i
    .io_commitReady                       (pifoEngines_1_io_commitReady                          ), //o
    .io_pifo_push1_valid                  (pifoEngines_1_io_pifo_push1_valid                     ), //o
    .io_pifo_push1_payload_priority       (pifoEngines_1_io_pifo_push1_payload_priority[7:0]     ), //o
    .io_pifo_push1_payload_data           (pifoEngines_1_io_pifo_push1_payload_data[4:0]         ), //o
    .io_pifo_push1_payload_port           (pifoEngines_1_io_pifo_push1_payload_port[2:0]         ), //o
    .io_pifo_push2_valid                  (pifoEngines_1_io_pifo_push2_valid                     ), //o
    .io_pifo_push2_payload_priority       (pifoEngines_1_io_pifo_push2_payload_priority[7:0]     ), //o
    .io_pifo_push2_payload_data           (pifoEngines_1_io_pifo_push2_payload_data[4:0]         ), //o
    .io_pifo_push2_payload_port           (pifoEngines_1_io_pifo_push2_payload_port[2:0]         ), //o
    .io_pifo_popRequest_valid             (pifoEngines_1_io_pifo_popRequest_valid                ), //o
    .io_pifo_popRequest_payload_port      (pifoEngines_1_io_pifo_popRequest_payload_port[2:0]    ), //o
    .io_pifo_popResponse_valid            (io_pifo_1_popResponse_valid                           ), //i
    .io_pifo_popResponse_payload_exist    (io_pifo_1_popResponse_payload_exist                   ), //i
    .io_pifo_popResponse_payload_priority (io_pifo_1_popResponse_payload_priority[7:0]           ), //i
    .io_pifo_popResponse_payload_data     (io_pifo_1_popResponse_payload_data[4:0]               ), //i
    .io_pifo_popResponse_payload_port     (io_pifo_1_popResponse_payload_port[2:0]               ), //i
    .io_pifo_popPortEmpty                 (io_pifo_1_popPortEmpty                                ), //i
    .io_pifo_portDrained_valid            (io_pifo_1_portDrained_valid                           ), //i
    .io_pifo_portDrained_payload          (io_pifo_1_portDrained_payload[2:0]                    ), //i
    .clk                                  (clk                                                   ), //i
    .reset                                (reset                                                 )  //i
  );
  ReplayControlFifo replayControl (
    .io_push_valid            (io_controlRequest_valid                   ), //i
    .io_push_ready            (replayControl_io_push_ready               ), //o
    .io_push_payload_command  (io_controlRequest_payload_command[2:0]    ), //i
    .io_push_payload_engineId (io_controlRequest_payload_engineId[1:0]   ), //i
    .io_push_payload_vPifoId  (io_controlRequest_payload_vPifoId[2:0]    ), //i
    .io_push_payload_flowId   (io_controlRequest_payload_flowId[4:0]     ), //i
    .io_push_payload_data     (io_controlRequest_payload_data[31:0]      ), //i
    .io_pop_valid             (replayControl_io_pop_valid                ), //o
    .io_pop_ready             (replayControl_io_pop_ready                ), //i
    .io_pop_payload_command   (replayControl_io_pop_payload_command[2:0] ), //o
    .io_pop_payload_engineId  (replayControl_io_pop_payload_engineId[1:0]), //o
    .io_pop_payload_vPifoId   (replayControl_io_pop_payload_vPifoId[2:0] ), //o
    .io_pop_payload_flowId    (replayControl_io_pop_payload_flowId[4:0]  ), //o
    .io_pop_payload_data      (replayControl_io_pop_payload_data[31:0]   ), //o
    .io_replaying             (replayControl_io_replaying                ), //o
    .io_available             (replayControl_io_available[1:0]           ), //o
    .clk                      (clk                                       ), //i
    .reset                    (reset                                     )  //i
  );
  StreamDemux_3 streamDemux_4 (
    .io_select                     (streamDemux_4_io_select                               ), //i
    .io_input_valid                (io_pop_fork2_outputs_0_throwWhen_valid                ), //i
    .io_input_ready                (streamDemux_4_io_input_ready                          ), //o
    .io_input_payload_command      (io_pop_fork2_outputs_0_throwWhen_payload_command[2:0] ), //i
    .io_input_payload_engineId     (io_pop_fork2_outputs_0_throwWhen_payload_engineId[1:0]), //i
    .io_input_payload_vPifoId      (io_pop_fork2_outputs_0_throwWhen_payload_vPifoId[2:0] ), //i
    .io_input_payload_flowId       (io_pop_fork2_outputs_0_throwWhen_payload_flowId[4:0]  ), //i
    .io_input_payload_data         (io_pop_fork2_outputs_0_throwWhen_payload_data[31:0]   ), //i
    .io_outputs_0_valid            (streamDemux_4_io_outputs_0_valid                      ), //o
    .io_outputs_0_ready            (streamArbiter_9_io_inputs_0_ready                     ), //i
    .io_outputs_0_payload_command  (streamDemux_4_io_outputs_0_payload_command[2:0]       ), //o
    .io_outputs_0_payload_engineId (streamDemux_4_io_outputs_0_payload_engineId[1:0]      ), //o
    .io_outputs_0_payload_vPifoId  (streamDemux_4_io_outputs_0_payload_vPifoId[2:0]       ), //o
    .io_outputs_0_payload_flowId   (streamDemux_4_io_outputs_0_payload_flowId[4:0]        ), //o
    .io_outputs_0_payload_data     (streamDemux_4_io_outputs_0_payload_data[31:0]         ), //o
    .io_outputs_1_valid            (streamDemux_4_io_outputs_1_valid                      ), //o
    .io_outputs_1_ready            (streamArbiter_10_io_inputs_0_ready                    ), //i
    .io_outputs_1_payload_command  (streamDemux_4_io_outputs_1_payload_command[2:0]       ), //o
    .io_outputs_1_payload_engineId (streamDemux_4_io_outputs_1_payload_engineId[1:0]      ), //o
    .io_outputs_1_payload_vPifoId  (streamDemux_4_io_outputs_1_payload_vPifoId[2:0]       ), //o
    .io_outputs_1_payload_flowId   (streamDemux_4_io_outputs_1_payload_flowId[4:0]        ), //o
    .io_outputs_1_payload_data     (streamDemux_4_io_outputs_1_payload_data[31:0]         )  //o
  );
  StreamFork_8 io_pop_fork2_outputs_1_takeWhen_haltWhen_fork (
    .io_input_valid                (io_pop_fork2_outputs_1_takeWhen_haltWhen_valid                                  ), //i
    .io_input_ready                (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_input_ready                    ), //o
    .io_input_payload_command      (io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_command[2:0]                   ), //i
    .io_input_payload_engineId     (io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_engineId[1:0]                  ), //i
    .io_input_payload_vPifoId      (io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_vPifoId[2:0]                   ), //i
    .io_input_payload_flowId       (io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_flowId[4:0]                    ), //i
    .io_input_payload_data         (io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_data[31:0]                     ), //i
    .io_outputs_0_valid            (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_valid                ), //o
    .io_outputs_0_ready            (streamArbiter_9_io_inputs_1_ready                                               ), //i
    .io_outputs_0_payload_command  (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_command[2:0] ), //o
    .io_outputs_0_payload_engineId (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_engineId[1:0]), //o
    .io_outputs_0_payload_vPifoId  (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_vPifoId[2:0] ), //o
    .io_outputs_0_payload_flowId   (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_flowId[4:0]  ), //o
    .io_outputs_0_payload_data     (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_data[31:0]   ), //o
    .io_outputs_1_valid            (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_valid                ), //o
    .io_outputs_1_ready            (streamArbiter_10_io_inputs_1_ready                                              ), //i
    .io_outputs_1_payload_command  (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_command[2:0] ), //o
    .io_outputs_1_payload_engineId (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_engineId[1:0]), //o
    .io_outputs_1_payload_vPifoId  (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_vPifoId[2:0] ), //o
    .io_outputs_1_payload_flowId   (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_flowId[4:0]  ), //o
    .io_outputs_1_payload_data     (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_data[31:0]   ), //o
    .clk                           (clk                                                                             ), //i
    .reset                         (reset                                                                           )  //i
  );
  StreamArbiter_7 streamArbiter_9 (
    .io_inputs_0_valid            (streamDemux_4_io_outputs_0_valid                                                ), //i
    .io_inputs_0_ready            (streamArbiter_9_io_inputs_0_ready                                               ), //o
    .io_inputs_0_payload_command  (streamDemux_4_io_outputs_0_payload_command[2:0]                                 ), //i
    .io_inputs_0_payload_engineId (streamDemux_4_io_outputs_0_payload_engineId[1:0]                                ), //i
    .io_inputs_0_payload_vPifoId  (streamDemux_4_io_outputs_0_payload_vPifoId[2:0]                                 ), //i
    .io_inputs_0_payload_flowId   (streamDemux_4_io_outputs_0_payload_flowId[4:0]                                  ), //i
    .io_inputs_0_payload_data     (streamDemux_4_io_outputs_0_payload_data[31:0]                                   ), //i
    .io_inputs_1_valid            (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_valid                ), //i
    .io_inputs_1_ready            (streamArbiter_9_io_inputs_1_ready                                               ), //o
    .io_inputs_1_payload_command  (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_command[2:0] ), //i
    .io_inputs_1_payload_engineId (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_engineId[1:0]), //i
    .io_inputs_1_payload_vPifoId  (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_vPifoId[2:0] ), //i
    .io_inputs_1_payload_flowId   (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_flowId[4:0]  ), //i
    .io_inputs_1_payload_data     (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_0_payload_data[31:0]   ), //i
    .io_output_valid              (streamArbiter_9_io_output_valid                                                 ), //o
    .io_output_ready              (io_output_combStage_ready                                                       ), //i
    .io_output_payload_command    (streamArbiter_9_io_output_payload_command[2:0]                                  ), //o
    .io_output_payload_engineId   (streamArbiter_9_io_output_payload_engineId[1:0]                                 ), //o
    .io_output_payload_vPifoId    (streamArbiter_9_io_output_payload_vPifoId[2:0]                                  ), //o
    .io_output_payload_flowId     (streamArbiter_9_io_output_payload_flowId[4:0]                                   ), //o
    .io_output_payload_data       (streamArbiter_9_io_output_payload_data[31:0]                                    ), //o
    .io_chosen                    (streamArbiter_9_io_chosen                                                       ), //o
    .io_chosenOH                  (streamArbiter_9_io_chosenOH[1:0]                                                ), //o
    .clk                          (clk                                                                             ), //i
    .reset                        (reset                                                                           )  //i
  );
  StreamArbiter_7 streamArbiter_10 (
    .io_inputs_0_valid            (streamDemux_4_io_outputs_1_valid                                                ), //i
    .io_inputs_0_ready            (streamArbiter_10_io_inputs_0_ready                                              ), //o
    .io_inputs_0_payload_command  (streamDemux_4_io_outputs_1_payload_command[2:0]                                 ), //i
    .io_inputs_0_payload_engineId (streamDemux_4_io_outputs_1_payload_engineId[1:0]                                ), //i
    .io_inputs_0_payload_vPifoId  (streamDemux_4_io_outputs_1_payload_vPifoId[2:0]                                 ), //i
    .io_inputs_0_payload_flowId   (streamDemux_4_io_outputs_1_payload_flowId[4:0]                                  ), //i
    .io_inputs_0_payload_data     (streamDemux_4_io_outputs_1_payload_data[31:0]                                   ), //i
    .io_inputs_1_valid            (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_valid                ), //i
    .io_inputs_1_ready            (streamArbiter_10_io_inputs_1_ready                                              ), //o
    .io_inputs_1_payload_command  (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_command[2:0] ), //i
    .io_inputs_1_payload_engineId (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_engineId[1:0]), //i
    .io_inputs_1_payload_vPifoId  (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_vPifoId[2:0] ), //i
    .io_inputs_1_payload_flowId   (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_flowId[4:0]  ), //i
    .io_inputs_1_payload_data     (io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_outputs_1_payload_data[31:0]   ), //i
    .io_output_valid              (streamArbiter_10_io_output_valid                                                ), //o
    .io_output_ready              (io_output_combStage_ready_1                                                     ), //i
    .io_output_payload_command    (streamArbiter_10_io_output_payload_command[2:0]                                 ), //o
    .io_output_payload_engineId   (streamArbiter_10_io_output_payload_engineId[1:0]                                ), //o
    .io_output_payload_vPifoId    (streamArbiter_10_io_output_payload_vPifoId[2:0]                                 ), //o
    .io_output_payload_flowId     (streamArbiter_10_io_output_payload_flowId[4:0]                                  ), //o
    .io_output_payload_data       (streamArbiter_10_io_output_payload_data[31:0]                                   ), //o
    .io_chosen                    (streamArbiter_10_io_chosen                                                      ), //o
    .io_chosenOH                  (streamArbiter_10_io_chosenOH[1:0]                                               ), //o
    .clk                          (clk                                                                             ), //i
    .reset                        (reset                                                                           )  //i
  );
  `ifndef SYNTHESIS
  always @(*) begin
    case(io_controlRequest_payload_command)
      ControlCommand_UpdateMapperPre : io_controlRequest_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_controlRequest_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_controlRequest_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_controlRequest_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_controlRequest_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_controlRequest_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_controlRequest_payload_command_string = "UpdateBrainFlowState";
      default : io_controlRequest_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_pop_fork2_outputs_0_payload_command)
      ControlCommand_UpdateMapperPre : io_pop_fork2_outputs_0_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_pop_fork2_outputs_0_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_pop_fork2_outputs_0_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_pop_fork2_outputs_0_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_pop_fork2_outputs_0_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_pop_fork2_outputs_0_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_pop_fork2_outputs_0_payload_command_string = "UpdateBrainFlowState";
      default : io_pop_fork2_outputs_0_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_pop_fork2_outputs_1_payload_command)
      ControlCommand_UpdateMapperPre : io_pop_fork2_outputs_1_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_pop_fork2_outputs_1_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_pop_fork2_outputs_1_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_pop_fork2_outputs_1_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_pop_fork2_outputs_1_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_pop_fork2_outputs_1_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_pop_fork2_outputs_1_payload_command_string = "UpdateBrainFlowState";
      default : io_pop_fork2_outputs_1_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_pop_fork2_outputs_0_throwWhen_payload_command)
      ControlCommand_UpdateMapperPre : io_pop_fork2_outputs_0_throwWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_pop_fork2_outputs_0_throwWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_pop_fork2_outputs_0_throwWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_pop_fork2_outputs_0_throwWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_pop_fork2_outputs_0_throwWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_pop_fork2_outputs_0_throwWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_pop_fork2_outputs_0_throwWhen_payload_command_string = "UpdateBrainFlowState";
      default : io_pop_fork2_outputs_0_throwWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_pop_fork2_outputs_1_takeWhen_payload_command)
      ControlCommand_UpdateMapperPre : io_pop_fork2_outputs_1_takeWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_pop_fork2_outputs_1_takeWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_pop_fork2_outputs_1_takeWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_pop_fork2_outputs_1_takeWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_pop_fork2_outputs_1_takeWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_pop_fork2_outputs_1_takeWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_pop_fork2_outputs_1_takeWhen_payload_command_string = "UpdateBrainFlowState";
      default : io_pop_fork2_outputs_1_takeWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_command)
      ControlCommand_UpdateMapperPre : io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_command_string = "UpdateBrainFlowState";
      default : io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_output_combStage_payload_command)
      ControlCommand_UpdateMapperPre : io_output_combStage_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_output_combStage_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_output_combStage_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_output_combStage_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_output_combStage_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_output_combStage_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_output_combStage_payload_command_string = "UpdateBrainFlowState";
      default : io_output_combStage_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_output_combStage_payload_command_1)
      ControlCommand_UpdateMapperPre : io_output_combStage_payload_command_1_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_output_combStage_payload_command_1_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_output_combStage_payload_command_1_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_output_combStage_payload_command_1_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_output_combStage_payload_command_1_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_output_combStage_payload_command_1_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_output_combStage_payload_command_1_string = "UpdateBrainFlowState";
      default : io_output_combStage_payload_command_1_string = "????????????????????";
    endcase
  end
  `endif

  assign io_pifo_0_push1_valid = pifoEngines_0_io_pifo_push1_valid;
  assign io_pifo_0_push1_payload_priority = pifoEngines_0_io_pifo_push1_payload_priority;
  assign io_pifo_0_push1_payload_data = pifoEngines_0_io_pifo_push1_payload_data;
  assign io_pifo_0_push1_payload_port = pifoEngines_0_io_pifo_push1_payload_port;
  assign io_pifo_0_push2_valid = pifoEngines_0_io_pifo_push2_valid;
  assign io_pifo_0_push2_payload_priority = pifoEngines_0_io_pifo_push2_payload_priority;
  assign io_pifo_0_push2_payload_data = pifoEngines_0_io_pifo_push2_payload_data;
  assign io_pifo_0_push2_payload_port = pifoEngines_0_io_pifo_push2_payload_port;
  assign io_pifo_0_popRequest_valid = pifoEngines_0_io_pifo_popRequest_valid;
  assign io_pifo_0_popRequest_payload_port = pifoEngines_0_io_pifo_popRequest_payload_port;
  assign io_pifo_1_push1_valid = pifoEngines_1_io_pifo_push1_valid;
  assign io_pifo_1_push1_payload_priority = pifoEngines_1_io_pifo_push1_payload_priority;
  assign io_pifo_1_push1_payload_data = pifoEngines_1_io_pifo_push1_payload_data;
  assign io_pifo_1_push1_payload_port = pifoEngines_1_io_pifo_push1_payload_port;
  assign io_pifo_1_push2_valid = pifoEngines_1_io_pifo_push2_valid;
  assign io_pifo_1_push2_payload_priority = pifoEngines_1_io_pifo_push2_payload_priority;
  assign io_pifo_1_push2_payload_data = pifoEngines_1_io_pifo_push2_payload_data;
  assign io_pifo_1_push2_payload_port = pifoEngines_1_io_pifo_push2_payload_port;
  assign io_pifo_1_popRequest_valid = pifoEngines_1_io_pifo_popRequest_valid;
  assign io_pifo_1_popRequest_payload_port = pifoEngines_1_io_pifo_popRequest_payload_port;
  assign io_dataRequest_ready = xbar_io_inputs_0_ready;
  assign io_pop_valid = xbar_io_outputs_0_valid;
  assign io_pop_payload_engineId = xbar_io_outputs_0_payload_engineId;
  assign io_pop_payload_vPifoId = xbar_io_outputs_0_payload_vPifoId;
  assign io_insert_0_ready = pifoEngines_0_io_enqueRequest_ready;
  assign io_insert_1_ready = pifoEngines_1_io_enqueRequest_ready;
  assign io_controlRequest_ready = replayControl_io_push_ready;
  assign io_replayBusy = replayControl_io_replaying;
  assign io_replayLogAvailable = replayControl_io_available;
  assign _zz_io_commitReady = (pifoEngines_0_io_commitReady && pifoEngines_1_io_commitReady);
  assign io_commitReady = ((! replayControl_io_replaying) && _zz_io_commitReady);
  always @(*) begin
    replayControl_io_pop_ready = 1'b1;
    if(when_Stream_l1253) begin
      replayControl_io_pop_ready = 1'b0;
    end
    if(when_Stream_l1253_1) begin
      replayControl_io_pop_ready = 1'b0;
    end
  end

  assign when_Stream_l1253 = ((! io_pop_fork2_outputs_0_ready) && io_pop_fork2_logic_linkEnable_0);
  assign when_Stream_l1253_1 = ((! io_pop_fork2_outputs_1_ready) && io_pop_fork2_logic_linkEnable_1);
  assign io_pop_fork2_outputs_0_valid = (replayControl_io_pop_valid && io_pop_fork2_logic_linkEnable_0);
  assign io_pop_fork2_outputs_0_payload_command = replayControl_io_pop_payload_command;
  assign io_pop_fork2_outputs_0_payload_engineId = replayControl_io_pop_payload_engineId;
  assign io_pop_fork2_outputs_0_payload_vPifoId = replayControl_io_pop_payload_vPifoId;
  assign io_pop_fork2_outputs_0_payload_flowId = replayControl_io_pop_payload_flowId;
  assign io_pop_fork2_outputs_0_payload_data = replayControl_io_pop_payload_data;
  assign io_pop_fork2_outputs_0_fire = (io_pop_fork2_outputs_0_valid && io_pop_fork2_outputs_0_ready);
  assign io_pop_fork2_outputs_1_valid = (replayControl_io_pop_valid && io_pop_fork2_logic_linkEnable_1);
  assign io_pop_fork2_outputs_1_payload_command = replayControl_io_pop_payload_command;
  assign io_pop_fork2_outputs_1_payload_engineId = replayControl_io_pop_payload_engineId;
  assign io_pop_fork2_outputs_1_payload_vPifoId = replayControl_io_pop_payload_vPifoId;
  assign io_pop_fork2_outputs_1_payload_flowId = replayControl_io_pop_payload_flowId;
  assign io_pop_fork2_outputs_1_payload_data = replayControl_io_pop_payload_data;
  assign io_pop_fork2_outputs_1_fire = (io_pop_fork2_outputs_1_valid && io_pop_fork2_outputs_1_ready);
  assign when_Stream_l581 = (io_pop_fork2_outputs_0_payload_command == ControlCommand_CommitMapper);
  always @(*) begin
    io_pop_fork2_outputs_0_throwWhen_valid = io_pop_fork2_outputs_0_valid;
    if(when_Stream_l581) begin
      io_pop_fork2_outputs_0_throwWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    io_pop_fork2_outputs_0_ready = io_pop_fork2_outputs_0_throwWhen_ready;
    if(when_Stream_l581) begin
      io_pop_fork2_outputs_0_ready = 1'b1;
    end
  end

  assign io_pop_fork2_outputs_0_throwWhen_payload_command = io_pop_fork2_outputs_0_payload_command;
  assign io_pop_fork2_outputs_0_throwWhen_payload_engineId = io_pop_fork2_outputs_0_payload_engineId;
  assign io_pop_fork2_outputs_0_throwWhen_payload_vPifoId = io_pop_fork2_outputs_0_payload_vPifoId;
  assign io_pop_fork2_outputs_0_throwWhen_payload_flowId = io_pop_fork2_outputs_0_payload_flowId;
  assign io_pop_fork2_outputs_0_throwWhen_payload_data = io_pop_fork2_outputs_0_payload_data;
  assign when_Stream_l581_1 = (! (io_pop_fork2_outputs_1_payload_command == ControlCommand_CommitMapper));
  always @(*) begin
    io_pop_fork2_outputs_1_takeWhen_valid = io_pop_fork2_outputs_1_valid;
    if(when_Stream_l581_1) begin
      io_pop_fork2_outputs_1_takeWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    io_pop_fork2_outputs_1_ready = io_pop_fork2_outputs_1_takeWhen_ready;
    if(when_Stream_l581_1) begin
      io_pop_fork2_outputs_1_ready = 1'b1;
    end
  end

  assign io_pop_fork2_outputs_1_takeWhen_payload_command = io_pop_fork2_outputs_1_payload_command;
  assign io_pop_fork2_outputs_1_takeWhen_payload_engineId = io_pop_fork2_outputs_1_payload_engineId;
  assign io_pop_fork2_outputs_1_takeWhen_payload_vPifoId = io_pop_fork2_outputs_1_payload_vPifoId;
  assign io_pop_fork2_outputs_1_takeWhen_payload_flowId = io_pop_fork2_outputs_1_payload_flowId;
  assign io_pop_fork2_outputs_1_takeWhen_payload_data = io_pop_fork2_outputs_1_payload_data;
  assign _zz_io_pop_fork2_outputs_1_takeWhen_ready = (! (! _zz_io_commitReady));
  assign io_pop_fork2_outputs_1_takeWhen_haltWhen_valid = (io_pop_fork2_outputs_1_takeWhen_valid && _zz_io_pop_fork2_outputs_1_takeWhen_ready);
  assign io_pop_fork2_outputs_1_takeWhen_ready = (io_pop_fork2_outputs_1_takeWhen_haltWhen_ready && _zz_io_pop_fork2_outputs_1_takeWhen_ready);
  assign io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_command = io_pop_fork2_outputs_1_takeWhen_payload_command;
  assign io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_engineId = io_pop_fork2_outputs_1_takeWhen_payload_engineId;
  assign io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_vPifoId = io_pop_fork2_outputs_1_takeWhen_payload_vPifoId;
  assign io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_flowId = io_pop_fork2_outputs_1_takeWhen_payload_flowId;
  assign io_pop_fork2_outputs_1_takeWhen_haltWhen_payload_data = io_pop_fork2_outputs_1_takeWhen_payload_data;
  assign io_pop_fork2_outputs_0_throwWhen_ready = streamDemux_4_io_input_ready;
  assign streamDemux_4_io_select = _zz_io_select[0:0];
  assign io_pop_fork2_outputs_1_takeWhen_haltWhen_ready = io_pop_fork2_outputs_1_takeWhen_haltWhen_fork_io_input_ready;
  assign io_output_combStage_valid = streamArbiter_9_io_output_valid;
  assign io_output_combStage_payload_command = streamArbiter_9_io_output_payload_command;
  assign io_output_combStage_payload_engineId = streamArbiter_9_io_output_payload_engineId;
  assign io_output_combStage_payload_vPifoId = streamArbiter_9_io_output_payload_vPifoId;
  assign io_output_combStage_payload_flowId = streamArbiter_9_io_output_payload_flowId;
  assign io_output_combStage_payload_data = streamArbiter_9_io_output_payload_data;
  assign io_output_combStage_ready = pifoEngines_0_io_control_ready;
  assign io_output_combStage_valid_1 = streamArbiter_10_io_output_valid;
  assign io_output_combStage_payload_command_1 = streamArbiter_10_io_output_payload_command;
  assign io_output_combStage_payload_engineId_1 = streamArbiter_10_io_output_payload_engineId;
  assign io_output_combStage_payload_vPifoId_1 = streamArbiter_10_io_output_payload_vPifoId;
  assign io_output_combStage_payload_flowId_1 = streamArbiter_10_io_output_payload_flowId;
  assign io_output_combStage_payload_data_1 = streamArbiter_10_io_output_payload_data;
  assign io_output_combStage_ready_1 = pifoEngines_1_io_control_ready;
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      io_pop_fork2_logic_linkEnable_0 <= 1'b1;
      io_pop_fork2_logic_linkEnable_1 <= 1'b1;
    end else begin
      if(io_pop_fork2_outputs_0_fire) begin
        io_pop_fork2_logic_linkEnable_0 <= 1'b0;
      end
      if(io_pop_fork2_outputs_1_fire) begin
        io_pop_fork2_logic_linkEnable_1 <= 1'b0;
      end
      if(replayControl_io_pop_ready) begin
        io_pop_fork2_logic_linkEnable_0 <= 1'b1;
        io_pop_fork2_logic_linkEnable_1 <= 1'b1;
      end
    end
  end


endmodule

//StreamArbiter_8 replaced by StreamArbiter_7

module StreamArbiter_7 (
  input  wire          io_inputs_0_valid,
  output wire          io_inputs_0_ready,
  input  wire [2:0]    io_inputs_0_payload_command,
  input  wire [1:0]    io_inputs_0_payload_engineId,
  input  wire [2:0]    io_inputs_0_payload_vPifoId,
  input  wire [4:0]    io_inputs_0_payload_flowId,
  input  wire [31:0]   io_inputs_0_payload_data,
  input  wire          io_inputs_1_valid,
  output wire          io_inputs_1_ready,
  input  wire [2:0]    io_inputs_1_payload_command,
  input  wire [1:0]    io_inputs_1_payload_engineId,
  input  wire [2:0]    io_inputs_1_payload_vPifoId,
  input  wire [4:0]    io_inputs_1_payload_flowId,
  input  wire [31:0]   io_inputs_1_payload_data,
  output wire          io_output_valid,
  input  wire          io_output_ready,
  output wire [2:0]    io_output_payload_command,
  output wire [1:0]    io_output_payload_engineId,
  output wire [2:0]    io_output_payload_vPifoId,
  output wire [4:0]    io_output_payload_flowId,
  output wire [31:0]   io_output_payload_data,
  output wire [0:0]    io_chosen,
  output wire [1:0]    io_chosenOH,
  input  wire          clk,
  input  wire          reset
);
  localparam ControlCommand_UpdateMapperPre = 3'd0;
  localparam ControlCommand_UpdateMapperPost = 3'd1;
  localparam ControlCommand_UpdateMapperNonExist = 3'd2;
  localparam ControlCommand_CommitMapper = 3'd3;
  localparam ControlCommand_UpdateBrainEngine = 3'd4;
  localparam ControlCommand_UpdateBrainState = 3'd5;
  localparam ControlCommand_UpdateBrainFlowState = 3'd6;

  wire       [1:0]    _zz_maskProposal_1_1;
  wire       [1:0]    _zz_maskProposal_1_2;
  reg                 locked;
  wire                maskProposal_0;
  wire                maskProposal_1;
  reg                 maskLocked_0;
  reg                 maskLocked_1;
  wire                maskRouted_0;
  wire                maskRouted_1;
  wire       [1:0]    _zz_maskProposal_1;
  wire                io_output_fire;
  wire       [2:0]    _zz_io_output_payload_command;
  wire                _zz_io_chosen;
  `ifndef SYNTHESIS
  reg [159:0] io_inputs_0_payload_command_string;
  reg [159:0] io_inputs_1_payload_command_string;
  reg [159:0] io_output_payload_command_string;
  reg [159:0] _zz_io_output_payload_command_string;
  `endif


  assign _zz_maskProposal_1_1 = (_zz_maskProposal_1 & (~ _zz_maskProposal_1_2));
  assign _zz_maskProposal_1_2 = (_zz_maskProposal_1 - 2'b01);
  `ifndef SYNTHESIS
  always @(*) begin
    case(io_inputs_0_payload_command)
      ControlCommand_UpdateMapperPre : io_inputs_0_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_inputs_0_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_inputs_0_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_inputs_0_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_inputs_0_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_inputs_0_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_inputs_0_payload_command_string = "UpdateBrainFlowState";
      default : io_inputs_0_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_inputs_1_payload_command)
      ControlCommand_UpdateMapperPre : io_inputs_1_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_inputs_1_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_inputs_1_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_inputs_1_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_inputs_1_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_inputs_1_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_inputs_1_payload_command_string = "UpdateBrainFlowState";
      default : io_inputs_1_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_output_payload_command)
      ControlCommand_UpdateMapperPre : io_output_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_output_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_output_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_output_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_output_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_output_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_output_payload_command_string = "UpdateBrainFlowState";
      default : io_output_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(_zz_io_output_payload_command)
      ControlCommand_UpdateMapperPre : _zz_io_output_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : _zz_io_output_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : _zz_io_output_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : _zz_io_output_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : _zz_io_output_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : _zz_io_output_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : _zz_io_output_payload_command_string = "UpdateBrainFlowState";
      default : _zz_io_output_payload_command_string = "????????????????????";
    endcase
  end
  `endif

  assign maskRouted_0 = (locked ? maskLocked_0 : maskProposal_0);
  assign maskRouted_1 = (locked ? maskLocked_1 : maskProposal_1);
  assign _zz_maskProposal_1 = {io_inputs_1_valid,io_inputs_0_valid};
  assign maskProposal_0 = io_inputs_0_valid;
  assign maskProposal_1 = _zz_maskProposal_1_1[1];
  assign io_output_fire = (io_output_valid && io_output_ready);
  assign io_output_valid = ((io_inputs_0_valid && maskRouted_0) || (io_inputs_1_valid && maskRouted_1));
  assign _zz_io_output_payload_command = (maskRouted_0 ? io_inputs_0_payload_command : io_inputs_1_payload_command);
  assign io_output_payload_command = _zz_io_output_payload_command;
  assign io_output_payload_engineId = (maskRouted_0 ? io_inputs_0_payload_engineId : io_inputs_1_payload_engineId);
  assign io_output_payload_vPifoId = (maskRouted_0 ? io_inputs_0_payload_vPifoId : io_inputs_1_payload_vPifoId);
  assign io_output_payload_flowId = (maskRouted_0 ? io_inputs_0_payload_flowId : io_inputs_1_payload_flowId);
  assign io_output_payload_data = (maskRouted_0 ? io_inputs_0_payload_data : io_inputs_1_payload_data);
  assign io_inputs_0_ready = ((1'b0 || maskRouted_0) && io_output_ready);
  assign io_inputs_1_ready = ((1'b0 || maskRouted_1) && io_output_ready);
  assign io_chosenOH = {maskRouted_1,maskRouted_0};
  assign _zz_io_chosen = io_chosenOH[1];
  assign io_chosen = _zz_io_chosen;
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      locked <= 1'b0;
    end else begin
      if(io_output_valid) begin
        locked <= 1'b1;
      end
      if(io_output_fire) begin
        locked <= 1'b0;
      end
    end
  end

  always @(posedge clk) begin
    if(io_output_valid) begin
      maskLocked_0 <= maskRouted_0;
      maskLocked_1 <= maskRouted_1;
    end
  end


endmodule

module StreamFork_8 (
  input  wire          io_input_valid,
  output reg           io_input_ready,
  input  wire [2:0]    io_input_payload_command,
  input  wire [1:0]    io_input_payload_engineId,
  input  wire [2:0]    io_input_payload_vPifoId,
  input  wire [4:0]    io_input_payload_flowId,
  input  wire [31:0]   io_input_payload_data,
  output wire          io_outputs_0_valid,
  input  wire          io_outputs_0_ready,
  output wire [2:0]    io_outputs_0_payload_command,
  output wire [1:0]    io_outputs_0_payload_engineId,
  output wire [2:0]    io_outputs_0_payload_vPifoId,
  output wire [4:0]    io_outputs_0_payload_flowId,
  output wire [31:0]   io_outputs_0_payload_data,
  output wire          io_outputs_1_valid,
  input  wire          io_outputs_1_ready,
  output wire [2:0]    io_outputs_1_payload_command,
  output wire [1:0]    io_outputs_1_payload_engineId,
  output wire [2:0]    io_outputs_1_payload_vPifoId,
  output wire [4:0]    io_outputs_1_payload_flowId,
  output wire [31:0]   io_outputs_1_payload_data,
  input  wire          clk,
  input  wire          reset
);
  localparam ControlCommand_UpdateMapperPre = 3'd0;
  localparam ControlCommand_UpdateMapperPost = 3'd1;
  localparam ControlCommand_UpdateMapperNonExist = 3'd2;
  localparam ControlCommand_CommitMapper = 3'd3;
  localparam ControlCommand_UpdateBrainEngine = 3'd4;
  localparam ControlCommand_UpdateBrainState = 3'd5;
  localparam ControlCommand_UpdateBrainFlowState = 3'd6;

  reg                 logic_linkEnable_0;
  reg                 logic_linkEnable_1;
  wire                when_Stream_l1253;
  wire                when_Stream_l1253_1;
  wire                io_outputs_0_fire;
  wire                io_outputs_1_fire;
  `ifndef SYNTHESIS
  reg [159:0] io_input_payload_command_string;
  reg [159:0] io_outputs_0_payload_command_string;
  reg [159:0] io_outputs_1_payload_command_string;
  `endif


  `ifndef SYNTHESIS
  always @(*) begin
    case(io_input_payload_command)
      ControlCommand_UpdateMapperPre : io_input_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_input_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_input_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_input_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_input_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_input_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_input_payload_command_string = "UpdateBrainFlowState";
      default : io_input_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_outputs_0_payload_command)
      ControlCommand_UpdateMapperPre : io_outputs_0_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_outputs_0_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_outputs_0_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_outputs_0_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_outputs_0_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_outputs_0_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_outputs_0_payload_command_string = "UpdateBrainFlowState";
      default : io_outputs_0_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_outputs_1_payload_command)
      ControlCommand_UpdateMapperPre : io_outputs_1_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_outputs_1_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_outputs_1_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_outputs_1_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_outputs_1_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_outputs_1_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_outputs_1_payload_command_string = "UpdateBrainFlowState";
      default : io_outputs_1_payload_command_string = "????????????????????";
    endcase
  end
  `endif

  always @(*) begin
    io_input_ready = 1'b1;
    if(when_Stream_l1253) begin
      io_input_ready = 1'b0;
    end
    if(when_Stream_l1253_1) begin
      io_input_ready = 1'b0;
    end
  end

  assign when_Stream_l1253 = ((! io_outputs_0_ready) && logic_linkEnable_0);
  assign when_Stream_l1253_1 = ((! io_outputs_1_ready) && logic_linkEnable_1);
  assign io_outputs_0_valid = (io_input_valid && logic_linkEnable_0);
  assign io_outputs_0_payload_command = io_input_payload_command;
  assign io_outputs_0_payload_engineId = io_input_payload_engineId;
  assign io_outputs_0_payload_vPifoId = io_input_payload_vPifoId;
  assign io_outputs_0_payload_flowId = io_input_payload_flowId;
  assign io_outputs_0_payload_data = io_input_payload_data;
  assign io_outputs_0_fire = (io_outputs_0_valid && io_outputs_0_ready);
  assign io_outputs_1_valid = (io_input_valid && logic_linkEnable_1);
  assign io_outputs_1_payload_command = io_input_payload_command;
  assign io_outputs_1_payload_engineId = io_input_payload_engineId;
  assign io_outputs_1_payload_vPifoId = io_input_payload_vPifoId;
  assign io_outputs_1_payload_flowId = io_input_payload_flowId;
  assign io_outputs_1_payload_data = io_input_payload_data;
  assign io_outputs_1_fire = (io_outputs_1_valid && io_outputs_1_ready);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      logic_linkEnable_0 <= 1'b1;
      logic_linkEnable_1 <= 1'b1;
    end else begin
      if(io_outputs_0_fire) begin
        logic_linkEnable_0 <= 1'b0;
      end
      if(io_outputs_1_fire) begin
        logic_linkEnable_1 <= 1'b0;
      end
      if(io_input_ready) begin
        logic_linkEnable_0 <= 1'b1;
        logic_linkEnable_1 <= 1'b1;
      end
    end
  end


endmodule

module StreamDemux_3 (
  input  wire [0:0]    io_select,
  input  wire          io_input_valid,
  output reg           io_input_ready,
  input  wire [2:0]    io_input_payload_command,
  input  wire [1:0]    io_input_payload_engineId,
  input  wire [2:0]    io_input_payload_vPifoId,
  input  wire [4:0]    io_input_payload_flowId,
  input  wire [31:0]   io_input_payload_data,
  output reg           io_outputs_0_valid,
  input  wire          io_outputs_0_ready,
  output wire [2:0]    io_outputs_0_payload_command,
  output wire [1:0]    io_outputs_0_payload_engineId,
  output wire [2:0]    io_outputs_0_payload_vPifoId,
  output wire [4:0]    io_outputs_0_payload_flowId,
  output wire [31:0]   io_outputs_0_payload_data,
  output reg           io_outputs_1_valid,
  input  wire          io_outputs_1_ready,
  output wire [2:0]    io_outputs_1_payload_command,
  output wire [1:0]    io_outputs_1_payload_engineId,
  output wire [2:0]    io_outputs_1_payload_vPifoId,
  output wire [4:0]    io_outputs_1_payload_flowId,
  output wire [31:0]   io_outputs_1_payload_data
);
  localparam ControlCommand_UpdateMapperPre = 3'd0;
  localparam ControlCommand_UpdateMapperPost = 3'd1;
  localparam ControlCommand_UpdateMapperNonExist = 3'd2;
  localparam ControlCommand_CommitMapper = 3'd3;
  localparam ControlCommand_UpdateBrainEngine = 3'd4;
  localparam ControlCommand_UpdateBrainState = 3'd5;
  localparam ControlCommand_UpdateBrainFlowState = 3'd6;

  wire                when_Stream_l1168;
  wire                when_Stream_l1168_1;
  `ifndef SYNTHESIS
  reg [159:0] io_input_payload_command_string;
  reg [159:0] io_outputs_0_payload_command_string;
  reg [159:0] io_outputs_1_payload_command_string;
  `endif


  `ifndef SYNTHESIS
  always @(*) begin
    case(io_input_payload_command)
      ControlCommand_UpdateMapperPre : io_input_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_input_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_input_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_input_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_input_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_input_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_input_payload_command_string = "UpdateBrainFlowState";
      default : io_input_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_outputs_0_payload_command)
      ControlCommand_UpdateMapperPre : io_outputs_0_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_outputs_0_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_outputs_0_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_outputs_0_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_outputs_0_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_outputs_0_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_outputs_0_payload_command_string = "UpdateBrainFlowState";
      default : io_outputs_0_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_outputs_1_payload_command)
      ControlCommand_UpdateMapperPre : io_outputs_1_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_outputs_1_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_outputs_1_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_outputs_1_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_outputs_1_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_outputs_1_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_outputs_1_payload_command_string = "UpdateBrainFlowState";
      default : io_outputs_1_payload_command_string = "????????????????????";
    endcase
  end
  `endif

  always @(*) begin
    io_input_ready = 1'b0;
    if(!when_Stream_l1168) begin
      io_input_ready = io_outputs_0_ready;
    end
    if(!when_Stream_l1168_1) begin
      io_input_ready = io_outputs_1_ready;
    end
  end

  assign io_outputs_0_payload_command = io_input_payload_command;
  assign io_outputs_0_payload_engineId = io_input_payload_engineId;
  assign io_outputs_0_payload_vPifoId = io_input_payload_vPifoId;
  assign io_outputs_0_payload_flowId = io_input_payload_flowId;
  assign io_outputs_0_payload_data = io_input_payload_data;
  assign when_Stream_l1168 = (1'b0 != io_select);
  always @(*) begin
    if(when_Stream_l1168) begin
      io_outputs_0_valid = 1'b0;
    end else begin
      io_outputs_0_valid = io_input_valid;
    end
  end

  assign io_outputs_1_payload_command = io_input_payload_command;
  assign io_outputs_1_payload_engineId = io_input_payload_engineId;
  assign io_outputs_1_payload_vPifoId = io_input_payload_vPifoId;
  assign io_outputs_1_payload_flowId = io_input_payload_flowId;
  assign io_outputs_1_payload_data = io_input_payload_data;
  assign when_Stream_l1168_1 = (1'b1 != io_select);
  always @(*) begin
    if(when_Stream_l1168_1) begin
      io_outputs_1_valid = 1'b0;
    end else begin
      io_outputs_1_valid = io_input_valid;
    end
  end


endmodule

module ReplayControlFifo (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [2:0]    io_push_payload_command,
  input  wire [1:0]    io_push_payload_engineId,
  input  wire [2:0]    io_push_payload_vPifoId,
  input  wire [4:0]    io_push_payload_flowId,
  input  wire [31:0]   io_push_payload_data,
  output wire          io_pop_valid,
  input  wire          io_pop_ready,
  output wire [2:0]    io_pop_payload_command,
  output wire [1:0]    io_pop_payload_engineId,
  output wire [2:0]    io_pop_payload_vPifoId,
  output wire [4:0]    io_pop_payload_flowId,
  output wire [31:0]   io_pop_payload_data,
  output wire          io_replaying,
  output reg  [1:0]    io_available,
  input  wire          clk,
  input  wire          reset
);
  localparam ControlCommand_UpdateMapperPre = 3'd0;
  localparam ControlCommand_UpdateMapperPost = 3'd1;
  localparam ControlCommand_UpdateMapperNonExist = 3'd2;
  localparam ControlCommand_CommitMapper = 3'd3;
  localparam ControlCommand_UpdateBrainEngine = 3'd4;
  localparam ControlCommand_UpdateBrainState = 3'd5;
  localparam ControlCommand_UpdateBrainFlowState = 3'd6;

  reg        [44:0]   storage_spinal_port1;
  wire       [0:0]    _zz_storage_port;
  wire       [44:0]   _zz_storage_port_1;
  wire       [1:0]    _zz_when_ReplayControlFifo_l59;
  reg        [1:0]    writePointer;
  reg        [1:0]    readPointer;
  reg        [1:0]    releasePointer;
  reg        [1:0]    replayEnd;
  reg                 retained;
  reg                 replaying;
  reg                 headValid;
  wire       [1:0]    occupancy;
  wire                incomingCommit;
  wire                when_ReplayControlFifo_l38;
  wire                io_push_fire;
  wire       [2:0]    head_command;
  wire       [1:0]    head_engineId;
  wire       [2:0]    head_vPifoId;
  wire       [4:0]    head_flowId;
  wire       [31:0]   head_data;
  wire                mapper_8;
  wire                commit;
  wire                skip;
  wire                consume;
  reg        [1:0]    nextRead;
  wire                when_ReplayControlFifo_l59;
  wire                when_ReplayControlFifo_l67;
  wire                when_ReplayControlFifo_l74;
  wire                advance;
  wire                readEnable;
  wire       [0:0]    _zz_head_engineId;
  wire       [44:0]   _zz_head_engineId_1;
  wire       [2:0]    _zz_head_command;
  `ifndef SYNTHESIS
  reg [159:0] io_push_payload_command_string;
  reg [159:0] io_pop_payload_command_string;
  reg [159:0] head_command_string;
  reg [159:0] _zz_head_command_string;
  `endif

  reg [44:0] storage [0:1];

  assign _zz_storage_port = writePointer[0:0];
  assign _zz_when_ReplayControlFifo_l59 = (readPointer + 2'b01);
  assign _zz_storage_port_1 = {io_push_payload_data,{io_push_payload_flowId,{io_push_payload_vPifoId,{io_push_payload_engineId,io_push_payload_command}}}};
  always @(posedge clk) begin
    if(io_push_fire) begin
      storage[_zz_storage_port] <= _zz_storage_port_1;
    end
  end

  always @(posedge clk) begin
    if(readEnable) begin
      storage_spinal_port1 <= storage[_zz_head_engineId];
    end
  end

  `ifndef SYNTHESIS
  always @(*) begin
    case(io_push_payload_command)
      ControlCommand_UpdateMapperPre : io_push_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_push_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_push_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_push_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_push_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_push_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_push_payload_command_string = "UpdateBrainFlowState";
      default : io_push_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_pop_payload_command)
      ControlCommand_UpdateMapperPre : io_pop_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_pop_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_pop_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_pop_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_pop_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_pop_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_pop_payload_command_string = "UpdateBrainFlowState";
      default : io_pop_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(head_command)
      ControlCommand_UpdateMapperPre : head_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : head_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : head_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : head_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : head_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : head_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : head_command_string = "UpdateBrainFlowState";
      default : head_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(_zz_head_command)
      ControlCommand_UpdateMapperPre : _zz_head_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : _zz_head_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : _zz_head_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : _zz_head_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : _zz_head_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : _zz_head_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : _zz_head_command_string = "UpdateBrainFlowState";
      default : _zz_head_command_string = "????????????????????";
    endcase
  end
  `endif

  assign occupancy = (writePointer - releasePointer);
  assign incomingCommit = (io_push_payload_command == ControlCommand_CommitMapper);
  assign io_push_ready = ((! replaying) && (incomingCommit ? (occupancy < 2'b10) : (occupancy < 2'b01)));
  assign io_replaying = replaying;
  always @(*) begin
    io_available = 2'b00;
    if(when_ReplayControlFifo_l38) begin
      io_available = (2'b01 - occupancy);
    end
  end

  assign when_ReplayControlFifo_l38 = (occupancy < 2'b01);
  assign io_push_fire = (io_push_valid && io_push_ready);
  assign mapper_8 = ((head_command == ControlCommand_UpdateMapperPre) || (head_command == ControlCommand_UpdateMapperPost));
  assign commit = (head_command == ControlCommand_CommitMapper);
  assign skip = (replaying && (! mapper_8));
  assign io_pop_valid = (headValid && (! skip));
  assign io_pop_payload_command = head_command;
  assign io_pop_payload_engineId = head_engineId;
  assign io_pop_payload_vPifoId = head_vPifoId;
  assign io_pop_payload_flowId = head_flowId;
  assign io_pop_payload_data = head_data;
  assign consume = (headValid && (skip || io_pop_ready));
  always @(*) begin
    nextRead = readPointer;
    if(consume) begin
      nextRead = (readPointer + 2'b01);
      if(replaying) begin
        if(when_ReplayControlFifo_l59) begin
          nextRead = (replayEnd + 2'b01);
        end
      end else begin
        if(when_ReplayControlFifo_l67) begin
          nextRead = releasePointer;
        end
      end
    end
  end

  assign when_ReplayControlFifo_l59 = (_zz_when_ReplayControlFifo_l59 == replayEnd);
  assign when_ReplayControlFifo_l67 = (commit && retained);
  assign when_ReplayControlFifo_l74 = (! retained);
  assign advance = ((! headValid) || consume);
  assign readEnable = (advance && (nextRead != writePointer));
  assign _zz_head_engineId = nextRead[0:0];
  assign _zz_head_engineId_1 = storage_spinal_port1;
  assign _zz_head_command = _zz_head_engineId_1[2 : 0];
  assign head_command = _zz_head_command;
  assign head_engineId = _zz_head_engineId_1[4 : 3];
  assign head_vPifoId = _zz_head_engineId_1[7 : 5];
  assign head_flowId = _zz_head_engineId_1[12 : 8];
  assign head_data = _zz_head_engineId_1[44 : 13];
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      writePointer <= 2'b00;
      readPointer <= 2'b00;
      releasePointer <= 2'b00;
      replayEnd <= 2'b00;
      retained <= 1'b0;
      replaying <= 1'b0;
      headValid <= 1'b0;
    end else begin
      if(io_push_fire) begin
        writePointer <= (writePointer + 2'b01);
      end
      if(consume) begin
        if(replaying) begin
          releasePointer <= (readPointer + 2'b01);
          if(when_ReplayControlFifo_l59) begin
            releasePointer <= (replayEnd + 2'b01);
            replaying <= 1'b0;
            retained <= 1'b0;
          end
        end else begin
          if(when_ReplayControlFifo_l67) begin
            replayEnd <= readPointer;
            replaying <= 1'b1;
          end else begin
            if(mapper_8) begin
              retained <= 1'b1;
            end else begin
              if(when_ReplayControlFifo_l74) begin
                releasePointer <= (readPointer + 2'b01);
              end
            end
          end
        end
      end
      if(advance) begin
        readPointer <= nextRead;
        headValid <= readEnable;
      end
    end
  end


endmodule

module PifoEngine_1 (
  input  wire          io_enqueRequest_valid,
  output reg           io_enqueRequest_ready,
  input  wire [1:0]    io_enqueRequest_payload_engineId,
  input  wire [2:0]    io_enqueRequest_payload_vPifoId,
  input  wire          io_dequeueRequest_valid,
  output wire          io_dequeueRequest_ready,
  input  wire [1:0]    io_dequeueRequest_payload_engineId,
  input  wire [2:0]    io_dequeueRequest_payload_vPifoId,
  output wire          io_dequeueResponse_valid,
  input  wire          io_dequeueResponse_ready,
  output wire [1:0]    io_dequeueResponse_payload_engineId,
  output wire [2:0]    io_dequeueResponse_payload_vPifoId,
  input  wire          io_control_valid,
  output reg           io_control_ready,
  input  wire [2:0]    io_control_payload_command,
  input  wire [1:0]    io_control_payload_engineId,
  input  wire [2:0]    io_control_payload_vPifoId,
  input  wire [4:0]    io_control_payload_flowId,
  input  wire [31:0]   io_control_payload_data,
  output wire          io_commitReady,
  output wire          io_pifo_push1_valid,
  output wire [7:0]    io_pifo_push1_payload_priority,
  output wire [4:0]    io_pifo_push1_payload_data,
  output wire [2:0]    io_pifo_push1_payload_port,
  output wire          io_pifo_push2_valid,
  output wire [7:0]    io_pifo_push2_payload_priority,
  output wire [4:0]    io_pifo_push2_payload_data,
  output wire [2:0]    io_pifo_push2_payload_port,
  output wire          io_pifo_popRequest_valid,
  output wire [2:0]    io_pifo_popRequest_payload_port,
  input  wire          io_pifo_popResponse_valid,
  input  wire          io_pifo_popResponse_payload_exist,
  input  wire [7:0]    io_pifo_popResponse_payload_priority,
  input  wire [4:0]    io_pifo_popResponse_payload_data,
  input  wire [2:0]    io_pifo_popResponse_payload_port,
  input  wire          io_pifo_popPortEmpty,
  input  wire          io_pifo_portDrained_valid,
  input  wire [2:0]    io_pifo_portDrained_payload,
  input  wire          clk,
  input  wire          reset
);
  localparam ControlCommand_UpdateMapperPre = 3'd0;
  localparam ControlCommand_UpdateMapperPost = 3'd1;
  localparam ControlCommand_UpdateMapperNonExist = 3'd2;
  localparam ControlCommand_CommitMapper = 3'd3;
  localparam ControlCommand_UpdateBrainEngine = 3'd4;
  localparam ControlCommand_UpdateBrainState = 3'd5;
  localparam ControlCommand_UpdateBrainFlowState = 3'd6;

  wire                pifos_io_popRequest_valid;
  wire       [2:0]    enque_enqueMapper_io_writeReq_payload_outputId;
  wire       [7:0]    deque_dequeMapper_io_writeReq_payload_inputId;
  wire       [4:0]    deque_dequeMapper_io_writeReq_payload_outputId;
  wire                deque_frontRewrite_io_emptySource_valid;
  wire       [2:0]    deque_frontRewrite_io_writeReq_payload_outputId;
  reg                 control_fork_io_outputs_0_ready;
  reg                 control_fork_io_outputs_1_ready;
  reg                 control_fork_io_outputs_2_ready;
  wire                pifos_io_popResponse_valid;
  wire                pifos_io_popResponse_payload_exist;
  wire       [7:0]    pifos_io_popResponse_payload_priority;
  wire       [4:0]    pifos_io_popResponse_payload_data;
  wire       [2:0]    pifos_io_popResponse_payload_port;
  wire                pifos_io_popPortEmpty;
  wire                pifos_io_portDrained_valid;
  wire       [2:0]    pifos_io_portDrained_payload;
  wire                pifos_boundary_push1_valid;
  wire       [7:0]    pifos_boundary_push1_payload_priority;
  wire       [4:0]    pifos_boundary_push1_payload_data;
  wire       [2:0]    pifos_boundary_push1_payload_port;
  wire                pifos_boundary_push2_valid;
  wire       [7:0]    pifos_boundary_push2_payload_priority;
  wire       [4:0]    pifos_boundary_push2_payload_data;
  wire       [2:0]    pifos_boundary_push2_payload_port;
  wire                pifos_boundary_popRequest_valid;
  wire       [2:0]    pifos_boundary_popRequest_payload_port;
  wire                enque_enqueMapper_io_readRes_valid;
  wire       [2:0]    enque_enqueMapper_io_readRes_payload;
  wire                enque_enqueMapper_io_writeReq_ready;
  wire                enque_enqueMapper_io_commitReady;
  wire                enque_flowIdStream_fifo_io_push_ready;
  wire                enque_flowIdStream_fifo_io_pop_valid;
  wire       [1:0]    enque_flowIdStream_fifo_io_pop_payload_engineId;
  wire       [2:0]    enque_flowIdStream_fifo_io_pop_payload_vPifoId;
  wire       [1:0]    enque_flowIdStream_fifo_io_occupancy;
  wire       [1:0]    enque_flowIdStream_fifo_io_availability;
  wire                enque_brain_io_request_ready;
  wire                enque_brain_io_response_valid;
  wire       [7:0]    enque_brain_io_response_payload_priority;
  wire       [4:0]    enque_brain_io_response_payload_data;
  wire       [2:0]    enque_brain_io_response_payload_port;
  wire                enque_brain_io_control_ready;
  wire                deque_dequeMapper_io_readRes_valid;
  wire       [4:0]    deque_dequeMapper_io_readRes_payload;
  wire                deque_dequeMapper_io_writeReq_ready;
  wire                deque_dequeMapper_io_commitReady;
  wire       [2:0]    deque_frontRewrite_io_lookupTarget;
  wire                deque_frontRewrite_io_lookupEnabled;
  wire                deque_frontRewrite_io_lookupCanEnable;
  wire                deque_frontRewrite_io_drainEnablesRewrite;
  wire                deque_frontRewrite_io_emptyEnablesRewrite;
  wire                deque_frontRewrite_io_writeReq_ready;
  wire                deque_existingPop_fork_io_input_ready;
  wire                deque_existingPop_fork_io_outputs_0_valid;
  wire                deque_existingPop_fork_io_outputs_0_payload_exist;
  wire       [7:0]    deque_existingPop_fork_io_outputs_0_payload_priority;
  wire       [4:0]    deque_existingPop_fork_io_outputs_0_payload_data;
  wire       [2:0]    deque_existingPop_fork_io_outputs_0_payload_port;
  wire                deque_existingPop_fork_io_outputs_1_valid;
  wire                deque_existingPop_fork_io_outputs_1_payload_exist;
  wire       [7:0]    deque_existingPop_fork_io_outputs_1_payload_priority;
  wire       [4:0]    deque_existingPop_fork_io_outputs_1_payload_data;
  wire       [2:0]    deque_existingPop_fork_io_outputs_1_payload_port;
  wire                deque_existingPop_fork_io_outputs_2_valid;
  wire                deque_existingPop_fork_io_outputs_2_payload_exist;
  wire       [7:0]    deque_existingPop_fork_io_outputs_2_payload_priority;
  wire       [4:0]    deque_existingPop_fork_io_outputs_2_payload_data;
  wire       [2:0]    deque_existingPop_fork_io_outputs_2_payload_port;
  wire                io_outputs_2_fifo_io_push_ready;
  wire                io_outputs_2_fifo_io_pop_valid;
  wire                io_outputs_2_fifo_io_pop_payload_exist;
  wire       [7:0]    io_outputs_2_fifo_io_pop_payload_priority;
  wire       [4:0]    io_outputs_2_fifo_io_pop_payload_data;
  wire       [2:0]    io_outputs_2_fifo_io_pop_payload_port;
  wire       [1:0]    io_outputs_2_fifo_io_occupancy;
  wire       [1:0]    io_outputs_2_fifo_io_availability;
  wire                control_fork_io_input_ready;
  wire                control_fork_io_outputs_0_valid;
  wire       [2:0]    control_fork_io_outputs_0_payload_command;
  wire       [1:0]    control_fork_io_outputs_0_payload_engineId;
  wire       [2:0]    control_fork_io_outputs_0_payload_vPifoId;
  wire       [4:0]    control_fork_io_outputs_0_payload_flowId;
  wire       [31:0]   control_fork_io_outputs_0_payload_data;
  wire                control_fork_io_outputs_1_valid;
  wire       [2:0]    control_fork_io_outputs_1_payload_command;
  wire       [1:0]    control_fork_io_outputs_1_payload_engineId;
  wire       [2:0]    control_fork_io_outputs_1_payload_vPifoId;
  wire       [4:0]    control_fork_io_outputs_1_payload_flowId;
  wire       [31:0]   control_fork_io_outputs_1_payload_data;
  wire                control_fork_io_outputs_2_valid;
  wire       [2:0]    control_fork_io_outputs_2_payload_command;
  wire       [1:0]    control_fork_io_outputs_2_payload_engineId;
  wire       [2:0]    control_fork_io_outputs_2_payload_vPifoId;
  wire       [4:0]    control_fork_io_outputs_2_payload_flowId;
  wire       [31:0]   control_fork_io_outputs_2_payload_data;
  wire                enque_mapperRead_valid;
  wire                enque_mapperRead_ready;
  wire       [1:0]    enque_mapperRead_payload_engineId;
  wire       [2:0]    enque_mapperRead_payload_vPifoId;
  wire                enque_flowIdStream_valid;
  wire                enque_flowIdStream_ready;
  wire       [1:0]    enque_flowIdStream_payload_engineId;
  wire       [2:0]    enque_flowIdStream_payload_vPifoId;
  reg                 io_enqueRequest_fork2_logic_linkEnable_0;
  reg                 io_enqueRequest_fork2_logic_linkEnable_1;
  wire                when_Stream_l1253;
  wire                when_Stream_l1253_1;
  wire                enque_mapperRead_fire;
  wire                enque_flowIdStream_fire;
  wire                enque_mapperRead_map_valid;
  wire                enque_mapperRead_map_ready;
  wire       [2:0]    enque_mapperRead_map_payload;
  wire                enque_mapperRead_map_toFlow_valid;
  wire       [2:0]    enque_mapperRead_map_toFlow_payload;
  wire                enque_brainInput_valid;
  wire                enque_brainInput_ready;
  wire       [2:0]    enque_brainInput_payload_vpifoId;
  wire       [4:0]    enque_brainInput_payload_flowId;
  wire                enque_enqueMapper_io_readRes_toStream_valid;
  wire                enque_enqueMapper_io_readRes_toStream_ready;
  wire       [2:0]    enque_enqueMapper_io_readRes_toStream_payload;
  wire                _zz_enque_brainInput_valid;
  wire                _zz_enque_enqueMapper_io_readRes_toStream_ready;
  wire                enque_brain_io_response_toFlow_valid;
  wire       [7:0]    enque_brain_io_response_toFlow_payload_priority;
  wire       [4:0]    enque_brain_io_response_toFlow_payload_data;
  wire       [2:0]    enque_brain_io_response_toFlow_payload_port;
  wire       [2:0]    deque_frontPort;
  wire                deque_enablingRewrite;
  wire                pifos_io_popResponse_toStream_valid;
  reg                 pifos_io_popResponse_toStream_ready;
  wire                pifos_io_popResponse_toStream_payload_exist;
  wire       [7:0]    pifos_io_popResponse_toStream_payload_priority;
  wire       [4:0]    pifos_io_popResponse_toStream_payload_data;
  wire       [2:0]    pifos_io_popResponse_toStream_payload_port;
  wire                when_Stream_l581;
  reg                 deque_existingPop_valid;
  wire                deque_existingPop_ready;
  wire                deque_existingPop_payload_exist;
  wire       [7:0]    deque_existingPop_payload_priority;
  wire       [4:0]    deque_existingPop_payload_data;
  wire       [2:0]    deque_existingPop_payload_port;
  wire                deque_existingPop_fork_io_outputs_0_toFlow_valid;
  wire                deque_existingPop_fork_io_outputs_0_toFlow_payload_exist;
  wire       [7:0]    deque_existingPop_fork_io_outputs_0_toFlow_payload_priority;
  wire       [4:0]    deque_existingPop_fork_io_outputs_0_toFlow_payload_data;
  wire       [2:0]    deque_existingPop_fork_io_outputs_0_toFlow_payload_port;
  wire                deque_existingPop_fork_io_outputs_1_map_valid;
  wire                deque_existingPop_fork_io_outputs_1_map_ready;
  wire       [7:0]    deque_existingPop_fork_io_outputs_1_map_payload;
  wire                deque_existingPop_fork_io_outputs_1_map_toFlow_valid;
  wire       [7:0]    deque_existingPop_fork_io_outputs_1_map_toFlow_payload;
  wire                deque_dequeMapper_io_readRes_toStream_valid;
  wire                deque_dequeMapper_io_readRes_toStream_ready;
  wire       [4:0]    deque_dequeMapper_io_readRes_toStream_payload;
  wire                _zz_io_dequeueResponse_valid;
  wire                _zz_deque_dequeMapper_io_readRes_toStream_ready;
  wire                mapperCommitReady;
  wire                control_valid;
  wire                control_ready;
  wire       [2:0]    control_payload_command;
  wire       [1:0]    control_payload_engineId;
  wire       [2:0]    control_payload_vPifoId;
  wire       [4:0]    control_payload_flowId;
  wire       [31:0]   control_payload_data;
  wire                brainControl_valid;
  wire                brainControl_ready;
  wire       [2:0]    brainControl_payload_command;
  wire       [1:0]    brainControl_payload_engineId;
  wire       [2:0]    brainControl_payload_vPifoId;
  wire       [4:0]    brainControl_payload_flowId;
  wire       [31:0]   brainControl_payload_data;
  wire                commitControl_valid;
  reg                 commitControl_ready;
  wire       [2:0]    commitControl_payload_command;
  wire       [1:0]    commitControl_payload_engineId;
  wire       [2:0]    commitControl_payload_vPifoId;
  wire       [4:0]    commitControl_payload_flowId;
  wire       [31:0]   commitControl_payload_data;
  reg                 io_control_fork3_logic_linkEnable_0;
  reg                 io_control_fork3_logic_linkEnable_1;
  reg                 io_control_fork3_logic_linkEnable_2;
  wire                when_Stream_l1253_2;
  wire                when_Stream_l1253_3;
  wire                when_Stream_l1253_4;
  wire                control_fire;
  wire                brainControl_fire;
  wire                commitControl_fire;
  wire                when_Stream_l581_1;
  reg                 control_fork_io_outputs_0_takeWhen_valid;
  wire                control_fork_io_outputs_0_takeWhen_ready;
  wire       [2:0]    control_fork_io_outputs_0_takeWhen_payload_command;
  wire       [1:0]    control_fork_io_outputs_0_takeWhen_payload_engineId;
  wire       [2:0]    control_fork_io_outputs_0_takeWhen_payload_vPifoId;
  wire       [4:0]    control_fork_io_outputs_0_takeWhen_payload_flowId;
  wire       [31:0]   control_fork_io_outputs_0_takeWhen_payload_data;
  wire                when_Stream_l581_2;
  reg                 control_fork_io_outputs_1_takeWhen_valid;
  wire                control_fork_io_outputs_1_takeWhen_ready;
  wire       [2:0]    control_fork_io_outputs_1_takeWhen_payload_command;
  wire       [1:0]    control_fork_io_outputs_1_takeWhen_payload_engineId;
  wire       [2:0]    control_fork_io_outputs_1_takeWhen_payload_vPifoId;
  wire       [4:0]    control_fork_io_outputs_1_takeWhen_payload_flowId;
  wire       [31:0]   control_fork_io_outputs_1_takeWhen_payload_data;
  wire                when_Stream_l581_3;
  reg                 control_fork_io_outputs_2_takeWhen_valid;
  wire                control_fork_io_outputs_2_takeWhen_ready;
  wire       [2:0]    control_fork_io_outputs_2_takeWhen_payload_command;
  wire       [1:0]    control_fork_io_outputs_2_takeWhen_payload_engineId;
  wire       [2:0]    control_fork_io_outputs_2_takeWhen_payload_vPifoId;
  wire       [4:0]    control_fork_io_outputs_2_takeWhen_payload_flowId;
  wire       [31:0]   control_fork_io_outputs_2_takeWhen_payload_data;
  wire                when_Stream_l581_4;
  reg                 commit_valid;
  wire                commit_ready;
  wire       [2:0]    commit_payload_command;
  wire       [1:0]    commit_payload_engineId;
  wire       [2:0]    commit_payload_vPifoId;
  wire       [4:0]    commit_payload_flowId;
  wire       [31:0]   commit_payload_data;
  wire                commitPulse;
  `ifndef SYNTHESIS
  reg [159:0] io_control_payload_command_string;
  reg [159:0] control_payload_command_string;
  reg [159:0] brainControl_payload_command_string;
  reg [159:0] commitControl_payload_command_string;
  reg [159:0] control_fork_io_outputs_0_takeWhen_payload_command_string;
  reg [159:0] control_fork_io_outputs_1_takeWhen_payload_command_string;
  reg [159:0] control_fork_io_outputs_2_takeWhen_payload_command_string;
  reg [159:0] commit_payload_command_string;
  `endif


  ExternalPifoCore pifos (
    .io_push1_valid                        (enque_brain_io_response_toFlow_valid                ), //i
    .io_push1_payload_priority             (enque_brain_io_response_toFlow_payload_priority[7:0]), //i
    .io_push1_payload_data                 (enque_brain_io_response_toFlow_payload_data[4:0]    ), //i
    .io_push1_payload_port                 (enque_brain_io_response_toFlow_payload_port[2:0]    ), //i
    .io_push2_valid                        (1'b0                                                ), //i
    .io_push2_payload_priority             (8'bxxxxxxxx                                         ), //i
    .io_push2_payload_data                 (5'bxxxxx                                            ), //i
    .io_push2_payload_port                 (3'bxxx                                              ), //i
    .io_popRequest_valid                   (pifos_io_popRequest_valid                           ), //i
    .io_popRequest_payload_port            (deque_frontPort[2:0]                                ), //i
    .io_popResponse_valid                  (pifos_io_popResponse_valid                          ), //o
    .io_popResponse_payload_exist          (pifos_io_popResponse_payload_exist                  ), //o
    .io_popResponse_payload_priority       (pifos_io_popResponse_payload_priority[7:0]          ), //o
    .io_popResponse_payload_data           (pifos_io_popResponse_payload_data[4:0]              ), //o
    .io_popResponse_payload_port           (pifos_io_popResponse_payload_port[2:0]              ), //o
    .io_popPortEmpty                       (pifos_io_popPortEmpty                               ), //o
    .io_portDrained_valid                  (pifos_io_portDrained_valid                          ), //o
    .io_portDrained_payload                (pifos_io_portDrained_payload[2:0]                   ), //o
    .boundary_push1_valid                  (pifos_boundary_push1_valid                          ), //o
    .boundary_push1_payload_priority       (pifos_boundary_push1_payload_priority[7:0]          ), //o
    .boundary_push1_payload_data           (pifos_boundary_push1_payload_data[4:0]              ), //o
    .boundary_push1_payload_port           (pifos_boundary_push1_payload_port[2:0]              ), //o
    .boundary_push2_valid                  (pifos_boundary_push2_valid                          ), //o
    .boundary_push2_payload_priority       (pifos_boundary_push2_payload_priority[7:0]          ), //o
    .boundary_push2_payload_data           (pifos_boundary_push2_payload_data[4:0]              ), //o
    .boundary_push2_payload_port           (pifos_boundary_push2_payload_port[2:0]              ), //o
    .boundary_popRequest_valid             (pifos_boundary_popRequest_valid                     ), //o
    .boundary_popRequest_payload_port      (pifos_boundary_popRequest_payload_port[2:0]         ), //o
    .boundary_popResponse_valid            (io_pifo_popResponse_valid                           ), //i
    .boundary_popResponse_payload_exist    (io_pifo_popResponse_payload_exist                   ), //i
    .boundary_popResponse_payload_priority (io_pifo_popResponse_payload_priority[7:0]           ), //i
    .boundary_popResponse_payload_data     (io_pifo_popResponse_payload_data[4:0]               ), //i
    .boundary_popResponse_payload_port     (io_pifo_popResponse_payload_port[2:0]               ), //i
    .boundary_popPortEmpty                 (io_pifo_popPortEmpty                                ), //i
    .boundary_portDrained_valid            (io_pifo_portDrained_valid                           ), //i
    .boundary_portDrained_payload          (io_pifo_portDrained_payload[2:0]                    )  //i
  );
  ReplayMapper_2 enque_enqueMapper (
    .io_readReq_valid             (enque_mapperRead_map_toFlow_valid                      ), //i
    .io_readReq_payload           (enque_mapperRead_map_toFlow_payload[2:0]               ), //i
    .io_readRes_valid             (enque_enqueMapper_io_readRes_valid                     ), //o
    .io_readRes_payload           (enque_enqueMapper_io_readRes_payload[2:0]              ), //o
    .io_writeReq_valid            (control_fork_io_outputs_0_takeWhen_valid               ), //i
    .io_writeReq_ready            (enque_enqueMapper_io_writeReq_ready                    ), //o
    .io_writeReq_payload_inputId  (control_fork_io_outputs_0_takeWhen_payload_vPifoId[2:0]), //i
    .io_writeReq_payload_outputId (enque_enqueMapper_io_writeReq_payload_outputId[2:0]    ), //i
    .io_commit                    (commitPulse                                            ), //i
    .io_commitReady               (enque_enqueMapper_io_commitReady                       ), //o
    .clk                          (clk                                                    ), //i
    .reset                        (reset                                                  )  //i
  );
  StreamFifoLowLatency_10 enque_flowIdStream_fifo (
    .io_push_valid            (enque_flowIdStream_valid                            ), //i
    .io_push_ready            (enque_flowIdStream_fifo_io_push_ready               ), //o
    .io_push_payload_engineId (enque_flowIdStream_payload_engineId[1:0]            ), //i
    .io_push_payload_vPifoId  (enque_flowIdStream_payload_vPifoId[2:0]             ), //i
    .io_pop_valid             (enque_flowIdStream_fifo_io_pop_valid                ), //o
    .io_pop_ready             (_zz_enque_enqueMapper_io_readRes_toStream_ready     ), //i
    .io_pop_payload_engineId  (enque_flowIdStream_fifo_io_pop_payload_engineId[1:0]), //o
    .io_pop_payload_vPifoId   (enque_flowIdStream_fifo_io_pop_payload_vPifoId[2:0] ), //o
    .io_flush                 (1'b0                                                ), //i
    .io_occupancy             (enque_flowIdStream_fifo_io_occupancy[1:0]           ), //o
    .io_availability          (enque_flowIdStream_fifo_io_availability[1:0]        ), //o
    .clk                      (clk                                                 ), //i
    .reset                    (reset                                               )  //i
  );
  PIFOBrain_1 enque_brain (
    .io_request_valid             (enque_brainInput_valid                                          ), //i
    .io_request_ready             (enque_brain_io_request_ready                                    ), //o
    .io_request_payload_vpifoId   (enque_brainInput_payload_vpifoId[2:0]                           ), //i
    .io_request_payload_flowId    (enque_brainInput_payload_flowId[4:0]                            ), //i
    .io_response_valid            (enque_brain_io_response_valid                                   ), //o
    .io_response_ready            (1'b1                                                            ), //i
    .io_response_payload_priority (enque_brain_io_response_payload_priority[7:0]                   ), //o
    .io_response_payload_data     (enque_brain_io_response_payload_data[4:0]                       ), //o
    .io_response_payload_port     (enque_brain_io_response_payload_port[2:0]                       ), //o
    .io_control_valid             (brainControl_valid                                              ), //i
    .io_control_ready             (enque_brain_io_control_ready                                    ), //o
    .io_control_payload_command   (brainControl_payload_command[2:0]                               ), //i
    .io_control_payload_engineId  (brainControl_payload_engineId[1:0]                              ), //i
    .io_control_payload_vPifoId   (brainControl_payload_vPifoId[2:0]                               ), //i
    .io_control_payload_flowId    (brainControl_payload_flowId[4:0]                                ), //i
    .io_control_payload_data      (brainControl_payload_data[31:0]                                 ), //i
    .io_poped_valid               (deque_existingPop_fork_io_outputs_0_toFlow_valid                ), //i
    .io_poped_payload_exist       (deque_existingPop_fork_io_outputs_0_toFlow_payload_exist        ), //i
    .io_poped_payload_priority    (deque_existingPop_fork_io_outputs_0_toFlow_payload_priority[7:0]), //i
    .io_poped_payload_data        (deque_existingPop_fork_io_outputs_0_toFlow_payload_data[4:0]    ), //i
    .io_poped_payload_port        (deque_existingPop_fork_io_outputs_0_toFlow_payload_port[2:0]    ), //i
    .clk                          (clk                                                             ), //i
    .reset                        (reset                                                           )  //i
  );
  ReplayMapper_3 deque_dequeMapper (
    .io_readReq_valid             (deque_existingPop_fork_io_outputs_1_map_toFlow_valid       ), //i
    .io_readReq_payload           (deque_existingPop_fork_io_outputs_1_map_toFlow_payload[7:0]), //i
    .io_readRes_valid             (deque_dequeMapper_io_readRes_valid                         ), //o
    .io_readRes_payload           (deque_dequeMapper_io_readRes_payload[4:0]                  ), //o
    .io_writeReq_valid            (control_fork_io_outputs_1_takeWhen_valid                   ), //i
    .io_writeReq_ready            (deque_dequeMapper_io_writeReq_ready                        ), //o
    .io_writeReq_payload_inputId  (deque_dequeMapper_io_writeReq_payload_inputId[7:0]         ), //i
    .io_writeReq_payload_outputId (deque_dequeMapper_io_writeReq_payload_outputId[4:0]        ), //i
    .io_commit                    (commitPulse                                                ), //i
    .io_commitReady               (deque_dequeMapper_io_commitReady                           ), //o
    .clk                          (clk                                                        ), //i
    .reset                        (reset                                                      )  //i
  );
  FrontRewriteTable deque_frontRewrite (
    .io_lookupSource              (io_dequeueRequest_payload_vPifoId[2:0]                 ), //i
    .io_lookupTarget              (deque_frontRewrite_io_lookupTarget[2:0]                ), //o
    .io_lookupEnabled             (deque_frontRewrite_io_lookupEnabled                    ), //o
    .io_lookupCanEnable           (deque_frontRewrite_io_lookupCanEnable                  ), //o
    .io_drained_valid             (pifos_io_portDrained_valid                             ), //i
    .io_drained_payload           (pifos_io_portDrained_payload[2:0]                      ), //i
    .io_drainEnablesRewrite       (deque_frontRewrite_io_drainEnablesRewrite              ), //o
    .io_emptySource_valid         (deque_frontRewrite_io_emptySource_valid                ), //i
    .io_emptySource_payload       (io_dequeueRequest_payload_vPifoId[2:0]                 ), //i
    .io_emptyEnablesRewrite       (deque_frontRewrite_io_emptyEnablesRewrite              ), //o
    .io_writeReq_valid            (control_fork_io_outputs_2_takeWhen_valid               ), //i
    .io_writeReq_ready            (deque_frontRewrite_io_writeReq_ready                   ), //o
    .io_writeReq_payload_inputId  (control_fork_io_outputs_2_takeWhen_payload_vPifoId[2:0]), //i
    .io_writeReq_payload_outputId (deque_frontRewrite_io_writeReq_payload_outputId[2:0]   ), //i
    .io_commit                    (commitPulse                                            ), //i
    .clk                          (clk                                                    ), //i
    .reset                        (reset                                                  )  //i
  );
  StreamFork_2 deque_existingPop_fork (
    .io_input_valid                (deque_existingPop_valid                                  ), //i
    .io_input_ready                (deque_existingPop_fork_io_input_ready                    ), //o
    .io_input_payload_exist        (deque_existingPop_payload_exist                          ), //i
    .io_input_payload_priority     (deque_existingPop_payload_priority[7:0]                  ), //i
    .io_input_payload_data         (deque_existingPop_payload_data[4:0]                      ), //i
    .io_input_payload_port         (deque_existingPop_payload_port[2:0]                      ), //i
    .io_outputs_0_valid            (deque_existingPop_fork_io_outputs_0_valid                ), //o
    .io_outputs_0_ready            (1'b1                                                     ), //i
    .io_outputs_0_payload_exist    (deque_existingPop_fork_io_outputs_0_payload_exist        ), //o
    .io_outputs_0_payload_priority (deque_existingPop_fork_io_outputs_0_payload_priority[7:0]), //o
    .io_outputs_0_payload_data     (deque_existingPop_fork_io_outputs_0_payload_data[4:0]    ), //o
    .io_outputs_0_payload_port     (deque_existingPop_fork_io_outputs_0_payload_port[2:0]    ), //o
    .io_outputs_1_valid            (deque_existingPop_fork_io_outputs_1_valid                ), //o
    .io_outputs_1_ready            (deque_existingPop_fork_io_outputs_1_map_ready            ), //i
    .io_outputs_1_payload_exist    (deque_existingPop_fork_io_outputs_1_payload_exist        ), //o
    .io_outputs_1_payload_priority (deque_existingPop_fork_io_outputs_1_payload_priority[7:0]), //o
    .io_outputs_1_payload_data     (deque_existingPop_fork_io_outputs_1_payload_data[4:0]    ), //o
    .io_outputs_1_payload_port     (deque_existingPop_fork_io_outputs_1_payload_port[2:0]    ), //o
    .io_outputs_2_valid            (deque_existingPop_fork_io_outputs_2_valid                ), //o
    .io_outputs_2_ready            (io_outputs_2_fifo_io_push_ready                          ), //i
    .io_outputs_2_payload_exist    (deque_existingPop_fork_io_outputs_2_payload_exist        ), //o
    .io_outputs_2_payload_priority (deque_existingPop_fork_io_outputs_2_payload_priority[7:0]), //o
    .io_outputs_2_payload_data     (deque_existingPop_fork_io_outputs_2_payload_data[4:0]    ), //o
    .io_outputs_2_payload_port     (deque_existingPop_fork_io_outputs_2_payload_port[2:0]    ), //o
    .clk                           (clk                                                      ), //i
    .reset                         (reset                                                    )  //i
  );
  StreamFifoLowLatency_11 io_outputs_2_fifo (
    .io_push_valid            (deque_existingPop_fork_io_outputs_2_valid                ), //i
    .io_push_ready            (io_outputs_2_fifo_io_push_ready                          ), //o
    .io_push_payload_exist    (deque_existingPop_fork_io_outputs_2_payload_exist        ), //i
    .io_push_payload_priority (deque_existingPop_fork_io_outputs_2_payload_priority[7:0]), //i
    .io_push_payload_data     (deque_existingPop_fork_io_outputs_2_payload_data[4:0]    ), //i
    .io_push_payload_port     (deque_existingPop_fork_io_outputs_2_payload_port[2:0]    ), //i
    .io_pop_valid             (io_outputs_2_fifo_io_pop_valid                           ), //o
    .io_pop_ready             (_zz_deque_dequeMapper_io_readRes_toStream_ready          ), //i
    .io_pop_payload_exist     (io_outputs_2_fifo_io_pop_payload_exist                   ), //o
    .io_pop_payload_priority  (io_outputs_2_fifo_io_pop_payload_priority[7:0]           ), //o
    .io_pop_payload_data      (io_outputs_2_fifo_io_pop_payload_data[4:0]               ), //o
    .io_pop_payload_port      (io_outputs_2_fifo_io_pop_payload_port[2:0]               ), //o
    .io_flush                 (1'b0                                                     ), //i
    .io_occupancy             (io_outputs_2_fifo_io_occupancy[1:0]                      ), //o
    .io_availability          (io_outputs_2_fifo_io_availability[1:0]                   ), //o
    .clk                      (clk                                                      ), //i
    .reset                    (reset                                                    )  //i
  );
  StreamFork_1 control_fork (
    .io_input_valid                (control_valid                                  ), //i
    .io_input_ready                (control_fork_io_input_ready                    ), //o
    .io_input_payload_command      (control_payload_command[2:0]                   ), //i
    .io_input_payload_engineId     (control_payload_engineId[1:0]                  ), //i
    .io_input_payload_vPifoId      (control_payload_vPifoId[2:0]                   ), //i
    .io_input_payload_flowId       (control_payload_flowId[4:0]                    ), //i
    .io_input_payload_data         (control_payload_data[31:0]                     ), //i
    .io_outputs_0_valid            (control_fork_io_outputs_0_valid                ), //o
    .io_outputs_0_ready            (control_fork_io_outputs_0_ready                ), //i
    .io_outputs_0_payload_command  (control_fork_io_outputs_0_payload_command[2:0] ), //o
    .io_outputs_0_payload_engineId (control_fork_io_outputs_0_payload_engineId[1:0]), //o
    .io_outputs_0_payload_vPifoId  (control_fork_io_outputs_0_payload_vPifoId[2:0] ), //o
    .io_outputs_0_payload_flowId   (control_fork_io_outputs_0_payload_flowId[4:0]  ), //o
    .io_outputs_0_payload_data     (control_fork_io_outputs_0_payload_data[31:0]   ), //o
    .io_outputs_1_valid            (control_fork_io_outputs_1_valid                ), //o
    .io_outputs_1_ready            (control_fork_io_outputs_1_ready                ), //i
    .io_outputs_1_payload_command  (control_fork_io_outputs_1_payload_command[2:0] ), //o
    .io_outputs_1_payload_engineId (control_fork_io_outputs_1_payload_engineId[1:0]), //o
    .io_outputs_1_payload_vPifoId  (control_fork_io_outputs_1_payload_vPifoId[2:0] ), //o
    .io_outputs_1_payload_flowId   (control_fork_io_outputs_1_payload_flowId[4:0]  ), //o
    .io_outputs_1_payload_data     (control_fork_io_outputs_1_payload_data[31:0]   ), //o
    .io_outputs_2_valid            (control_fork_io_outputs_2_valid                ), //o
    .io_outputs_2_ready            (control_fork_io_outputs_2_ready                ), //i
    .io_outputs_2_payload_command  (control_fork_io_outputs_2_payload_command[2:0] ), //o
    .io_outputs_2_payload_engineId (control_fork_io_outputs_2_payload_engineId[1:0]), //o
    .io_outputs_2_payload_vPifoId  (control_fork_io_outputs_2_payload_vPifoId[2:0] ), //o
    .io_outputs_2_payload_flowId   (control_fork_io_outputs_2_payload_flowId[4:0]  ), //o
    .io_outputs_2_payload_data     (control_fork_io_outputs_2_payload_data[31:0]   ), //o
    .clk                           (clk                                            ), //i
    .reset                         (reset                                          )  //i
  );
  `ifndef SYNTHESIS
  always @(*) begin
    case(io_control_payload_command)
      ControlCommand_UpdateMapperPre : io_control_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_control_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_control_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_control_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_control_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_control_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_control_payload_command_string = "UpdateBrainFlowState";
      default : io_control_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(control_payload_command)
      ControlCommand_UpdateMapperPre : control_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : control_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : control_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : control_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : control_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : control_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : control_payload_command_string = "UpdateBrainFlowState";
      default : control_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(brainControl_payload_command)
      ControlCommand_UpdateMapperPre : brainControl_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : brainControl_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : brainControl_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : brainControl_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : brainControl_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : brainControl_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : brainControl_payload_command_string = "UpdateBrainFlowState";
      default : brainControl_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(commitControl_payload_command)
      ControlCommand_UpdateMapperPre : commitControl_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : commitControl_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : commitControl_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : commitControl_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : commitControl_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : commitControl_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : commitControl_payload_command_string = "UpdateBrainFlowState";
      default : commitControl_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(control_fork_io_outputs_0_takeWhen_payload_command)
      ControlCommand_UpdateMapperPre : control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : control_fork_io_outputs_0_takeWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateBrainFlowState";
      default : control_fork_io_outputs_0_takeWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(control_fork_io_outputs_1_takeWhen_payload_command)
      ControlCommand_UpdateMapperPre : control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : control_fork_io_outputs_1_takeWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateBrainFlowState";
      default : control_fork_io_outputs_1_takeWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(control_fork_io_outputs_2_takeWhen_payload_command)
      ControlCommand_UpdateMapperPre : control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : control_fork_io_outputs_2_takeWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateBrainFlowState";
      default : control_fork_io_outputs_2_takeWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(commit_payload_command)
      ControlCommand_UpdateMapperPre : commit_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : commit_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : commit_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : commit_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : commit_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : commit_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : commit_payload_command_string = "UpdateBrainFlowState";
      default : commit_payload_command_string = "????????????????????";
    endcase
  end
  `endif

  assign io_pifo_push1_valid = pifos_boundary_push1_valid;
  assign io_pifo_push1_payload_priority = pifos_boundary_push1_payload_priority;
  assign io_pifo_push1_payload_data = pifos_boundary_push1_payload_data;
  assign io_pifo_push1_payload_port = pifos_boundary_push1_payload_port;
  assign io_pifo_push2_valid = pifos_boundary_push2_valid;
  assign io_pifo_push2_payload_priority = pifos_boundary_push2_payload_priority;
  assign io_pifo_push2_payload_data = pifos_boundary_push2_payload_data;
  assign io_pifo_push2_payload_port = pifos_boundary_push2_payload_port;
  assign io_pifo_popRequest_valid = pifos_boundary_popRequest_valid;
  assign io_pifo_popRequest_payload_port = pifos_boundary_popRequest_payload_port;
  always @(*) begin
    io_enqueRequest_ready = 1'b1;
    if(when_Stream_l1253) begin
      io_enqueRequest_ready = 1'b0;
    end
    if(when_Stream_l1253_1) begin
      io_enqueRequest_ready = 1'b0;
    end
  end

  assign when_Stream_l1253 = ((! enque_mapperRead_ready) && io_enqueRequest_fork2_logic_linkEnable_0);
  assign when_Stream_l1253_1 = ((! enque_flowIdStream_ready) && io_enqueRequest_fork2_logic_linkEnable_1);
  assign enque_mapperRead_valid = (io_enqueRequest_valid && io_enqueRequest_fork2_logic_linkEnable_0);
  assign enque_mapperRead_payload_engineId = io_enqueRequest_payload_engineId;
  assign enque_mapperRead_payload_vPifoId = io_enqueRequest_payload_vPifoId;
  assign enque_mapperRead_fire = (enque_mapperRead_valid && enque_mapperRead_ready);
  assign enque_flowIdStream_valid = (io_enqueRequest_valid && io_enqueRequest_fork2_logic_linkEnable_1);
  assign enque_flowIdStream_payload_engineId = io_enqueRequest_payload_engineId;
  assign enque_flowIdStream_payload_vPifoId = io_enqueRequest_payload_vPifoId;
  assign enque_flowIdStream_fire = (enque_flowIdStream_valid && enque_flowIdStream_ready);
  assign enque_mapperRead_map_valid = enque_mapperRead_valid;
  assign enque_mapperRead_ready = enque_mapperRead_map_ready;
  assign enque_mapperRead_map_payload = enque_mapperRead_payload_vPifoId;
  assign enque_mapperRead_map_ready = 1'b1;
  assign enque_mapperRead_map_toFlow_valid = enque_mapperRead_map_valid;
  assign enque_mapperRead_map_toFlow_payload = enque_mapperRead_map_payload;
  assign enque_enqueMapper_io_readRes_toStream_valid = enque_enqueMapper_io_readRes_valid;
  assign enque_enqueMapper_io_readRes_toStream_payload = enque_enqueMapper_io_readRes_payload;
  assign enque_flowIdStream_ready = enque_flowIdStream_fifo_io_push_ready;
  assign _zz_enque_brainInput_valid = (enque_enqueMapper_io_readRes_toStream_valid && enque_flowIdStream_fifo_io_pop_valid);
  assign _zz_enque_enqueMapper_io_readRes_toStream_ready = (_zz_enque_brainInput_valid && enque_brainInput_ready);
  assign enque_enqueMapper_io_readRes_toStream_ready = _zz_enque_enqueMapper_io_readRes_toStream_ready;
  assign enque_brainInput_valid = _zz_enque_brainInput_valid;
  assign enque_brainInput_payload_vpifoId = enque_enqueMapper_io_readRes_toStream_payload;
  assign enque_brainInput_payload_flowId = {enque_flowIdStream_fifo_io_pop_payload_engineId,enque_flowIdStream_fifo_io_pop_payload_vPifoId};
  assign enque_brainInput_ready = enque_brain_io_request_ready;
  assign enque_brain_io_response_toFlow_valid = enque_brain_io_response_valid;
  assign enque_brain_io_response_toFlow_payload_priority = enque_brain_io_response_payload_priority;
  assign enque_brain_io_response_toFlow_payload_data = enque_brain_io_response_payload_data;
  assign enque_brain_io_response_toFlow_payload_port = enque_brain_io_response_payload_port;
  assign deque_frontPort = (deque_frontRewrite_io_lookupEnabled ? deque_frontRewrite_io_lookupTarget : io_dequeueRequest_payload_vPifoId);
  assign deque_frontRewrite_io_emptySource_valid = ((io_dequeueRequest_valid && deque_frontRewrite_io_lookupCanEnable) && pifos_io_popPortEmpty);
  assign deque_enablingRewrite = (deque_frontRewrite_io_drainEnablesRewrite || deque_frontRewrite_io_emptyEnablesRewrite);
  assign pifos_io_popRequest_valid = (io_dequeueRequest_valid && (! deque_enablingRewrite));
  assign io_dequeueRequest_ready = (! deque_enablingRewrite);
  assign pifos_io_popResponse_toStream_valid = pifos_io_popResponse_valid;
  assign pifos_io_popResponse_toStream_payload_exist = pifos_io_popResponse_payload_exist;
  assign pifos_io_popResponse_toStream_payload_priority = pifos_io_popResponse_payload_priority;
  assign pifos_io_popResponse_toStream_payload_data = pifos_io_popResponse_payload_data;
  assign pifos_io_popResponse_toStream_payload_port = pifos_io_popResponse_payload_port;
  assign when_Stream_l581 = (! pifos_io_popResponse_payload_exist);
  always @(*) begin
    deque_existingPop_valid = pifos_io_popResponse_toStream_valid;
    if(when_Stream_l581) begin
      deque_existingPop_valid = 1'b0;
    end
  end

  always @(*) begin
    pifos_io_popResponse_toStream_ready = deque_existingPop_ready;
    if(when_Stream_l581) begin
      pifos_io_popResponse_toStream_ready = 1'b1;
    end
  end

  assign deque_existingPop_payload_exist = pifos_io_popResponse_toStream_payload_exist;
  assign deque_existingPop_payload_priority = pifos_io_popResponse_toStream_payload_priority;
  assign deque_existingPop_payload_data = pifos_io_popResponse_toStream_payload_data;
  assign deque_existingPop_payload_port = pifos_io_popResponse_toStream_payload_port;
  assign deque_existingPop_ready = deque_existingPop_fork_io_input_ready;
  assign deque_existingPop_fork_io_outputs_0_toFlow_valid = deque_existingPop_fork_io_outputs_0_valid;
  assign deque_existingPop_fork_io_outputs_0_toFlow_payload_exist = deque_existingPop_fork_io_outputs_0_payload_exist;
  assign deque_existingPop_fork_io_outputs_0_toFlow_payload_priority = deque_existingPop_fork_io_outputs_0_payload_priority;
  assign deque_existingPop_fork_io_outputs_0_toFlow_payload_data = deque_existingPop_fork_io_outputs_0_payload_data;
  assign deque_existingPop_fork_io_outputs_0_toFlow_payload_port = deque_existingPop_fork_io_outputs_0_payload_port;
  assign deque_existingPop_fork_io_outputs_1_map_valid = deque_existingPop_fork_io_outputs_1_valid;
  assign deque_existingPop_fork_io_outputs_1_map_payload = {deque_existingPop_fork_io_outputs_1_payload_port,deque_existingPop_fork_io_outputs_1_payload_data};
  assign deque_existingPop_fork_io_outputs_1_map_ready = 1'b1;
  assign deque_existingPop_fork_io_outputs_1_map_toFlow_valid = deque_existingPop_fork_io_outputs_1_map_valid;
  assign deque_existingPop_fork_io_outputs_1_map_toFlow_payload = deque_existingPop_fork_io_outputs_1_map_payload;
  assign deque_dequeMapper_io_readRes_toStream_valid = deque_dequeMapper_io_readRes_valid;
  assign deque_dequeMapper_io_readRes_toStream_payload = deque_dequeMapper_io_readRes_payload;
  assign _zz_deque_dequeMapper_io_readRes_toStream_ready = (_zz_io_dequeueResponse_valid && io_dequeueResponse_ready);
  assign _zz_io_dequeueResponse_valid = (deque_dequeMapper_io_readRes_toStream_valid && io_outputs_2_fifo_io_pop_valid);
  assign deque_dequeMapper_io_readRes_toStream_ready = _zz_deque_dequeMapper_io_readRes_toStream_ready;
  assign io_dequeueResponse_valid = _zz_io_dequeueResponse_valid;
  assign io_dequeueResponse_payload_engineId = deque_dequeMapper_io_readRes_payload[4 : 3];
  assign io_dequeueResponse_payload_vPifoId = deque_dequeMapper_io_readRes_payload[2 : 0];
  assign mapperCommitReady = (enque_enqueMapper_io_commitReady && deque_dequeMapper_io_commitReady);
  assign io_commitReady = mapperCommitReady;
  always @(*) begin
    io_control_ready = 1'b1;
    if(when_Stream_l1253_2) begin
      io_control_ready = 1'b0;
    end
    if(when_Stream_l1253_3) begin
      io_control_ready = 1'b0;
    end
    if(when_Stream_l1253_4) begin
      io_control_ready = 1'b0;
    end
  end

  assign when_Stream_l1253_2 = ((! control_ready) && io_control_fork3_logic_linkEnable_0);
  assign when_Stream_l1253_3 = ((! brainControl_ready) && io_control_fork3_logic_linkEnable_1);
  assign when_Stream_l1253_4 = ((! commitControl_ready) && io_control_fork3_logic_linkEnable_2);
  assign control_valid = (io_control_valid && io_control_fork3_logic_linkEnable_0);
  assign control_payload_command = io_control_payload_command;
  assign control_payload_engineId = io_control_payload_engineId;
  assign control_payload_vPifoId = io_control_payload_vPifoId;
  assign control_payload_flowId = io_control_payload_flowId;
  assign control_payload_data = io_control_payload_data;
  assign control_fire = (control_valid && control_ready);
  assign brainControl_valid = (io_control_valid && io_control_fork3_logic_linkEnable_1);
  assign brainControl_payload_command = io_control_payload_command;
  assign brainControl_payload_engineId = io_control_payload_engineId;
  assign brainControl_payload_vPifoId = io_control_payload_vPifoId;
  assign brainControl_payload_flowId = io_control_payload_flowId;
  assign brainControl_payload_data = io_control_payload_data;
  assign brainControl_fire = (brainControl_valid && brainControl_ready);
  assign commitControl_valid = (io_control_valid && io_control_fork3_logic_linkEnable_2);
  assign commitControl_payload_command = io_control_payload_command;
  assign commitControl_payload_engineId = io_control_payload_engineId;
  assign commitControl_payload_vPifoId = io_control_payload_vPifoId;
  assign commitControl_payload_flowId = io_control_payload_flowId;
  assign commitControl_payload_data = io_control_payload_data;
  assign commitControl_fire = (commitControl_valid && commitControl_ready);
  assign control_ready = control_fork_io_input_ready;
  assign when_Stream_l581_1 = (! (control_fork_io_outputs_0_payload_command == ControlCommand_UpdateMapperPre));
  always @(*) begin
    control_fork_io_outputs_0_takeWhen_valid = control_fork_io_outputs_0_valid;
    if(when_Stream_l581_1) begin
      control_fork_io_outputs_0_takeWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    control_fork_io_outputs_0_ready = control_fork_io_outputs_0_takeWhen_ready;
    if(when_Stream_l581_1) begin
      control_fork_io_outputs_0_ready = 1'b1;
    end
  end

  assign control_fork_io_outputs_0_takeWhen_payload_command = control_fork_io_outputs_0_payload_command;
  assign control_fork_io_outputs_0_takeWhen_payload_engineId = control_fork_io_outputs_0_payload_engineId;
  assign control_fork_io_outputs_0_takeWhen_payload_vPifoId = control_fork_io_outputs_0_payload_vPifoId;
  assign control_fork_io_outputs_0_takeWhen_payload_flowId = control_fork_io_outputs_0_payload_flowId;
  assign control_fork_io_outputs_0_takeWhen_payload_data = control_fork_io_outputs_0_payload_data;
  assign control_fork_io_outputs_0_takeWhen_ready = enque_enqueMapper_io_writeReq_ready;
  assign enque_enqueMapper_io_writeReq_payload_outputId = control_fork_io_outputs_0_takeWhen_payload_data[2:0];
  assign when_Stream_l581_2 = (! (control_fork_io_outputs_1_payload_command == ControlCommand_UpdateMapperPost));
  always @(*) begin
    control_fork_io_outputs_1_takeWhen_valid = control_fork_io_outputs_1_valid;
    if(when_Stream_l581_2) begin
      control_fork_io_outputs_1_takeWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    control_fork_io_outputs_1_ready = control_fork_io_outputs_1_takeWhen_ready;
    if(when_Stream_l581_2) begin
      control_fork_io_outputs_1_ready = 1'b1;
    end
  end

  assign control_fork_io_outputs_1_takeWhen_payload_command = control_fork_io_outputs_1_payload_command;
  assign control_fork_io_outputs_1_takeWhen_payload_engineId = control_fork_io_outputs_1_payload_engineId;
  assign control_fork_io_outputs_1_takeWhen_payload_vPifoId = control_fork_io_outputs_1_payload_vPifoId;
  assign control_fork_io_outputs_1_takeWhen_payload_flowId = control_fork_io_outputs_1_payload_flowId;
  assign control_fork_io_outputs_1_takeWhen_payload_data = control_fork_io_outputs_1_payload_data;
  assign control_fork_io_outputs_1_takeWhen_ready = deque_dequeMapper_io_writeReq_ready;
  assign deque_dequeMapper_io_writeReq_payload_inputId = {control_fork_io_outputs_1_takeWhen_payload_vPifoId,control_fork_io_outputs_1_takeWhen_payload_flowId};
  assign deque_dequeMapper_io_writeReq_payload_outputId = control_fork_io_outputs_1_takeWhen_payload_data[4:0];
  assign when_Stream_l581_3 = (! (control_fork_io_outputs_2_payload_command == ControlCommand_UpdateMapperNonExist));
  always @(*) begin
    control_fork_io_outputs_2_takeWhen_valid = control_fork_io_outputs_2_valid;
    if(when_Stream_l581_3) begin
      control_fork_io_outputs_2_takeWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    control_fork_io_outputs_2_ready = control_fork_io_outputs_2_takeWhen_ready;
    if(when_Stream_l581_3) begin
      control_fork_io_outputs_2_ready = 1'b1;
    end
  end

  assign control_fork_io_outputs_2_takeWhen_payload_command = control_fork_io_outputs_2_payload_command;
  assign control_fork_io_outputs_2_takeWhen_payload_engineId = control_fork_io_outputs_2_payload_engineId;
  assign control_fork_io_outputs_2_takeWhen_payload_vPifoId = control_fork_io_outputs_2_payload_vPifoId;
  assign control_fork_io_outputs_2_takeWhen_payload_flowId = control_fork_io_outputs_2_payload_flowId;
  assign control_fork_io_outputs_2_takeWhen_payload_data = control_fork_io_outputs_2_payload_data;
  assign control_fork_io_outputs_2_takeWhen_ready = deque_frontRewrite_io_writeReq_ready;
  assign deque_frontRewrite_io_writeReq_payload_outputId = control_fork_io_outputs_2_takeWhen_payload_data[2 : 0];
  assign brainControl_ready = enque_brain_io_control_ready;
  assign when_Stream_l581_4 = (! (commitControl_payload_command == ControlCommand_CommitMapper));
  always @(*) begin
    commit_valid = commitControl_valid;
    if(when_Stream_l581_4) begin
      commit_valid = 1'b0;
    end
  end

  always @(*) begin
    commitControl_ready = commit_ready;
    if(when_Stream_l581_4) begin
      commitControl_ready = 1'b1;
    end
  end

  assign commit_payload_command = commitControl_payload_command;
  assign commit_payload_engineId = commitControl_payload_engineId;
  assign commit_payload_vPifoId = commitControl_payload_vPifoId;
  assign commit_payload_flowId = commitControl_payload_flowId;
  assign commit_payload_data = commitControl_payload_data;
  assign commit_ready = mapperCommitReady;
  assign commitPulse = (commit_valid && commit_ready);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      io_enqueRequest_fork2_logic_linkEnable_0 <= 1'b1;
      io_enqueRequest_fork2_logic_linkEnable_1 <= 1'b1;
      io_control_fork3_logic_linkEnable_0 <= 1'b1;
      io_control_fork3_logic_linkEnable_1 <= 1'b1;
      io_control_fork3_logic_linkEnable_2 <= 1'b1;
    end else begin
      if(enque_mapperRead_fire) begin
        io_enqueRequest_fork2_logic_linkEnable_0 <= 1'b0;
      end
      if(enque_flowIdStream_fire) begin
        io_enqueRequest_fork2_logic_linkEnable_1 <= 1'b0;
      end
      if(io_enqueRequest_ready) begin
        io_enqueRequest_fork2_logic_linkEnable_0 <= 1'b1;
        io_enqueRequest_fork2_logic_linkEnable_1 <= 1'b1;
      end
      if(control_fire) begin
        io_control_fork3_logic_linkEnable_0 <= 1'b0;
      end
      if(brainControl_fire) begin
        io_control_fork3_logic_linkEnable_1 <= 1'b0;
      end
      if(commitControl_fire) begin
        io_control_fork3_logic_linkEnable_2 <= 1'b0;
      end
      if(io_control_ready) begin
        io_control_fork3_logic_linkEnable_0 <= 1'b1;
        io_control_fork3_logic_linkEnable_1 <= 1'b1;
        io_control_fork3_logic_linkEnable_2 <= 1'b1;
      end
    end
  end


endmodule

module PifoEngine (
  input  wire          io_enqueRequest_valid,
  output reg           io_enqueRequest_ready,
  input  wire [1:0]    io_enqueRequest_payload_engineId,
  input  wire [2:0]    io_enqueRequest_payload_vPifoId,
  input  wire          io_dequeueRequest_valid,
  output wire          io_dequeueRequest_ready,
  input  wire [1:0]    io_dequeueRequest_payload_engineId,
  input  wire [2:0]    io_dequeueRequest_payload_vPifoId,
  output wire          io_dequeueResponse_valid,
  input  wire          io_dequeueResponse_ready,
  output wire [1:0]    io_dequeueResponse_payload_engineId,
  output wire [2:0]    io_dequeueResponse_payload_vPifoId,
  input  wire          io_control_valid,
  output reg           io_control_ready,
  input  wire [2:0]    io_control_payload_command,
  input  wire [1:0]    io_control_payload_engineId,
  input  wire [2:0]    io_control_payload_vPifoId,
  input  wire [4:0]    io_control_payload_flowId,
  input  wire [31:0]   io_control_payload_data,
  output wire          io_commitReady,
  output wire          io_pifo_push1_valid,
  output wire [7:0]    io_pifo_push1_payload_priority,
  output wire [4:0]    io_pifo_push1_payload_data,
  output wire [2:0]    io_pifo_push1_payload_port,
  output wire          io_pifo_push2_valid,
  output wire [7:0]    io_pifo_push2_payload_priority,
  output wire [4:0]    io_pifo_push2_payload_data,
  output wire [2:0]    io_pifo_push2_payload_port,
  output wire          io_pifo_popRequest_valid,
  output wire [2:0]    io_pifo_popRequest_payload_port,
  input  wire          io_pifo_popResponse_valid,
  input  wire          io_pifo_popResponse_payload_exist,
  input  wire [7:0]    io_pifo_popResponse_payload_priority,
  input  wire [4:0]    io_pifo_popResponse_payload_data,
  input  wire [2:0]    io_pifo_popResponse_payload_port,
  input  wire          io_pifo_popPortEmpty,
  input  wire          io_pifo_portDrained_valid,
  input  wire [2:0]    io_pifo_portDrained_payload,
  input  wire          clk,
  input  wire          reset
);
  localparam ControlCommand_UpdateMapperPre = 3'd0;
  localparam ControlCommand_UpdateMapperPost = 3'd1;
  localparam ControlCommand_UpdateMapperNonExist = 3'd2;
  localparam ControlCommand_CommitMapper = 3'd3;
  localparam ControlCommand_UpdateBrainEngine = 3'd4;
  localparam ControlCommand_UpdateBrainState = 3'd5;
  localparam ControlCommand_UpdateBrainFlowState = 3'd6;

  wire                pifos_io_popRequest_valid;
  wire       [2:0]    enque_enqueMapper_io_writeReq_payload_outputId;
  wire       [7:0]    deque_dequeMapper_io_writeReq_payload_inputId;
  wire       [4:0]    deque_dequeMapper_io_writeReq_payload_outputId;
  wire                deque_frontRewrite_io_emptySource_valid;
  wire       [2:0]    deque_frontRewrite_io_writeReq_payload_outputId;
  reg                 control_fork_io_outputs_0_ready;
  reg                 control_fork_io_outputs_1_ready;
  reg                 control_fork_io_outputs_2_ready;
  wire                pifos_io_popResponse_valid;
  wire                pifos_io_popResponse_payload_exist;
  wire       [7:0]    pifos_io_popResponse_payload_priority;
  wire       [4:0]    pifos_io_popResponse_payload_data;
  wire       [2:0]    pifos_io_popResponse_payload_port;
  wire                pifos_io_popPortEmpty;
  wire                pifos_io_portDrained_valid;
  wire       [2:0]    pifos_io_portDrained_payload;
  wire                pifos_boundary_push1_valid;
  wire       [7:0]    pifos_boundary_push1_payload_priority;
  wire       [4:0]    pifos_boundary_push1_payload_data;
  wire       [2:0]    pifos_boundary_push1_payload_port;
  wire                pifos_boundary_push2_valid;
  wire       [7:0]    pifos_boundary_push2_payload_priority;
  wire       [4:0]    pifos_boundary_push2_payload_data;
  wire       [2:0]    pifos_boundary_push2_payload_port;
  wire                pifos_boundary_popRequest_valid;
  wire       [2:0]    pifos_boundary_popRequest_payload_port;
  wire                enque_enqueMapper_io_readRes_valid;
  wire       [2:0]    enque_enqueMapper_io_readRes_payload;
  wire                enque_enqueMapper_io_writeReq_ready;
  wire                enque_enqueMapper_io_commitReady;
  wire                enque_flowIdStream_fifo_io_push_ready;
  wire                enque_flowIdStream_fifo_io_pop_valid;
  wire       [1:0]    enque_flowIdStream_fifo_io_pop_payload_engineId;
  wire       [2:0]    enque_flowIdStream_fifo_io_pop_payload_vPifoId;
  wire       [1:0]    enque_flowIdStream_fifo_io_occupancy;
  wire       [1:0]    enque_flowIdStream_fifo_io_availability;
  wire                enque_brain_io_request_ready;
  wire                enque_brain_io_response_valid;
  wire       [7:0]    enque_brain_io_response_payload_priority;
  wire       [4:0]    enque_brain_io_response_payload_data;
  wire       [2:0]    enque_brain_io_response_payload_port;
  wire                enque_brain_io_control_ready;
  wire                deque_dequeMapper_io_readRes_valid;
  wire       [4:0]    deque_dequeMapper_io_readRes_payload;
  wire                deque_dequeMapper_io_writeReq_ready;
  wire                deque_dequeMapper_io_commitReady;
  wire       [2:0]    deque_frontRewrite_io_lookupTarget;
  wire                deque_frontRewrite_io_lookupEnabled;
  wire                deque_frontRewrite_io_lookupCanEnable;
  wire                deque_frontRewrite_io_drainEnablesRewrite;
  wire                deque_frontRewrite_io_emptyEnablesRewrite;
  wire                deque_frontRewrite_io_writeReq_ready;
  wire                deque_existingPop_fork_io_input_ready;
  wire                deque_existingPop_fork_io_outputs_0_valid;
  wire                deque_existingPop_fork_io_outputs_0_payload_exist;
  wire       [7:0]    deque_existingPop_fork_io_outputs_0_payload_priority;
  wire       [4:0]    deque_existingPop_fork_io_outputs_0_payload_data;
  wire       [2:0]    deque_existingPop_fork_io_outputs_0_payload_port;
  wire                deque_existingPop_fork_io_outputs_1_valid;
  wire                deque_existingPop_fork_io_outputs_1_payload_exist;
  wire       [7:0]    deque_existingPop_fork_io_outputs_1_payload_priority;
  wire       [4:0]    deque_existingPop_fork_io_outputs_1_payload_data;
  wire       [2:0]    deque_existingPop_fork_io_outputs_1_payload_port;
  wire                deque_existingPop_fork_io_outputs_2_valid;
  wire                deque_existingPop_fork_io_outputs_2_payload_exist;
  wire       [7:0]    deque_existingPop_fork_io_outputs_2_payload_priority;
  wire       [4:0]    deque_existingPop_fork_io_outputs_2_payload_data;
  wire       [2:0]    deque_existingPop_fork_io_outputs_2_payload_port;
  wire                io_outputs_2_fifo_io_push_ready;
  wire                io_outputs_2_fifo_io_pop_valid;
  wire                io_outputs_2_fifo_io_pop_payload_exist;
  wire       [7:0]    io_outputs_2_fifo_io_pop_payload_priority;
  wire       [4:0]    io_outputs_2_fifo_io_pop_payload_data;
  wire       [2:0]    io_outputs_2_fifo_io_pop_payload_port;
  wire       [1:0]    io_outputs_2_fifo_io_occupancy;
  wire       [1:0]    io_outputs_2_fifo_io_availability;
  wire                control_fork_io_input_ready;
  wire                control_fork_io_outputs_0_valid;
  wire       [2:0]    control_fork_io_outputs_0_payload_command;
  wire       [1:0]    control_fork_io_outputs_0_payload_engineId;
  wire       [2:0]    control_fork_io_outputs_0_payload_vPifoId;
  wire       [4:0]    control_fork_io_outputs_0_payload_flowId;
  wire       [31:0]   control_fork_io_outputs_0_payload_data;
  wire                control_fork_io_outputs_1_valid;
  wire       [2:0]    control_fork_io_outputs_1_payload_command;
  wire       [1:0]    control_fork_io_outputs_1_payload_engineId;
  wire       [2:0]    control_fork_io_outputs_1_payload_vPifoId;
  wire       [4:0]    control_fork_io_outputs_1_payload_flowId;
  wire       [31:0]   control_fork_io_outputs_1_payload_data;
  wire                control_fork_io_outputs_2_valid;
  wire       [2:0]    control_fork_io_outputs_2_payload_command;
  wire       [1:0]    control_fork_io_outputs_2_payload_engineId;
  wire       [2:0]    control_fork_io_outputs_2_payload_vPifoId;
  wire       [4:0]    control_fork_io_outputs_2_payload_flowId;
  wire       [31:0]   control_fork_io_outputs_2_payload_data;
  wire                enque_mapperRead_valid;
  wire                enque_mapperRead_ready;
  wire       [1:0]    enque_mapperRead_payload_engineId;
  wire       [2:0]    enque_mapperRead_payload_vPifoId;
  wire                enque_flowIdStream_valid;
  wire                enque_flowIdStream_ready;
  wire       [1:0]    enque_flowIdStream_payload_engineId;
  wire       [2:0]    enque_flowIdStream_payload_vPifoId;
  reg                 io_enqueRequest_fork2_logic_linkEnable_0;
  reg                 io_enqueRequest_fork2_logic_linkEnable_1;
  wire                when_Stream_l1253;
  wire                when_Stream_l1253_1;
  wire                enque_mapperRead_fire;
  wire                enque_flowIdStream_fire;
  wire                enque_mapperRead_map_valid;
  wire                enque_mapperRead_map_ready;
  wire       [2:0]    enque_mapperRead_map_payload;
  wire                enque_mapperRead_map_toFlow_valid;
  wire       [2:0]    enque_mapperRead_map_toFlow_payload;
  wire                enque_brainInput_valid;
  wire                enque_brainInput_ready;
  wire       [2:0]    enque_brainInput_payload_vpifoId;
  wire       [4:0]    enque_brainInput_payload_flowId;
  wire                enque_enqueMapper_io_readRes_toStream_valid;
  wire                enque_enqueMapper_io_readRes_toStream_ready;
  wire       [2:0]    enque_enqueMapper_io_readRes_toStream_payload;
  wire                _zz_enque_brainInput_valid;
  wire                _zz_enque_enqueMapper_io_readRes_toStream_ready;
  wire                enque_brain_io_response_toFlow_valid;
  wire       [7:0]    enque_brain_io_response_toFlow_payload_priority;
  wire       [4:0]    enque_brain_io_response_toFlow_payload_data;
  wire       [2:0]    enque_brain_io_response_toFlow_payload_port;
  wire       [2:0]    deque_frontPort;
  wire                deque_enablingRewrite;
  wire                pifos_io_popResponse_toStream_valid;
  reg                 pifos_io_popResponse_toStream_ready;
  wire                pifos_io_popResponse_toStream_payload_exist;
  wire       [7:0]    pifos_io_popResponse_toStream_payload_priority;
  wire       [4:0]    pifos_io_popResponse_toStream_payload_data;
  wire       [2:0]    pifos_io_popResponse_toStream_payload_port;
  wire                when_Stream_l581;
  reg                 deque_existingPop_valid;
  wire                deque_existingPop_ready;
  wire                deque_existingPop_payload_exist;
  wire       [7:0]    deque_existingPop_payload_priority;
  wire       [4:0]    deque_existingPop_payload_data;
  wire       [2:0]    deque_existingPop_payload_port;
  wire                deque_existingPop_fork_io_outputs_0_toFlow_valid;
  wire                deque_existingPop_fork_io_outputs_0_toFlow_payload_exist;
  wire       [7:0]    deque_existingPop_fork_io_outputs_0_toFlow_payload_priority;
  wire       [4:0]    deque_existingPop_fork_io_outputs_0_toFlow_payload_data;
  wire       [2:0]    deque_existingPop_fork_io_outputs_0_toFlow_payload_port;
  wire                deque_existingPop_fork_io_outputs_1_map_valid;
  wire                deque_existingPop_fork_io_outputs_1_map_ready;
  wire       [7:0]    deque_existingPop_fork_io_outputs_1_map_payload;
  wire                deque_existingPop_fork_io_outputs_1_map_toFlow_valid;
  wire       [7:0]    deque_existingPop_fork_io_outputs_1_map_toFlow_payload;
  wire                deque_dequeMapper_io_readRes_toStream_valid;
  wire                deque_dequeMapper_io_readRes_toStream_ready;
  wire       [4:0]    deque_dequeMapper_io_readRes_toStream_payload;
  wire                _zz_io_dequeueResponse_valid;
  wire                _zz_deque_dequeMapper_io_readRes_toStream_ready;
  wire                mapperCommitReady;
  wire                control_valid;
  wire                control_ready;
  wire       [2:0]    control_payload_command;
  wire       [1:0]    control_payload_engineId;
  wire       [2:0]    control_payload_vPifoId;
  wire       [4:0]    control_payload_flowId;
  wire       [31:0]   control_payload_data;
  wire                brainControl_valid;
  wire                brainControl_ready;
  wire       [2:0]    brainControl_payload_command;
  wire       [1:0]    brainControl_payload_engineId;
  wire       [2:0]    brainControl_payload_vPifoId;
  wire       [4:0]    brainControl_payload_flowId;
  wire       [31:0]   brainControl_payload_data;
  wire                commitControl_valid;
  reg                 commitControl_ready;
  wire       [2:0]    commitControl_payload_command;
  wire       [1:0]    commitControl_payload_engineId;
  wire       [2:0]    commitControl_payload_vPifoId;
  wire       [4:0]    commitControl_payload_flowId;
  wire       [31:0]   commitControl_payload_data;
  reg                 io_control_fork3_logic_linkEnable_0;
  reg                 io_control_fork3_logic_linkEnable_1;
  reg                 io_control_fork3_logic_linkEnable_2;
  wire                when_Stream_l1253_2;
  wire                when_Stream_l1253_3;
  wire                when_Stream_l1253_4;
  wire                control_fire;
  wire                brainControl_fire;
  wire                commitControl_fire;
  wire                when_Stream_l581_1;
  reg                 control_fork_io_outputs_0_takeWhen_valid;
  wire                control_fork_io_outputs_0_takeWhen_ready;
  wire       [2:0]    control_fork_io_outputs_0_takeWhen_payload_command;
  wire       [1:0]    control_fork_io_outputs_0_takeWhen_payload_engineId;
  wire       [2:0]    control_fork_io_outputs_0_takeWhen_payload_vPifoId;
  wire       [4:0]    control_fork_io_outputs_0_takeWhen_payload_flowId;
  wire       [31:0]   control_fork_io_outputs_0_takeWhen_payload_data;
  wire                when_Stream_l581_2;
  reg                 control_fork_io_outputs_1_takeWhen_valid;
  wire                control_fork_io_outputs_1_takeWhen_ready;
  wire       [2:0]    control_fork_io_outputs_1_takeWhen_payload_command;
  wire       [1:0]    control_fork_io_outputs_1_takeWhen_payload_engineId;
  wire       [2:0]    control_fork_io_outputs_1_takeWhen_payload_vPifoId;
  wire       [4:0]    control_fork_io_outputs_1_takeWhen_payload_flowId;
  wire       [31:0]   control_fork_io_outputs_1_takeWhen_payload_data;
  wire                when_Stream_l581_3;
  reg                 control_fork_io_outputs_2_takeWhen_valid;
  wire                control_fork_io_outputs_2_takeWhen_ready;
  wire       [2:0]    control_fork_io_outputs_2_takeWhen_payload_command;
  wire       [1:0]    control_fork_io_outputs_2_takeWhen_payload_engineId;
  wire       [2:0]    control_fork_io_outputs_2_takeWhen_payload_vPifoId;
  wire       [4:0]    control_fork_io_outputs_2_takeWhen_payload_flowId;
  wire       [31:0]   control_fork_io_outputs_2_takeWhen_payload_data;
  wire                when_Stream_l581_4;
  reg                 commit_valid;
  wire                commit_ready;
  wire       [2:0]    commit_payload_command;
  wire       [1:0]    commit_payload_engineId;
  wire       [2:0]    commit_payload_vPifoId;
  wire       [4:0]    commit_payload_flowId;
  wire       [31:0]   commit_payload_data;
  wire                commitPulse;
  `ifndef SYNTHESIS
  reg [159:0] io_control_payload_command_string;
  reg [159:0] control_payload_command_string;
  reg [159:0] brainControl_payload_command_string;
  reg [159:0] commitControl_payload_command_string;
  reg [159:0] control_fork_io_outputs_0_takeWhen_payload_command_string;
  reg [159:0] control_fork_io_outputs_1_takeWhen_payload_command_string;
  reg [159:0] control_fork_io_outputs_2_takeWhen_payload_command_string;
  reg [159:0] commit_payload_command_string;
  `endif


  ExternalPifoCore pifos (
    .io_push1_valid                        (enque_brain_io_response_toFlow_valid                ), //i
    .io_push1_payload_priority             (enque_brain_io_response_toFlow_payload_priority[7:0]), //i
    .io_push1_payload_data                 (enque_brain_io_response_toFlow_payload_data[4:0]    ), //i
    .io_push1_payload_port                 (enque_brain_io_response_toFlow_payload_port[2:0]    ), //i
    .io_push2_valid                        (1'b0                                                ), //i
    .io_push2_payload_priority             (8'bxxxxxxxx                                         ), //i
    .io_push2_payload_data                 (5'bxxxxx                                            ), //i
    .io_push2_payload_port                 (3'bxxx                                              ), //i
    .io_popRequest_valid                   (pifos_io_popRequest_valid                           ), //i
    .io_popRequest_payload_port            (deque_frontPort[2:0]                                ), //i
    .io_popResponse_valid                  (pifos_io_popResponse_valid                          ), //o
    .io_popResponse_payload_exist          (pifos_io_popResponse_payload_exist                  ), //o
    .io_popResponse_payload_priority       (pifos_io_popResponse_payload_priority[7:0]          ), //o
    .io_popResponse_payload_data           (pifos_io_popResponse_payload_data[4:0]              ), //o
    .io_popResponse_payload_port           (pifos_io_popResponse_payload_port[2:0]              ), //o
    .io_popPortEmpty                       (pifos_io_popPortEmpty                               ), //o
    .io_portDrained_valid                  (pifos_io_portDrained_valid                          ), //o
    .io_portDrained_payload                (pifos_io_portDrained_payload[2:0]                   ), //o
    .boundary_push1_valid                  (pifos_boundary_push1_valid                          ), //o
    .boundary_push1_payload_priority       (pifos_boundary_push1_payload_priority[7:0]          ), //o
    .boundary_push1_payload_data           (pifos_boundary_push1_payload_data[4:0]              ), //o
    .boundary_push1_payload_port           (pifos_boundary_push1_payload_port[2:0]              ), //o
    .boundary_push2_valid                  (pifos_boundary_push2_valid                          ), //o
    .boundary_push2_payload_priority       (pifos_boundary_push2_payload_priority[7:0]          ), //o
    .boundary_push2_payload_data           (pifos_boundary_push2_payload_data[4:0]              ), //o
    .boundary_push2_payload_port           (pifos_boundary_push2_payload_port[2:0]              ), //o
    .boundary_popRequest_valid             (pifos_boundary_popRequest_valid                     ), //o
    .boundary_popRequest_payload_port      (pifos_boundary_popRequest_payload_port[2:0]         ), //o
    .boundary_popResponse_valid            (io_pifo_popResponse_valid                           ), //i
    .boundary_popResponse_payload_exist    (io_pifo_popResponse_payload_exist                   ), //i
    .boundary_popResponse_payload_priority (io_pifo_popResponse_payload_priority[7:0]           ), //i
    .boundary_popResponse_payload_data     (io_pifo_popResponse_payload_data[4:0]               ), //i
    .boundary_popResponse_payload_port     (io_pifo_popResponse_payload_port[2:0]               ), //i
    .boundary_popPortEmpty                 (io_pifo_popPortEmpty                                ), //i
    .boundary_portDrained_valid            (io_pifo_portDrained_valid                           ), //i
    .boundary_portDrained_payload          (io_pifo_portDrained_payload[2:0]                    )  //i
  );
  ReplayMapper enque_enqueMapper (
    .io_readReq_valid             (enque_mapperRead_map_toFlow_valid                      ), //i
    .io_readReq_payload           (enque_mapperRead_map_toFlow_payload[2:0]               ), //i
    .io_readRes_valid             (enque_enqueMapper_io_readRes_valid                     ), //o
    .io_readRes_payload           (enque_enqueMapper_io_readRes_payload[2:0]              ), //o
    .io_writeReq_valid            (control_fork_io_outputs_0_takeWhen_valid               ), //i
    .io_writeReq_ready            (enque_enqueMapper_io_writeReq_ready                    ), //o
    .io_writeReq_payload_inputId  (control_fork_io_outputs_0_takeWhen_payload_vPifoId[2:0]), //i
    .io_writeReq_payload_outputId (enque_enqueMapper_io_writeReq_payload_outputId[2:0]    ), //i
    .io_commit                    (commitPulse                                            ), //i
    .io_commitReady               (enque_enqueMapper_io_commitReady                       ), //o
    .clk                          (clk                                                    ), //i
    .reset                        (reset                                                  )  //i
  );
  StreamFifoLowLatency_10 enque_flowIdStream_fifo (
    .io_push_valid            (enque_flowIdStream_valid                            ), //i
    .io_push_ready            (enque_flowIdStream_fifo_io_push_ready               ), //o
    .io_push_payload_engineId (enque_flowIdStream_payload_engineId[1:0]            ), //i
    .io_push_payload_vPifoId  (enque_flowIdStream_payload_vPifoId[2:0]             ), //i
    .io_pop_valid             (enque_flowIdStream_fifo_io_pop_valid                ), //o
    .io_pop_ready             (_zz_enque_enqueMapper_io_readRes_toStream_ready     ), //i
    .io_pop_payload_engineId  (enque_flowIdStream_fifo_io_pop_payload_engineId[1:0]), //o
    .io_pop_payload_vPifoId   (enque_flowIdStream_fifo_io_pop_payload_vPifoId[2:0] ), //o
    .io_flush                 (1'b0                                                ), //i
    .io_occupancy             (enque_flowIdStream_fifo_io_occupancy[1:0]           ), //o
    .io_availability          (enque_flowIdStream_fifo_io_availability[1:0]        ), //o
    .clk                      (clk                                                 ), //i
    .reset                    (reset                                               )  //i
  );
  PIFOBrain enque_brain (
    .io_request_valid             (enque_brainInput_valid                                          ), //i
    .io_request_ready             (enque_brain_io_request_ready                                    ), //o
    .io_request_payload_vpifoId   (enque_brainInput_payload_vpifoId[2:0]                           ), //i
    .io_request_payload_flowId    (enque_brainInput_payload_flowId[4:0]                            ), //i
    .io_response_valid            (enque_brain_io_response_valid                                   ), //o
    .io_response_ready            (1'b1                                                            ), //i
    .io_response_payload_priority (enque_brain_io_response_payload_priority[7:0]                   ), //o
    .io_response_payload_data     (enque_brain_io_response_payload_data[4:0]                       ), //o
    .io_response_payload_port     (enque_brain_io_response_payload_port[2:0]                       ), //o
    .io_control_valid             (brainControl_valid                                              ), //i
    .io_control_ready             (enque_brain_io_control_ready                                    ), //o
    .io_control_payload_command   (brainControl_payload_command[2:0]                               ), //i
    .io_control_payload_engineId  (brainControl_payload_engineId[1:0]                              ), //i
    .io_control_payload_vPifoId   (brainControl_payload_vPifoId[2:0]                               ), //i
    .io_control_payload_flowId    (brainControl_payload_flowId[4:0]                                ), //i
    .io_control_payload_data      (brainControl_payload_data[31:0]                                 ), //i
    .io_poped_valid               (deque_existingPop_fork_io_outputs_0_toFlow_valid                ), //i
    .io_poped_payload_exist       (deque_existingPop_fork_io_outputs_0_toFlow_payload_exist        ), //i
    .io_poped_payload_priority    (deque_existingPop_fork_io_outputs_0_toFlow_payload_priority[7:0]), //i
    .io_poped_payload_data        (deque_existingPop_fork_io_outputs_0_toFlow_payload_data[4:0]    ), //i
    .io_poped_payload_port        (deque_existingPop_fork_io_outputs_0_toFlow_payload_port[2:0]    ), //i
    .clk                          (clk                                                             ), //i
    .reset                        (reset                                                           )  //i
  );
  ReplayMapper_1 deque_dequeMapper (
    .io_readReq_valid             (deque_existingPop_fork_io_outputs_1_map_toFlow_valid       ), //i
    .io_readReq_payload           (deque_existingPop_fork_io_outputs_1_map_toFlow_payload[7:0]), //i
    .io_readRes_valid             (deque_dequeMapper_io_readRes_valid                         ), //o
    .io_readRes_payload           (deque_dequeMapper_io_readRes_payload[4:0]                  ), //o
    .io_writeReq_valid            (control_fork_io_outputs_1_takeWhen_valid                   ), //i
    .io_writeReq_ready            (deque_dequeMapper_io_writeReq_ready                        ), //o
    .io_writeReq_payload_inputId  (deque_dequeMapper_io_writeReq_payload_inputId[7:0]         ), //i
    .io_writeReq_payload_outputId (deque_dequeMapper_io_writeReq_payload_outputId[4:0]        ), //i
    .io_commit                    (commitPulse                                                ), //i
    .io_commitReady               (deque_dequeMapper_io_commitReady                           ), //o
    .clk                          (clk                                                        ), //i
    .reset                        (reset                                                      )  //i
  );
  FrontRewriteTable deque_frontRewrite (
    .io_lookupSource              (io_dequeueRequest_payload_vPifoId[2:0]                 ), //i
    .io_lookupTarget              (deque_frontRewrite_io_lookupTarget[2:0]                ), //o
    .io_lookupEnabled             (deque_frontRewrite_io_lookupEnabled                    ), //o
    .io_lookupCanEnable           (deque_frontRewrite_io_lookupCanEnable                  ), //o
    .io_drained_valid             (pifos_io_portDrained_valid                             ), //i
    .io_drained_payload           (pifos_io_portDrained_payload[2:0]                      ), //i
    .io_drainEnablesRewrite       (deque_frontRewrite_io_drainEnablesRewrite              ), //o
    .io_emptySource_valid         (deque_frontRewrite_io_emptySource_valid                ), //i
    .io_emptySource_payload       (io_dequeueRequest_payload_vPifoId[2:0]                 ), //i
    .io_emptyEnablesRewrite       (deque_frontRewrite_io_emptyEnablesRewrite              ), //o
    .io_writeReq_valid            (control_fork_io_outputs_2_takeWhen_valid               ), //i
    .io_writeReq_ready            (deque_frontRewrite_io_writeReq_ready                   ), //o
    .io_writeReq_payload_inputId  (control_fork_io_outputs_2_takeWhen_payload_vPifoId[2:0]), //i
    .io_writeReq_payload_outputId (deque_frontRewrite_io_writeReq_payload_outputId[2:0]   ), //i
    .io_commit                    (commitPulse                                            ), //i
    .clk                          (clk                                                    ), //i
    .reset                        (reset                                                  )  //i
  );
  StreamFork_2 deque_existingPop_fork (
    .io_input_valid                (deque_existingPop_valid                                  ), //i
    .io_input_ready                (deque_existingPop_fork_io_input_ready                    ), //o
    .io_input_payload_exist        (deque_existingPop_payload_exist                          ), //i
    .io_input_payload_priority     (deque_existingPop_payload_priority[7:0]                  ), //i
    .io_input_payload_data         (deque_existingPop_payload_data[4:0]                      ), //i
    .io_input_payload_port         (deque_existingPop_payload_port[2:0]                      ), //i
    .io_outputs_0_valid            (deque_existingPop_fork_io_outputs_0_valid                ), //o
    .io_outputs_0_ready            (1'b1                                                     ), //i
    .io_outputs_0_payload_exist    (deque_existingPop_fork_io_outputs_0_payload_exist        ), //o
    .io_outputs_0_payload_priority (deque_existingPop_fork_io_outputs_0_payload_priority[7:0]), //o
    .io_outputs_0_payload_data     (deque_existingPop_fork_io_outputs_0_payload_data[4:0]    ), //o
    .io_outputs_0_payload_port     (deque_existingPop_fork_io_outputs_0_payload_port[2:0]    ), //o
    .io_outputs_1_valid            (deque_existingPop_fork_io_outputs_1_valid                ), //o
    .io_outputs_1_ready            (deque_existingPop_fork_io_outputs_1_map_ready            ), //i
    .io_outputs_1_payload_exist    (deque_existingPop_fork_io_outputs_1_payload_exist        ), //o
    .io_outputs_1_payload_priority (deque_existingPop_fork_io_outputs_1_payload_priority[7:0]), //o
    .io_outputs_1_payload_data     (deque_existingPop_fork_io_outputs_1_payload_data[4:0]    ), //o
    .io_outputs_1_payload_port     (deque_existingPop_fork_io_outputs_1_payload_port[2:0]    ), //o
    .io_outputs_2_valid            (deque_existingPop_fork_io_outputs_2_valid                ), //o
    .io_outputs_2_ready            (io_outputs_2_fifo_io_push_ready                          ), //i
    .io_outputs_2_payload_exist    (deque_existingPop_fork_io_outputs_2_payload_exist        ), //o
    .io_outputs_2_payload_priority (deque_existingPop_fork_io_outputs_2_payload_priority[7:0]), //o
    .io_outputs_2_payload_data     (deque_existingPop_fork_io_outputs_2_payload_data[4:0]    ), //o
    .io_outputs_2_payload_port     (deque_existingPop_fork_io_outputs_2_payload_port[2:0]    ), //o
    .clk                           (clk                                                      ), //i
    .reset                         (reset                                                    )  //i
  );
  StreamFifoLowLatency_11 io_outputs_2_fifo (
    .io_push_valid            (deque_existingPop_fork_io_outputs_2_valid                ), //i
    .io_push_ready            (io_outputs_2_fifo_io_push_ready                          ), //o
    .io_push_payload_exist    (deque_existingPop_fork_io_outputs_2_payload_exist        ), //i
    .io_push_payload_priority (deque_existingPop_fork_io_outputs_2_payload_priority[7:0]), //i
    .io_push_payload_data     (deque_existingPop_fork_io_outputs_2_payload_data[4:0]    ), //i
    .io_push_payload_port     (deque_existingPop_fork_io_outputs_2_payload_port[2:0]    ), //i
    .io_pop_valid             (io_outputs_2_fifo_io_pop_valid                           ), //o
    .io_pop_ready             (_zz_deque_dequeMapper_io_readRes_toStream_ready          ), //i
    .io_pop_payload_exist     (io_outputs_2_fifo_io_pop_payload_exist                   ), //o
    .io_pop_payload_priority  (io_outputs_2_fifo_io_pop_payload_priority[7:0]           ), //o
    .io_pop_payload_data      (io_outputs_2_fifo_io_pop_payload_data[4:0]               ), //o
    .io_pop_payload_port      (io_outputs_2_fifo_io_pop_payload_port[2:0]               ), //o
    .io_flush                 (1'b0                                                     ), //i
    .io_occupancy             (io_outputs_2_fifo_io_occupancy[1:0]                      ), //o
    .io_availability          (io_outputs_2_fifo_io_availability[1:0]                   ), //o
    .clk                      (clk                                                      ), //i
    .reset                    (reset                                                    )  //i
  );
  StreamFork_1 control_fork (
    .io_input_valid                (control_valid                                  ), //i
    .io_input_ready                (control_fork_io_input_ready                    ), //o
    .io_input_payload_command      (control_payload_command[2:0]                   ), //i
    .io_input_payload_engineId     (control_payload_engineId[1:0]                  ), //i
    .io_input_payload_vPifoId      (control_payload_vPifoId[2:0]                   ), //i
    .io_input_payload_flowId       (control_payload_flowId[4:0]                    ), //i
    .io_input_payload_data         (control_payload_data[31:0]                     ), //i
    .io_outputs_0_valid            (control_fork_io_outputs_0_valid                ), //o
    .io_outputs_0_ready            (control_fork_io_outputs_0_ready                ), //i
    .io_outputs_0_payload_command  (control_fork_io_outputs_0_payload_command[2:0] ), //o
    .io_outputs_0_payload_engineId (control_fork_io_outputs_0_payload_engineId[1:0]), //o
    .io_outputs_0_payload_vPifoId  (control_fork_io_outputs_0_payload_vPifoId[2:0] ), //o
    .io_outputs_0_payload_flowId   (control_fork_io_outputs_0_payload_flowId[4:0]  ), //o
    .io_outputs_0_payload_data     (control_fork_io_outputs_0_payload_data[31:0]   ), //o
    .io_outputs_1_valid            (control_fork_io_outputs_1_valid                ), //o
    .io_outputs_1_ready            (control_fork_io_outputs_1_ready                ), //i
    .io_outputs_1_payload_command  (control_fork_io_outputs_1_payload_command[2:0] ), //o
    .io_outputs_1_payload_engineId (control_fork_io_outputs_1_payload_engineId[1:0]), //o
    .io_outputs_1_payload_vPifoId  (control_fork_io_outputs_1_payload_vPifoId[2:0] ), //o
    .io_outputs_1_payload_flowId   (control_fork_io_outputs_1_payload_flowId[4:0]  ), //o
    .io_outputs_1_payload_data     (control_fork_io_outputs_1_payload_data[31:0]   ), //o
    .io_outputs_2_valid            (control_fork_io_outputs_2_valid                ), //o
    .io_outputs_2_ready            (control_fork_io_outputs_2_ready                ), //i
    .io_outputs_2_payload_command  (control_fork_io_outputs_2_payload_command[2:0] ), //o
    .io_outputs_2_payload_engineId (control_fork_io_outputs_2_payload_engineId[1:0]), //o
    .io_outputs_2_payload_vPifoId  (control_fork_io_outputs_2_payload_vPifoId[2:0] ), //o
    .io_outputs_2_payload_flowId   (control_fork_io_outputs_2_payload_flowId[4:0]  ), //o
    .io_outputs_2_payload_data     (control_fork_io_outputs_2_payload_data[31:0]   ), //o
    .clk                           (clk                                            ), //i
    .reset                         (reset                                          )  //i
  );
  `ifndef SYNTHESIS
  always @(*) begin
    case(io_control_payload_command)
      ControlCommand_UpdateMapperPre : io_control_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_control_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_control_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_control_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_control_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_control_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_control_payload_command_string = "UpdateBrainFlowState";
      default : io_control_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(control_payload_command)
      ControlCommand_UpdateMapperPre : control_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : control_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : control_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : control_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : control_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : control_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : control_payload_command_string = "UpdateBrainFlowState";
      default : control_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(brainControl_payload_command)
      ControlCommand_UpdateMapperPre : brainControl_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : brainControl_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : brainControl_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : brainControl_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : brainControl_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : brainControl_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : brainControl_payload_command_string = "UpdateBrainFlowState";
      default : brainControl_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(commitControl_payload_command)
      ControlCommand_UpdateMapperPre : commitControl_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : commitControl_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : commitControl_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : commitControl_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : commitControl_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : commitControl_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : commitControl_payload_command_string = "UpdateBrainFlowState";
      default : commitControl_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(control_fork_io_outputs_0_takeWhen_payload_command)
      ControlCommand_UpdateMapperPre : control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : control_fork_io_outputs_0_takeWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateBrainFlowState";
      default : control_fork_io_outputs_0_takeWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(control_fork_io_outputs_1_takeWhen_payload_command)
      ControlCommand_UpdateMapperPre : control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : control_fork_io_outputs_1_takeWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateBrainFlowState";
      default : control_fork_io_outputs_1_takeWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(control_fork_io_outputs_2_takeWhen_payload_command)
      ControlCommand_UpdateMapperPre : control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : control_fork_io_outputs_2_takeWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateBrainFlowState";
      default : control_fork_io_outputs_2_takeWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(commit_payload_command)
      ControlCommand_UpdateMapperPre : commit_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : commit_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : commit_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : commit_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : commit_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : commit_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : commit_payload_command_string = "UpdateBrainFlowState";
      default : commit_payload_command_string = "????????????????????";
    endcase
  end
  `endif

  assign io_pifo_push1_valid = pifos_boundary_push1_valid;
  assign io_pifo_push1_payload_priority = pifos_boundary_push1_payload_priority;
  assign io_pifo_push1_payload_data = pifos_boundary_push1_payload_data;
  assign io_pifo_push1_payload_port = pifos_boundary_push1_payload_port;
  assign io_pifo_push2_valid = pifos_boundary_push2_valid;
  assign io_pifo_push2_payload_priority = pifos_boundary_push2_payload_priority;
  assign io_pifo_push2_payload_data = pifos_boundary_push2_payload_data;
  assign io_pifo_push2_payload_port = pifos_boundary_push2_payload_port;
  assign io_pifo_popRequest_valid = pifos_boundary_popRequest_valid;
  assign io_pifo_popRequest_payload_port = pifos_boundary_popRequest_payload_port;
  always @(*) begin
    io_enqueRequest_ready = 1'b1;
    if(when_Stream_l1253) begin
      io_enqueRequest_ready = 1'b0;
    end
    if(when_Stream_l1253_1) begin
      io_enqueRequest_ready = 1'b0;
    end
  end

  assign when_Stream_l1253 = ((! enque_mapperRead_ready) && io_enqueRequest_fork2_logic_linkEnable_0);
  assign when_Stream_l1253_1 = ((! enque_flowIdStream_ready) && io_enqueRequest_fork2_logic_linkEnable_1);
  assign enque_mapperRead_valid = (io_enqueRequest_valid && io_enqueRequest_fork2_logic_linkEnable_0);
  assign enque_mapperRead_payload_engineId = io_enqueRequest_payload_engineId;
  assign enque_mapperRead_payload_vPifoId = io_enqueRequest_payload_vPifoId;
  assign enque_mapperRead_fire = (enque_mapperRead_valid && enque_mapperRead_ready);
  assign enque_flowIdStream_valid = (io_enqueRequest_valid && io_enqueRequest_fork2_logic_linkEnable_1);
  assign enque_flowIdStream_payload_engineId = io_enqueRequest_payload_engineId;
  assign enque_flowIdStream_payload_vPifoId = io_enqueRequest_payload_vPifoId;
  assign enque_flowIdStream_fire = (enque_flowIdStream_valid && enque_flowIdStream_ready);
  assign enque_mapperRead_map_valid = enque_mapperRead_valid;
  assign enque_mapperRead_ready = enque_mapperRead_map_ready;
  assign enque_mapperRead_map_payload = enque_mapperRead_payload_vPifoId;
  assign enque_mapperRead_map_ready = 1'b1;
  assign enque_mapperRead_map_toFlow_valid = enque_mapperRead_map_valid;
  assign enque_mapperRead_map_toFlow_payload = enque_mapperRead_map_payload;
  assign enque_enqueMapper_io_readRes_toStream_valid = enque_enqueMapper_io_readRes_valid;
  assign enque_enqueMapper_io_readRes_toStream_payload = enque_enqueMapper_io_readRes_payload;
  assign enque_flowIdStream_ready = enque_flowIdStream_fifo_io_push_ready;
  assign _zz_enque_brainInput_valid = (enque_enqueMapper_io_readRes_toStream_valid && enque_flowIdStream_fifo_io_pop_valid);
  assign _zz_enque_enqueMapper_io_readRes_toStream_ready = (_zz_enque_brainInput_valid && enque_brainInput_ready);
  assign enque_enqueMapper_io_readRes_toStream_ready = _zz_enque_enqueMapper_io_readRes_toStream_ready;
  assign enque_brainInput_valid = _zz_enque_brainInput_valid;
  assign enque_brainInput_payload_vpifoId = enque_enqueMapper_io_readRes_toStream_payload;
  assign enque_brainInput_payload_flowId = {enque_flowIdStream_fifo_io_pop_payload_engineId,enque_flowIdStream_fifo_io_pop_payload_vPifoId};
  assign enque_brainInput_ready = enque_brain_io_request_ready;
  assign enque_brain_io_response_toFlow_valid = enque_brain_io_response_valid;
  assign enque_brain_io_response_toFlow_payload_priority = enque_brain_io_response_payload_priority;
  assign enque_brain_io_response_toFlow_payload_data = enque_brain_io_response_payload_data;
  assign enque_brain_io_response_toFlow_payload_port = enque_brain_io_response_payload_port;
  assign deque_frontPort = (deque_frontRewrite_io_lookupEnabled ? deque_frontRewrite_io_lookupTarget : io_dequeueRequest_payload_vPifoId);
  assign deque_frontRewrite_io_emptySource_valid = ((io_dequeueRequest_valid && deque_frontRewrite_io_lookupCanEnable) && pifos_io_popPortEmpty);
  assign deque_enablingRewrite = (deque_frontRewrite_io_drainEnablesRewrite || deque_frontRewrite_io_emptyEnablesRewrite);
  assign pifos_io_popRequest_valid = (io_dequeueRequest_valid && (! deque_enablingRewrite));
  assign io_dequeueRequest_ready = (! deque_enablingRewrite);
  assign pifos_io_popResponse_toStream_valid = pifos_io_popResponse_valid;
  assign pifos_io_popResponse_toStream_payload_exist = pifos_io_popResponse_payload_exist;
  assign pifos_io_popResponse_toStream_payload_priority = pifos_io_popResponse_payload_priority;
  assign pifos_io_popResponse_toStream_payload_data = pifos_io_popResponse_payload_data;
  assign pifos_io_popResponse_toStream_payload_port = pifos_io_popResponse_payload_port;
  assign when_Stream_l581 = (! pifos_io_popResponse_payload_exist);
  always @(*) begin
    deque_existingPop_valid = pifos_io_popResponse_toStream_valid;
    if(when_Stream_l581) begin
      deque_existingPop_valid = 1'b0;
    end
  end

  always @(*) begin
    pifos_io_popResponse_toStream_ready = deque_existingPop_ready;
    if(when_Stream_l581) begin
      pifos_io_popResponse_toStream_ready = 1'b1;
    end
  end

  assign deque_existingPop_payload_exist = pifos_io_popResponse_toStream_payload_exist;
  assign deque_existingPop_payload_priority = pifos_io_popResponse_toStream_payload_priority;
  assign deque_existingPop_payload_data = pifos_io_popResponse_toStream_payload_data;
  assign deque_existingPop_payload_port = pifos_io_popResponse_toStream_payload_port;
  assign deque_existingPop_ready = deque_existingPop_fork_io_input_ready;
  assign deque_existingPop_fork_io_outputs_0_toFlow_valid = deque_existingPop_fork_io_outputs_0_valid;
  assign deque_existingPop_fork_io_outputs_0_toFlow_payload_exist = deque_existingPop_fork_io_outputs_0_payload_exist;
  assign deque_existingPop_fork_io_outputs_0_toFlow_payload_priority = deque_existingPop_fork_io_outputs_0_payload_priority;
  assign deque_existingPop_fork_io_outputs_0_toFlow_payload_data = deque_existingPop_fork_io_outputs_0_payload_data;
  assign deque_existingPop_fork_io_outputs_0_toFlow_payload_port = deque_existingPop_fork_io_outputs_0_payload_port;
  assign deque_existingPop_fork_io_outputs_1_map_valid = deque_existingPop_fork_io_outputs_1_valid;
  assign deque_existingPop_fork_io_outputs_1_map_payload = {deque_existingPop_fork_io_outputs_1_payload_port,deque_existingPop_fork_io_outputs_1_payload_data};
  assign deque_existingPop_fork_io_outputs_1_map_ready = 1'b1;
  assign deque_existingPop_fork_io_outputs_1_map_toFlow_valid = deque_existingPop_fork_io_outputs_1_map_valid;
  assign deque_existingPop_fork_io_outputs_1_map_toFlow_payload = deque_existingPop_fork_io_outputs_1_map_payload;
  assign deque_dequeMapper_io_readRes_toStream_valid = deque_dequeMapper_io_readRes_valid;
  assign deque_dequeMapper_io_readRes_toStream_payload = deque_dequeMapper_io_readRes_payload;
  assign _zz_deque_dequeMapper_io_readRes_toStream_ready = (_zz_io_dequeueResponse_valid && io_dequeueResponse_ready);
  assign _zz_io_dequeueResponse_valid = (deque_dequeMapper_io_readRes_toStream_valid && io_outputs_2_fifo_io_pop_valid);
  assign deque_dequeMapper_io_readRes_toStream_ready = _zz_deque_dequeMapper_io_readRes_toStream_ready;
  assign io_dequeueResponse_valid = _zz_io_dequeueResponse_valid;
  assign io_dequeueResponse_payload_engineId = deque_dequeMapper_io_readRes_payload[4 : 3];
  assign io_dequeueResponse_payload_vPifoId = deque_dequeMapper_io_readRes_payload[2 : 0];
  assign mapperCommitReady = (enque_enqueMapper_io_commitReady && deque_dequeMapper_io_commitReady);
  assign io_commitReady = mapperCommitReady;
  always @(*) begin
    io_control_ready = 1'b1;
    if(when_Stream_l1253_2) begin
      io_control_ready = 1'b0;
    end
    if(when_Stream_l1253_3) begin
      io_control_ready = 1'b0;
    end
    if(when_Stream_l1253_4) begin
      io_control_ready = 1'b0;
    end
  end

  assign when_Stream_l1253_2 = ((! control_ready) && io_control_fork3_logic_linkEnable_0);
  assign when_Stream_l1253_3 = ((! brainControl_ready) && io_control_fork3_logic_linkEnable_1);
  assign when_Stream_l1253_4 = ((! commitControl_ready) && io_control_fork3_logic_linkEnable_2);
  assign control_valid = (io_control_valid && io_control_fork3_logic_linkEnable_0);
  assign control_payload_command = io_control_payload_command;
  assign control_payload_engineId = io_control_payload_engineId;
  assign control_payload_vPifoId = io_control_payload_vPifoId;
  assign control_payload_flowId = io_control_payload_flowId;
  assign control_payload_data = io_control_payload_data;
  assign control_fire = (control_valid && control_ready);
  assign brainControl_valid = (io_control_valid && io_control_fork3_logic_linkEnable_1);
  assign brainControl_payload_command = io_control_payload_command;
  assign brainControl_payload_engineId = io_control_payload_engineId;
  assign brainControl_payload_vPifoId = io_control_payload_vPifoId;
  assign brainControl_payload_flowId = io_control_payload_flowId;
  assign brainControl_payload_data = io_control_payload_data;
  assign brainControl_fire = (brainControl_valid && brainControl_ready);
  assign commitControl_valid = (io_control_valid && io_control_fork3_logic_linkEnable_2);
  assign commitControl_payload_command = io_control_payload_command;
  assign commitControl_payload_engineId = io_control_payload_engineId;
  assign commitControl_payload_vPifoId = io_control_payload_vPifoId;
  assign commitControl_payload_flowId = io_control_payload_flowId;
  assign commitControl_payload_data = io_control_payload_data;
  assign commitControl_fire = (commitControl_valid && commitControl_ready);
  assign control_ready = control_fork_io_input_ready;
  assign when_Stream_l581_1 = (! (control_fork_io_outputs_0_payload_command == ControlCommand_UpdateMapperPre));
  always @(*) begin
    control_fork_io_outputs_0_takeWhen_valid = control_fork_io_outputs_0_valid;
    if(when_Stream_l581_1) begin
      control_fork_io_outputs_0_takeWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    control_fork_io_outputs_0_ready = control_fork_io_outputs_0_takeWhen_ready;
    if(when_Stream_l581_1) begin
      control_fork_io_outputs_0_ready = 1'b1;
    end
  end

  assign control_fork_io_outputs_0_takeWhen_payload_command = control_fork_io_outputs_0_payload_command;
  assign control_fork_io_outputs_0_takeWhen_payload_engineId = control_fork_io_outputs_0_payload_engineId;
  assign control_fork_io_outputs_0_takeWhen_payload_vPifoId = control_fork_io_outputs_0_payload_vPifoId;
  assign control_fork_io_outputs_0_takeWhen_payload_flowId = control_fork_io_outputs_0_payload_flowId;
  assign control_fork_io_outputs_0_takeWhen_payload_data = control_fork_io_outputs_0_payload_data;
  assign control_fork_io_outputs_0_takeWhen_ready = enque_enqueMapper_io_writeReq_ready;
  assign enque_enqueMapper_io_writeReq_payload_outputId = control_fork_io_outputs_0_takeWhen_payload_data[2:0];
  assign when_Stream_l581_2 = (! (control_fork_io_outputs_1_payload_command == ControlCommand_UpdateMapperPost));
  always @(*) begin
    control_fork_io_outputs_1_takeWhen_valid = control_fork_io_outputs_1_valid;
    if(when_Stream_l581_2) begin
      control_fork_io_outputs_1_takeWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    control_fork_io_outputs_1_ready = control_fork_io_outputs_1_takeWhen_ready;
    if(when_Stream_l581_2) begin
      control_fork_io_outputs_1_ready = 1'b1;
    end
  end

  assign control_fork_io_outputs_1_takeWhen_payload_command = control_fork_io_outputs_1_payload_command;
  assign control_fork_io_outputs_1_takeWhen_payload_engineId = control_fork_io_outputs_1_payload_engineId;
  assign control_fork_io_outputs_1_takeWhen_payload_vPifoId = control_fork_io_outputs_1_payload_vPifoId;
  assign control_fork_io_outputs_1_takeWhen_payload_flowId = control_fork_io_outputs_1_payload_flowId;
  assign control_fork_io_outputs_1_takeWhen_payload_data = control_fork_io_outputs_1_payload_data;
  assign control_fork_io_outputs_1_takeWhen_ready = deque_dequeMapper_io_writeReq_ready;
  assign deque_dequeMapper_io_writeReq_payload_inputId = {control_fork_io_outputs_1_takeWhen_payload_vPifoId,control_fork_io_outputs_1_takeWhen_payload_flowId};
  assign deque_dequeMapper_io_writeReq_payload_outputId = control_fork_io_outputs_1_takeWhen_payload_data[4:0];
  assign when_Stream_l581_3 = (! (control_fork_io_outputs_2_payload_command == ControlCommand_UpdateMapperNonExist));
  always @(*) begin
    control_fork_io_outputs_2_takeWhen_valid = control_fork_io_outputs_2_valid;
    if(when_Stream_l581_3) begin
      control_fork_io_outputs_2_takeWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    control_fork_io_outputs_2_ready = control_fork_io_outputs_2_takeWhen_ready;
    if(when_Stream_l581_3) begin
      control_fork_io_outputs_2_ready = 1'b1;
    end
  end

  assign control_fork_io_outputs_2_takeWhen_payload_command = control_fork_io_outputs_2_payload_command;
  assign control_fork_io_outputs_2_takeWhen_payload_engineId = control_fork_io_outputs_2_payload_engineId;
  assign control_fork_io_outputs_2_takeWhen_payload_vPifoId = control_fork_io_outputs_2_payload_vPifoId;
  assign control_fork_io_outputs_2_takeWhen_payload_flowId = control_fork_io_outputs_2_payload_flowId;
  assign control_fork_io_outputs_2_takeWhen_payload_data = control_fork_io_outputs_2_payload_data;
  assign control_fork_io_outputs_2_takeWhen_ready = deque_frontRewrite_io_writeReq_ready;
  assign deque_frontRewrite_io_writeReq_payload_outputId = control_fork_io_outputs_2_takeWhen_payload_data[2 : 0];
  assign brainControl_ready = enque_brain_io_control_ready;
  assign when_Stream_l581_4 = (! (commitControl_payload_command == ControlCommand_CommitMapper));
  always @(*) begin
    commit_valid = commitControl_valid;
    if(when_Stream_l581_4) begin
      commit_valid = 1'b0;
    end
  end

  always @(*) begin
    commitControl_ready = commit_ready;
    if(when_Stream_l581_4) begin
      commitControl_ready = 1'b1;
    end
  end

  assign commit_payload_command = commitControl_payload_command;
  assign commit_payload_engineId = commitControl_payload_engineId;
  assign commit_payload_vPifoId = commitControl_payload_vPifoId;
  assign commit_payload_flowId = commitControl_payload_flowId;
  assign commit_payload_data = commitControl_payload_data;
  assign commit_ready = mapperCommitReady;
  assign commitPulse = (commit_valid && commit_ready);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      io_enqueRequest_fork2_logic_linkEnable_0 <= 1'b1;
      io_enqueRequest_fork2_logic_linkEnable_1 <= 1'b1;
      io_control_fork3_logic_linkEnable_0 <= 1'b1;
      io_control_fork3_logic_linkEnable_1 <= 1'b1;
      io_control_fork3_logic_linkEnable_2 <= 1'b1;
    end else begin
      if(enque_mapperRead_fire) begin
        io_enqueRequest_fork2_logic_linkEnable_0 <= 1'b0;
      end
      if(enque_flowIdStream_fire) begin
        io_enqueRequest_fork2_logic_linkEnable_1 <= 1'b0;
      end
      if(io_enqueRequest_ready) begin
        io_enqueRequest_fork2_logic_linkEnable_0 <= 1'b1;
        io_enqueRequest_fork2_logic_linkEnable_1 <= 1'b1;
      end
      if(control_fire) begin
        io_control_fork3_logic_linkEnable_0 <= 1'b0;
      end
      if(brainControl_fire) begin
        io_control_fork3_logic_linkEnable_1 <= 1'b0;
      end
      if(commitControl_fire) begin
        io_control_fork3_logic_linkEnable_2 <= 1'b0;
      end
      if(io_control_ready) begin
        io_control_fork3_logic_linkEnable_0 <= 1'b1;
        io_control_fork3_logic_linkEnable_1 <= 1'b1;
        io_control_fork3_logic_linkEnable_2 <= 1'b1;
      end
    end
  end


endmodule

module MessageCrossBar (
  input  wire          io_inputs_0_valid,
  output wire          io_inputs_0_ready,
  input  wire [1:0]    io_inputs_0_payload_engineId,
  input  wire [2:0]    io_inputs_0_payload_vPifoId,
  input  wire          io_inputs_1_valid,
  output wire          io_inputs_1_ready,
  input  wire [1:0]    io_inputs_1_payload_engineId,
  input  wire [2:0]    io_inputs_1_payload_vPifoId,
  input  wire          io_inputs_2_valid,
  output wire          io_inputs_2_ready,
  input  wire [1:0]    io_inputs_2_payload_engineId,
  input  wire [2:0]    io_inputs_2_payload_vPifoId,
  output wire          io_outputs_0_valid,
  input  wire          io_outputs_0_ready,
  output wire [1:0]    io_outputs_0_payload_engineId,
  output wire [2:0]    io_outputs_0_payload_vPifoId,
  output wire          io_outputs_1_valid,
  input  wire          io_outputs_1_ready,
  output wire [1:0]    io_outputs_1_payload_engineId,
  output wire [2:0]    io_outputs_1_payload_vPifoId,
  output wire          io_outputs_2_valid,
  input  wire          io_outputs_2_ready,
  output wire [1:0]    io_outputs_2_payload_engineId,
  output wire [2:0]    io_outputs_2_payload_vPifoId,
  input  wire          clk,
  input  wire          reset
);

  wire                io_inputs_0_fifo_io_push_ready;
  wire                io_inputs_0_fifo_io_pop_valid;
  wire       [1:0]    io_inputs_0_fifo_io_pop_payload_engineId;
  wire       [2:0]    io_inputs_0_fifo_io_pop_payload_vPifoId;
  wire       [3:0]    io_inputs_0_fifo_io_occupancy;
  wire       [3:0]    io_inputs_0_fifo_io_availability;
  wire                streamDemux_4_io_input_ready;
  wire                streamDemux_4_io_outputs_0_valid;
  wire       [1:0]    streamDemux_4_io_outputs_0_payload_engineId;
  wire       [2:0]    streamDemux_4_io_outputs_0_payload_vPifoId;
  wire                streamDemux_4_io_outputs_1_valid;
  wire       [1:0]    streamDemux_4_io_outputs_1_payload_engineId;
  wire       [2:0]    streamDemux_4_io_outputs_1_payload_vPifoId;
  wire                streamDemux_4_io_outputs_2_valid;
  wire       [1:0]    streamDemux_4_io_outputs_2_payload_engineId;
  wire       [2:0]    streamDemux_4_io_outputs_2_payload_vPifoId;
  wire                io_inputs_1_fifo_io_push_ready;
  wire                io_inputs_1_fifo_io_pop_valid;
  wire       [1:0]    io_inputs_1_fifo_io_pop_payload_engineId;
  wire       [2:0]    io_inputs_1_fifo_io_pop_payload_vPifoId;
  wire       [3:0]    io_inputs_1_fifo_io_occupancy;
  wire       [3:0]    io_inputs_1_fifo_io_availability;
  wire                streamDemux_5_io_input_ready;
  wire                streamDemux_5_io_outputs_0_valid;
  wire       [1:0]    streamDemux_5_io_outputs_0_payload_engineId;
  wire       [2:0]    streamDemux_5_io_outputs_0_payload_vPifoId;
  wire                streamDemux_5_io_outputs_1_valid;
  wire       [1:0]    streamDemux_5_io_outputs_1_payload_engineId;
  wire       [2:0]    streamDemux_5_io_outputs_1_payload_vPifoId;
  wire                streamDemux_5_io_outputs_2_valid;
  wire       [1:0]    streamDemux_5_io_outputs_2_payload_engineId;
  wire       [2:0]    streamDemux_5_io_outputs_2_payload_vPifoId;
  wire                io_inputs_2_fifo_io_push_ready;
  wire                io_inputs_2_fifo_io_pop_valid;
  wire       [1:0]    io_inputs_2_fifo_io_pop_payload_engineId;
  wire       [2:0]    io_inputs_2_fifo_io_pop_payload_vPifoId;
  wire       [3:0]    io_inputs_2_fifo_io_occupancy;
  wire       [3:0]    io_inputs_2_fifo_io_availability;
  wire                streamDemux_6_io_input_ready;
  wire                streamDemux_6_io_outputs_0_valid;
  wire       [1:0]    streamDemux_6_io_outputs_0_payload_engineId;
  wire       [2:0]    streamDemux_6_io_outputs_0_payload_vPifoId;
  wire                streamDemux_6_io_outputs_1_valid;
  wire       [1:0]    streamDemux_6_io_outputs_1_payload_engineId;
  wire       [2:0]    streamDemux_6_io_outputs_1_payload_vPifoId;
  wire                streamDemux_6_io_outputs_2_valid;
  wire       [1:0]    streamDemux_6_io_outputs_2_payload_engineId;
  wire       [2:0]    streamDemux_6_io_outputs_2_payload_vPifoId;
  wire                streamArbiter_9_io_inputs_0_ready;
  wire                streamArbiter_9_io_inputs_1_ready;
  wire                streamArbiter_9_io_inputs_2_ready;
  wire                streamArbiter_9_io_output_valid;
  wire       [1:0]    streamArbiter_9_io_output_payload_engineId;
  wire       [2:0]    streamArbiter_9_io_output_payload_vPifoId;
  wire       [1:0]    streamArbiter_9_io_chosen;
  wire       [2:0]    streamArbiter_9_io_chosenOH;
  wire                streamArbiter_10_io_inputs_0_ready;
  wire                streamArbiter_10_io_inputs_1_ready;
  wire                streamArbiter_10_io_inputs_2_ready;
  wire                streamArbiter_10_io_output_valid;
  wire       [1:0]    streamArbiter_10_io_output_payload_engineId;
  wire       [2:0]    streamArbiter_10_io_output_payload_vPifoId;
  wire       [1:0]    streamArbiter_10_io_chosen;
  wire       [2:0]    streamArbiter_10_io_chosenOH;
  wire                streamArbiter_11_io_inputs_0_ready;
  wire                streamArbiter_11_io_inputs_1_ready;
  wire                streamArbiter_11_io_inputs_2_ready;
  wire                streamArbiter_11_io_output_valid;
  wire       [1:0]    streamArbiter_11_io_output_payload_engineId;
  wire       [2:0]    streamArbiter_11_io_output_payload_vPifoId;
  wire       [1:0]    streamArbiter_11_io_chosen;
  wire       [2:0]    streamArbiter_11_io_chosenOH;
  reg                 _zz_io_output_ready;
  wire                _zz_io_outputs_0_valid;
  reg                 _zz_io_outputs_0_valid_1;
  reg        [1:0]    _zz_io_outputs_0_payload_engineId;
  reg        [2:0]    _zz_io_outputs_0_payload_vPifoId;
  wire                when_Stream_l477;
  reg                 _zz_io_output_ready_1;
  wire                _zz_io_outputs_1_valid;
  reg                 _zz_io_outputs_1_valid_1;
  reg        [1:0]    _zz_io_outputs_1_payload_engineId;
  reg        [2:0]    _zz_io_outputs_1_payload_vPifoId;
  wire                when_Stream_l477_1;
  reg                 _zz_io_output_ready_2;
  wire                _zz_io_outputs_2_valid;
  reg                 _zz_io_outputs_2_valid_1;
  reg        [1:0]    _zz_io_outputs_2_payload_engineId;
  reg        [2:0]    _zz_io_outputs_2_payload_vPifoId;
  wire                when_Stream_l477_2;

  StreamFifoLowLatency io_inputs_0_fifo (
    .io_push_valid            (io_inputs_0_valid                            ), //i
    .io_push_ready            (io_inputs_0_fifo_io_push_ready               ), //o
    .io_push_payload_engineId (io_inputs_0_payload_engineId[1:0]            ), //i
    .io_push_payload_vPifoId  (io_inputs_0_payload_vPifoId[2:0]             ), //i
    .io_pop_valid             (io_inputs_0_fifo_io_pop_valid                ), //o
    .io_pop_ready             (streamDemux_4_io_input_ready                 ), //i
    .io_pop_payload_engineId  (io_inputs_0_fifo_io_pop_payload_engineId[1:0]), //o
    .io_pop_payload_vPifoId   (io_inputs_0_fifo_io_pop_payload_vPifoId[2:0] ), //o
    .io_flush                 (1'b0                                         ), //i
    .io_occupancy             (io_inputs_0_fifo_io_occupancy[3:0]           ), //o
    .io_availability          (io_inputs_0_fifo_io_availability[3:0]        ), //o
    .clk                      (clk                                          ), //i
    .reset                    (reset                                        )  //i
  );
  StreamDemux streamDemux_4 (
    .io_select                     (io_inputs_0_fifo_io_pop_payload_engineId[1:0]   ), //i
    .io_input_valid                (io_inputs_0_fifo_io_pop_valid                   ), //i
    .io_input_ready                (streamDemux_4_io_input_ready                    ), //o
    .io_input_payload_engineId     (io_inputs_0_fifo_io_pop_payload_engineId[1:0]   ), //i
    .io_input_payload_vPifoId      (io_inputs_0_fifo_io_pop_payload_vPifoId[2:0]    ), //i
    .io_outputs_0_valid            (streamDemux_4_io_outputs_0_valid                ), //o
    .io_outputs_0_ready            (streamArbiter_9_io_inputs_0_ready               ), //i
    .io_outputs_0_payload_engineId (streamDemux_4_io_outputs_0_payload_engineId[1:0]), //o
    .io_outputs_0_payload_vPifoId  (streamDemux_4_io_outputs_0_payload_vPifoId[2:0] ), //o
    .io_outputs_1_valid            (streamDemux_4_io_outputs_1_valid                ), //o
    .io_outputs_1_ready            (streamArbiter_10_io_inputs_0_ready              ), //i
    .io_outputs_1_payload_engineId (streamDemux_4_io_outputs_1_payload_engineId[1:0]), //o
    .io_outputs_1_payload_vPifoId  (streamDemux_4_io_outputs_1_payload_vPifoId[2:0] ), //o
    .io_outputs_2_valid            (streamDemux_4_io_outputs_2_valid                ), //o
    .io_outputs_2_ready            (streamArbiter_11_io_inputs_0_ready              ), //i
    .io_outputs_2_payload_engineId (streamDemux_4_io_outputs_2_payload_engineId[1:0]), //o
    .io_outputs_2_payload_vPifoId  (streamDemux_4_io_outputs_2_payload_vPifoId[2:0] )  //o
  );
  StreamFifoLowLatency io_inputs_1_fifo (
    .io_push_valid            (io_inputs_1_valid                            ), //i
    .io_push_ready            (io_inputs_1_fifo_io_push_ready               ), //o
    .io_push_payload_engineId (io_inputs_1_payload_engineId[1:0]            ), //i
    .io_push_payload_vPifoId  (io_inputs_1_payload_vPifoId[2:0]             ), //i
    .io_pop_valid             (io_inputs_1_fifo_io_pop_valid                ), //o
    .io_pop_ready             (streamDemux_5_io_input_ready                 ), //i
    .io_pop_payload_engineId  (io_inputs_1_fifo_io_pop_payload_engineId[1:0]), //o
    .io_pop_payload_vPifoId   (io_inputs_1_fifo_io_pop_payload_vPifoId[2:0] ), //o
    .io_flush                 (1'b0                                         ), //i
    .io_occupancy             (io_inputs_1_fifo_io_occupancy[3:0]           ), //o
    .io_availability          (io_inputs_1_fifo_io_availability[3:0]        ), //o
    .clk                      (clk                                          ), //i
    .reset                    (reset                                        )  //i
  );
  StreamDemux streamDemux_5 (
    .io_select                     (io_inputs_1_fifo_io_pop_payload_engineId[1:0]   ), //i
    .io_input_valid                (io_inputs_1_fifo_io_pop_valid                   ), //i
    .io_input_ready                (streamDemux_5_io_input_ready                    ), //o
    .io_input_payload_engineId     (io_inputs_1_fifo_io_pop_payload_engineId[1:0]   ), //i
    .io_input_payload_vPifoId      (io_inputs_1_fifo_io_pop_payload_vPifoId[2:0]    ), //i
    .io_outputs_0_valid            (streamDemux_5_io_outputs_0_valid                ), //o
    .io_outputs_0_ready            (streamArbiter_9_io_inputs_1_ready               ), //i
    .io_outputs_0_payload_engineId (streamDemux_5_io_outputs_0_payload_engineId[1:0]), //o
    .io_outputs_0_payload_vPifoId  (streamDemux_5_io_outputs_0_payload_vPifoId[2:0] ), //o
    .io_outputs_1_valid            (streamDemux_5_io_outputs_1_valid                ), //o
    .io_outputs_1_ready            (streamArbiter_10_io_inputs_1_ready              ), //i
    .io_outputs_1_payload_engineId (streamDemux_5_io_outputs_1_payload_engineId[1:0]), //o
    .io_outputs_1_payload_vPifoId  (streamDemux_5_io_outputs_1_payload_vPifoId[2:0] ), //o
    .io_outputs_2_valid            (streamDemux_5_io_outputs_2_valid                ), //o
    .io_outputs_2_ready            (streamArbiter_11_io_inputs_1_ready              ), //i
    .io_outputs_2_payload_engineId (streamDemux_5_io_outputs_2_payload_engineId[1:0]), //o
    .io_outputs_2_payload_vPifoId  (streamDemux_5_io_outputs_2_payload_vPifoId[2:0] )  //o
  );
  StreamFifoLowLatency io_inputs_2_fifo (
    .io_push_valid            (io_inputs_2_valid                            ), //i
    .io_push_ready            (io_inputs_2_fifo_io_push_ready               ), //o
    .io_push_payload_engineId (io_inputs_2_payload_engineId[1:0]            ), //i
    .io_push_payload_vPifoId  (io_inputs_2_payload_vPifoId[2:0]             ), //i
    .io_pop_valid             (io_inputs_2_fifo_io_pop_valid                ), //o
    .io_pop_ready             (streamDemux_6_io_input_ready                 ), //i
    .io_pop_payload_engineId  (io_inputs_2_fifo_io_pop_payload_engineId[1:0]), //o
    .io_pop_payload_vPifoId   (io_inputs_2_fifo_io_pop_payload_vPifoId[2:0] ), //o
    .io_flush                 (1'b0                                         ), //i
    .io_occupancy             (io_inputs_2_fifo_io_occupancy[3:0]           ), //o
    .io_availability          (io_inputs_2_fifo_io_availability[3:0]        ), //o
    .clk                      (clk                                          ), //i
    .reset                    (reset                                        )  //i
  );
  StreamDemux streamDemux_6 (
    .io_select                     (io_inputs_2_fifo_io_pop_payload_engineId[1:0]   ), //i
    .io_input_valid                (io_inputs_2_fifo_io_pop_valid                   ), //i
    .io_input_ready                (streamDemux_6_io_input_ready                    ), //o
    .io_input_payload_engineId     (io_inputs_2_fifo_io_pop_payload_engineId[1:0]   ), //i
    .io_input_payload_vPifoId      (io_inputs_2_fifo_io_pop_payload_vPifoId[2:0]    ), //i
    .io_outputs_0_valid            (streamDemux_6_io_outputs_0_valid                ), //o
    .io_outputs_0_ready            (streamArbiter_9_io_inputs_2_ready               ), //i
    .io_outputs_0_payload_engineId (streamDemux_6_io_outputs_0_payload_engineId[1:0]), //o
    .io_outputs_0_payload_vPifoId  (streamDemux_6_io_outputs_0_payload_vPifoId[2:0] ), //o
    .io_outputs_1_valid            (streamDemux_6_io_outputs_1_valid                ), //o
    .io_outputs_1_ready            (streamArbiter_10_io_inputs_2_ready              ), //i
    .io_outputs_1_payload_engineId (streamDemux_6_io_outputs_1_payload_engineId[1:0]), //o
    .io_outputs_1_payload_vPifoId  (streamDemux_6_io_outputs_1_payload_vPifoId[2:0] ), //o
    .io_outputs_2_valid            (streamDemux_6_io_outputs_2_valid                ), //o
    .io_outputs_2_ready            (streamArbiter_11_io_inputs_2_ready              ), //i
    .io_outputs_2_payload_engineId (streamDemux_6_io_outputs_2_payload_engineId[1:0]), //o
    .io_outputs_2_payload_vPifoId  (streamDemux_6_io_outputs_2_payload_vPifoId[2:0] )  //o
  );
  StreamArbiter streamArbiter_9 (
    .io_inputs_0_valid            (streamDemux_4_io_outputs_0_valid                ), //i
    .io_inputs_0_ready            (streamArbiter_9_io_inputs_0_ready               ), //o
    .io_inputs_0_payload_engineId (streamDemux_4_io_outputs_0_payload_engineId[1:0]), //i
    .io_inputs_0_payload_vPifoId  (streamDemux_4_io_outputs_0_payload_vPifoId[2:0] ), //i
    .io_inputs_1_valid            (streamDemux_5_io_outputs_0_valid                ), //i
    .io_inputs_1_ready            (streamArbiter_9_io_inputs_1_ready               ), //o
    .io_inputs_1_payload_engineId (streamDemux_5_io_outputs_0_payload_engineId[1:0]), //i
    .io_inputs_1_payload_vPifoId  (streamDemux_5_io_outputs_0_payload_vPifoId[2:0] ), //i
    .io_inputs_2_valid            (streamDemux_6_io_outputs_0_valid                ), //i
    .io_inputs_2_ready            (streamArbiter_9_io_inputs_2_ready               ), //o
    .io_inputs_2_payload_engineId (streamDemux_6_io_outputs_0_payload_engineId[1:0]), //i
    .io_inputs_2_payload_vPifoId  (streamDemux_6_io_outputs_0_payload_vPifoId[2:0] ), //i
    .io_output_valid              (streamArbiter_9_io_output_valid                 ), //o
    .io_output_ready              (_zz_io_output_ready                             ), //i
    .io_output_payload_engineId   (streamArbiter_9_io_output_payload_engineId[1:0] ), //o
    .io_output_payload_vPifoId    (streamArbiter_9_io_output_payload_vPifoId[2:0]  ), //o
    .io_chosen                    (streamArbiter_9_io_chosen[1:0]                  ), //o
    .io_chosenOH                  (streamArbiter_9_io_chosenOH[2:0]                ), //o
    .clk                          (clk                                             ), //i
    .reset                        (reset                                           )  //i
  );
  StreamArbiter streamArbiter_10 (
    .io_inputs_0_valid            (streamDemux_4_io_outputs_1_valid                ), //i
    .io_inputs_0_ready            (streamArbiter_10_io_inputs_0_ready              ), //o
    .io_inputs_0_payload_engineId (streamDemux_4_io_outputs_1_payload_engineId[1:0]), //i
    .io_inputs_0_payload_vPifoId  (streamDemux_4_io_outputs_1_payload_vPifoId[2:0] ), //i
    .io_inputs_1_valid            (streamDemux_5_io_outputs_1_valid                ), //i
    .io_inputs_1_ready            (streamArbiter_10_io_inputs_1_ready              ), //o
    .io_inputs_1_payload_engineId (streamDemux_5_io_outputs_1_payload_engineId[1:0]), //i
    .io_inputs_1_payload_vPifoId  (streamDemux_5_io_outputs_1_payload_vPifoId[2:0] ), //i
    .io_inputs_2_valid            (streamDemux_6_io_outputs_1_valid                ), //i
    .io_inputs_2_ready            (streamArbiter_10_io_inputs_2_ready              ), //o
    .io_inputs_2_payload_engineId (streamDemux_6_io_outputs_1_payload_engineId[1:0]), //i
    .io_inputs_2_payload_vPifoId  (streamDemux_6_io_outputs_1_payload_vPifoId[2:0] ), //i
    .io_output_valid              (streamArbiter_10_io_output_valid                ), //o
    .io_output_ready              (_zz_io_output_ready_1                           ), //i
    .io_output_payload_engineId   (streamArbiter_10_io_output_payload_engineId[1:0]), //o
    .io_output_payload_vPifoId    (streamArbiter_10_io_output_payload_vPifoId[2:0] ), //o
    .io_chosen                    (streamArbiter_10_io_chosen[1:0]                 ), //o
    .io_chosenOH                  (streamArbiter_10_io_chosenOH[2:0]               ), //o
    .clk                          (clk                                             ), //i
    .reset                        (reset                                           )  //i
  );
  StreamArbiter streamArbiter_11 (
    .io_inputs_0_valid            (streamDemux_4_io_outputs_2_valid                ), //i
    .io_inputs_0_ready            (streamArbiter_11_io_inputs_0_ready              ), //o
    .io_inputs_0_payload_engineId (streamDemux_4_io_outputs_2_payload_engineId[1:0]), //i
    .io_inputs_0_payload_vPifoId  (streamDemux_4_io_outputs_2_payload_vPifoId[2:0] ), //i
    .io_inputs_1_valid            (streamDemux_5_io_outputs_2_valid                ), //i
    .io_inputs_1_ready            (streamArbiter_11_io_inputs_1_ready              ), //o
    .io_inputs_1_payload_engineId (streamDemux_5_io_outputs_2_payload_engineId[1:0]), //i
    .io_inputs_1_payload_vPifoId  (streamDemux_5_io_outputs_2_payload_vPifoId[2:0] ), //i
    .io_inputs_2_valid            (streamDemux_6_io_outputs_2_valid                ), //i
    .io_inputs_2_ready            (streamArbiter_11_io_inputs_2_ready              ), //o
    .io_inputs_2_payload_engineId (streamDemux_6_io_outputs_2_payload_engineId[1:0]), //i
    .io_inputs_2_payload_vPifoId  (streamDemux_6_io_outputs_2_payload_vPifoId[2:0] ), //i
    .io_output_valid              (streamArbiter_11_io_output_valid                ), //o
    .io_output_ready              (_zz_io_output_ready_2                           ), //i
    .io_output_payload_engineId   (streamArbiter_11_io_output_payload_engineId[1:0]), //o
    .io_output_payload_vPifoId    (streamArbiter_11_io_output_payload_vPifoId[2:0] ), //o
    .io_chosen                    (streamArbiter_11_io_chosen[1:0]                 ), //o
    .io_chosenOH                  (streamArbiter_11_io_chosenOH[2:0]               ), //o
    .clk                          (clk                                             ), //i
    .reset                        (reset                                           )  //i
  );
  assign io_inputs_0_ready = io_inputs_0_fifo_io_push_ready;
  assign io_inputs_1_ready = io_inputs_1_fifo_io_push_ready;
  assign io_inputs_2_ready = io_inputs_2_fifo_io_push_ready;
  always @(*) begin
    _zz_io_output_ready = io_outputs_0_ready;
    if(when_Stream_l477) begin
      _zz_io_output_ready = 1'b1;
    end
  end

  assign when_Stream_l477 = (! _zz_io_outputs_0_valid);
  assign _zz_io_outputs_0_valid = _zz_io_outputs_0_valid_1;
  assign io_outputs_0_valid = _zz_io_outputs_0_valid;
  assign io_outputs_0_payload_engineId = _zz_io_outputs_0_payload_engineId;
  assign io_outputs_0_payload_vPifoId = _zz_io_outputs_0_payload_vPifoId;
  always @(*) begin
    _zz_io_output_ready_1 = io_outputs_1_ready;
    if(when_Stream_l477_1) begin
      _zz_io_output_ready_1 = 1'b1;
    end
  end

  assign when_Stream_l477_1 = (! _zz_io_outputs_1_valid);
  assign _zz_io_outputs_1_valid = _zz_io_outputs_1_valid_1;
  assign io_outputs_1_valid = _zz_io_outputs_1_valid;
  assign io_outputs_1_payload_engineId = _zz_io_outputs_1_payload_engineId;
  assign io_outputs_1_payload_vPifoId = _zz_io_outputs_1_payload_vPifoId;
  always @(*) begin
    _zz_io_output_ready_2 = io_outputs_2_ready;
    if(when_Stream_l477_2) begin
      _zz_io_output_ready_2 = 1'b1;
    end
  end

  assign when_Stream_l477_2 = (! _zz_io_outputs_2_valid);
  assign _zz_io_outputs_2_valid = _zz_io_outputs_2_valid_1;
  assign io_outputs_2_valid = _zz_io_outputs_2_valid;
  assign io_outputs_2_payload_engineId = _zz_io_outputs_2_payload_engineId;
  assign io_outputs_2_payload_vPifoId = _zz_io_outputs_2_payload_vPifoId;
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      _zz_io_outputs_0_valid_1 <= 1'b0;
      _zz_io_outputs_1_valid_1 <= 1'b0;
      _zz_io_outputs_2_valid_1 <= 1'b0;
    end else begin
      if(_zz_io_output_ready) begin
        _zz_io_outputs_0_valid_1 <= streamArbiter_9_io_output_valid;
      end
      if(_zz_io_output_ready_1) begin
        _zz_io_outputs_1_valid_1 <= streamArbiter_10_io_output_valid;
      end
      if(_zz_io_output_ready_2) begin
        _zz_io_outputs_2_valid_1 <= streamArbiter_11_io_output_valid;
      end
    end
  end

  always @(posedge clk) begin
    if(_zz_io_output_ready) begin
      _zz_io_outputs_0_payload_engineId <= streamArbiter_9_io_output_payload_engineId;
      _zz_io_outputs_0_payload_vPifoId <= streamArbiter_9_io_output_payload_vPifoId;
    end
    if(_zz_io_output_ready_1) begin
      _zz_io_outputs_1_payload_engineId <= streamArbiter_10_io_output_payload_engineId;
      _zz_io_outputs_1_payload_vPifoId <= streamArbiter_10_io_output_payload_vPifoId;
    end
    if(_zz_io_output_ready_2) begin
      _zz_io_outputs_2_payload_engineId <= streamArbiter_11_io_output_payload_engineId;
      _zz_io_outputs_2_payload_vPifoId <= streamArbiter_11_io_output_payload_vPifoId;
    end
  end


endmodule

//StreamFork_7 replaced by StreamFork_1

//StreamFifoLowLatency_20 replaced by StreamFifoLowLatency_11

//StreamFork_6 replaced by StreamFork_2

//FrontRewriteTable_1 replaced by FrontRewriteTable

module ReplayMapper_3 (
  input  wire          io_readReq_valid,
  input  wire [7:0]    io_readReq_payload,
  output wire          io_readRes_valid,
  output wire [4:0]    io_readRes_payload,
  input  wire          io_writeReq_valid,
  output wire          io_writeReq_ready,
  input  wire [7:0]    io_writeReq_payload_inputId,
  input  wire [4:0]    io_writeReq_payload_outputId,
  input  wire          io_commit,
  output wire          io_commitReady,
  input  wire          clk,
  input  wire          reset
);

  reg        [4:0]    banks_0_spinal_port0;
  reg        [4:0]    banks_1_spinal_port0;
  wire       [4:0]    _zz_banks_0_port;
  wire                _zz_banks_0_port_1;
  wire       [4:0]    _zz_banks_1_port;
  wire                _zz_banks_1_port_1;
  reg                 activeBank;
  reg                 requestedBank;
  wire                _zz_bankRead_0;
  wire       [4:0]    bankRead_0;
  wire                _zz_bankRead_1;
  wire       [4:0]    bankRead_1;
  reg                 io_readReq_valid_regNext;
  wire                io_writeReq_fire;
  reg [4:0] banks_0 [0:255];
  reg [4:0] banks_1 [0:255];

  assign _zz_banks_0_port = io_writeReq_payload_outputId;
  assign _zz_banks_0_port_1 = (io_writeReq_fire && activeBank);
  assign _zz_banks_1_port = io_writeReq_payload_outputId;
  assign _zz_banks_1_port_1 = (io_writeReq_fire && (! activeBank));
  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_1_deque_dequeMapper_banks_0.bin",banks_0);
  end
  always @(posedge clk) begin
    if(_zz_bankRead_0) begin
      banks_0_spinal_port0 <= banks_0[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_banks_0_port_1) begin
      banks_0[io_writeReq_payload_inputId] <= _zz_banks_0_port;
    end
  end

  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_1_deque_dequeMapper_banks_1.bin",banks_1);
  end
  always @(posedge clk) begin
    if(_zz_bankRead_1) begin
      banks_1_spinal_port0 <= banks_1[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_banks_1_port_1) begin
      banks_1[io_writeReq_payload_inputId] <= _zz_banks_1_port;
    end
  end

  assign _zz_bankRead_0 = (io_readReq_valid && (! activeBank));
  assign bankRead_0 = banks_0_spinal_port0;
  assign _zz_bankRead_1 = (io_readReq_valid && activeBank);
  assign bankRead_1 = banks_1_spinal_port0;
  assign io_readRes_valid = io_readReq_valid_regNext;
  assign io_readRes_payload = (requestedBank ? bankRead_1 : bankRead_0);
  assign io_writeReq_ready = 1'b1;
  assign io_commitReady = 1'b1;
  assign io_writeReq_fire = (io_writeReq_valid && io_writeReq_ready);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      activeBank <= 1'b0;
      requestedBank <= 1'b0;
      io_readReq_valid_regNext <= 1'b0;
    end else begin
      if(io_readReq_valid) begin
        requestedBank <= activeBank;
      end
      io_readReq_valid_regNext <= io_readReq_valid;
      if(io_commit) begin
        activeBank <= (! activeBank);
      end
    end
  end


endmodule

module PIFOBrain_1 (
  input  wire          io_request_valid,
  output wire          io_request_ready,
  input  wire [2:0]    io_request_payload_vpifoId,
  input  wire [4:0]    io_request_payload_flowId,
  output wire          io_response_valid,
  input  wire          io_response_ready,
  output wire [7:0]    io_response_payload_priority,
  output wire [4:0]    io_response_payload_data,
  output wire [2:0]    io_response_payload_port,
  input  wire          io_control_valid,
  output wire          io_control_ready,
  input  wire [2:0]    io_control_payload_command,
  input  wire [1:0]    io_control_payload_engineId,
  input  wire [2:0]    io_control_payload_vPifoId,
  input  wire [4:0]    io_control_payload_flowId,
  input  wire [31:0]   io_control_payload_data,
  input  wire          io_poped_valid,
  input  wire          io_poped_payload_exist,
  input  wire [7:0]    io_poped_payload_priority,
  input  wire [4:0]    io_poped_payload_data,
  input  wire [2:0]    io_poped_payload_port,
  input  wire          clk,
  input  wire          reset
);
  localparam ControlCommand_UpdateMapperPre = 3'd0;
  localparam ControlCommand_UpdateMapperPost = 3'd1;
  localparam ControlCommand_UpdateMapperNonExist = 3'd2;
  localparam ControlCommand_CommitMapper = 3'd3;
  localparam ControlCommand_UpdateBrainEngine = 3'd4;
  localparam ControlCommand_UpdateBrainState = 3'd5;
  localparam ControlCommand_UpdateBrainFlowState = 3'd6;
  localparam BrainType_NOP = 2'd0;
  localparam BrainType_WFQ = 2'd1;
  localparam BrainType_SP = 2'd2;
  localparam BrainType_FIFO = 2'd3;

  wire       [1:0]    engineMapper_io_writeReq_payload_outputId;
  reg                 io_control_fork_io_outputs_0_ready;
  reg                 io_control_fork_io_outputs_1_ready;
  reg                 io_control_fork_io_outputs_2_ready;
  wire                io_request_fork_io_input_ready;
  wire                io_request_fork_io_outputs_0_valid;
  wire       [2:0]    io_request_fork_io_outputs_0_payload_vpifoId;
  wire       [4:0]    io_request_fork_io_outputs_0_payload_flowId;
  wire                io_request_fork_io_outputs_1_valid;
  wire       [2:0]    io_request_fork_io_outputs_1_payload_vpifoId;
  wire       [4:0]    io_request_fork_io_outputs_1_payload_flowId;
  wire                io_request_fork_io_outputs_2_valid;
  wire       [2:0]    io_request_fork_io_outputs_2_payload_vpifoId;
  wire       [4:0]    io_request_fork_io_outputs_2_payload_flowId;
  wire                io_request_fork_io_outputs_3_valid;
  wire       [2:0]    io_request_fork_io_outputs_3_payload_vpifoId;
  wire       [4:0]    io_request_fork_io_outputs_3_payload_flowId;
  wire                io_request_fork_io_outputs_4_valid;
  wire       [2:0]    io_request_fork_io_outputs_4_payload_vpifoId;
  wire       [4:0]    io_request_fork_io_outputs_4_payload_flowId;
  wire                engineMapper_io_readRes_valid;
  wire       [1:0]    engineMapper_io_readRes_payload;
  wire                lastVirtualMapper_io_readRes_valid;
  wire       [7:0]    lastVirtualMapper_io_readRes_payload;
  wire                engineCAM_io_readRes_valid;
  wire       [31:0]   engineCAM_io_readRes_payload;
  wire                flowStateUpdate_toStream_fifo_io_push_ready;
  wire                flowStateUpdate_toStream_fifo_io_pop_valid;
  wire       [7:0]    flowStateUpdate_toStream_fifo_io_pop_payload_inputId;
  wire       [31:0]   flowStateUpdate_toStream_fifo_io_pop_payload_outputId;
  wire       [1:0]    flowStateUpdate_toStream_fifo_io_occupancy;
  wire       [1:0]    flowStateUpdate_toStream_fifo_io_availability;
  wire                streamArbiter_9_io_inputs_0_ready;
  wire                streamArbiter_9_io_inputs_1_ready;
  wire                streamArbiter_9_io_output_valid;
  wire       [7:0]    streamArbiter_9_io_output_payload_inputId;
  wire       [31:0]   streamArbiter_9_io_output_payload_outputId;
  wire       [0:0]    streamArbiter_9_io_chosen;
  wire       [1:0]    streamArbiter_9_io_chosenOH;
  wire                brainStateMem_io_readRes_valid;
  wire       [31:0]   brainStateMem_io_readRes_payload;
  wire                brainStateUpdate_toStream_fifo_io_push_ready;
  wire                brainStateUpdate_toStream_fifo_io_pop_valid;
  wire       [2:0]    brainStateUpdate_toStream_fifo_io_pop_payload_inputId;
  wire       [31:0]   brainStateUpdate_toStream_fifo_io_pop_payload_outputId;
  wire       [1:0]    brainStateUpdate_toStream_fifo_io_occupancy;
  wire       [1:0]    brainStateUpdate_toStream_fifo_io_availability;
  wire                streamArbiter_10_io_inputs_0_ready;
  wire                streamArbiter_10_io_inputs_1_ready;
  wire                streamArbiter_10_io_output_valid;
  wire       [2:0]    streamArbiter_10_io_output_payload_inputId;
  wire       [31:0]   streamArbiter_10_io_output_payload_outputId;
  wire       [0:0]    streamArbiter_10_io_chosen;
  wire       [1:0]    streamArbiter_10_io_chosenOH;
  wire                io_control_fork_io_input_ready;
  wire                io_control_fork_io_outputs_0_valid;
  wire       [2:0]    io_control_fork_io_outputs_0_payload_command;
  wire       [1:0]    io_control_fork_io_outputs_0_payload_engineId;
  wire       [2:0]    io_control_fork_io_outputs_0_payload_vPifoId;
  wire       [4:0]    io_control_fork_io_outputs_0_payload_flowId;
  wire       [31:0]   io_control_fork_io_outputs_0_payload_data;
  wire                io_control_fork_io_outputs_1_valid;
  wire       [2:0]    io_control_fork_io_outputs_1_payload_command;
  wire       [1:0]    io_control_fork_io_outputs_1_payload_engineId;
  wire       [2:0]    io_control_fork_io_outputs_1_payload_vPifoId;
  wire       [4:0]    io_control_fork_io_outputs_1_payload_flowId;
  wire       [31:0]   io_control_fork_io_outputs_1_payload_data;
  wire                io_control_fork_io_outputs_2_valid;
  wire       [2:0]    io_control_fork_io_outputs_2_payload_command;
  wire       [1:0]    io_control_fork_io_outputs_2_payload_engineId;
  wire       [2:0]    io_control_fork_io_outputs_2_payload_vPifoId;
  wire       [4:0]    io_control_fork_io_outputs_2_payload_flowId;
  wire       [31:0]   io_control_fork_io_outputs_2_payload_data;
  wire                engineMapper_io_readRes_toStream_fifo_io_push_ready;
  wire                engineMapper_io_readRes_toStream_fifo_io_pop_valid;
  wire       [1:0]    engineMapper_io_readRes_toStream_fifo_io_pop_payload;
  wire       [1:0]    engineMapper_io_readRes_toStream_fifo_io_occupancy;
  wire       [1:0]    engineMapper_io_readRes_toStream_fifo_io_availability;
  wire                brainStateMem_io_readRes_toStream_fifo_io_push_ready;
  wire                brainStateMem_io_readRes_toStream_fifo_io_pop_valid;
  wire       [31:0]   brainStateMem_io_readRes_toStream_fifo_io_pop_payload;
  wire       [1:0]    brainStateMem_io_readRes_toStream_fifo_io_occupancy;
  wire       [1:0]    brainStateMem_io_readRes_toStream_fifo_io_availability;
  wire                engineCAM_io_readRes_toStream_fifo_io_push_ready;
  wire                engineCAM_io_readRes_toStream_fifo_io_pop_valid;
  wire       [31:0]   engineCAM_io_readRes_toStream_fifo_io_pop_payload;
  wire       [1:0]    engineCAM_io_readRes_toStream_fifo_io_occupancy;
  wire       [1:0]    engineCAM_io_readRes_toStream_fifo_io_availability;
  wire                lastVirtualMapper_io_readRes_toStream_fifo_io_push_ready;
  wire                lastVirtualMapper_io_readRes_toStream_fifo_io_pop_valid;
  wire       [7:0]    lastVirtualMapper_io_readRes_toStream_fifo_io_pop_payload;
  wire       [1:0]    lastVirtualMapper_io_readRes_toStream_fifo_io_occupancy;
  wire       [1:0]    lastVirtualMapper_io_readRes_toStream_fifo_io_availability;
  wire                io_outputs_4_fifo_io_push_ready;
  wire                io_outputs_4_fifo_io_pop_valid;
  wire       [2:0]    io_outputs_4_fifo_io_pop_payload_vpifoId;
  wire       [4:0]    io_outputs_4_fifo_io_pop_payload_flowId;
  wire       [1:0]    io_outputs_4_fifo_io_occupancy;
  wire       [1:0]    io_outputs_4_fifo_io_availability;
  wire       [7:0]    _zz__zz_outStream_payload_entry_priority_4;
  wire                io_request_fork_io_outputs_0_map_valid;
  wire                io_request_fork_io_outputs_0_map_ready;
  wire       [2:0]    io_request_fork_io_outputs_0_map_payload;
  wire                io_request_fork_io_outputs_0_map_toFlow_valid;
  wire       [2:0]    io_request_fork_io_outputs_0_map_toFlow_payload;
  wire                io_poped_takeWhen_valid;
  wire                io_poped_takeWhen_payload_exist;
  wire       [7:0]    io_poped_takeWhen_payload_priority;
  wire       [4:0]    io_poped_takeWhen_payload_data;
  wire       [2:0]    io_poped_takeWhen_payload_port;
  wire                io_request_fork_io_outputs_1_map_valid;
  wire                io_request_fork_io_outputs_1_map_ready;
  wire       [2:0]    io_request_fork_io_outputs_1_map_payload;
  wire                io_request_fork_io_outputs_1_map_toFlow_valid;
  wire       [2:0]    io_request_fork_io_outputs_1_map_toFlow_payload;
  wire                io_request_fork_io_outputs_2_map_valid;
  wire                io_request_fork_io_outputs_2_map_ready;
  wire       [7:0]    io_request_fork_io_outputs_2_map_payload;
  wire                io_request_fork_io_outputs_2_map_toFlow_valid;
  wire       [7:0]    io_request_fork_io_outputs_2_map_toFlow_payload;
  wire                flowStateControl_valid;
  wire       [7:0]    flowStateControl_payload_inputId;
  wire       [31:0]   flowStateControl_payload_outputId;
  wire                flowStateUpdate_valid;
  wire       [7:0]    flowStateUpdate_payload_inputId;
  wire       [31:0]   flowStateUpdate_payload_outputId;
  wire                flowStateControl_toStream_valid;
  wire                flowStateControl_toStream_ready;
  wire       [7:0]    flowStateControl_toStream_payload_inputId;
  wire       [31:0]   flowStateControl_toStream_payload_outputId;
  wire                flowStateUpdate_toStream_valid;
  wire                flowStateUpdate_toStream_ready;
  wire       [7:0]    flowStateUpdate_toStream_payload_inputId;
  wire       [31:0]   flowStateUpdate_toStream_payload_outputId;
  wire                io_request_fork_io_outputs_3_map_valid;
  wire                io_request_fork_io_outputs_3_map_ready;
  wire       [2:0]    io_request_fork_io_outputs_3_map_payload;
  wire                io_request_fork_io_outputs_3_map_toFlow_valid;
  wire       [2:0]    io_request_fork_io_outputs_3_map_toFlow_payload;
  wire                brainStateControl_valid;
  wire       [2:0]    brainStateControl_payload_inputId;
  wire       [31:0]   brainStateControl_payload_outputId;
  wire                brainStateUpdate_valid;
  wire       [2:0]    brainStateUpdate_payload_inputId;
  wire       [31:0]   brainStateUpdate_payload_outputId;
  wire                brainStateControl_toStream_valid;
  wire                brainStateControl_toStream_ready;
  wire       [2:0]    brainStateControl_toStream_payload_inputId;
  wire       [31:0]   brainStateControl_toStream_payload_outputId;
  wire                brainStateUpdate_toStream_valid;
  wire                brainStateUpdate_toStream_ready;
  wire       [2:0]    brainStateUpdate_toStream_payload_inputId;
  wire       [31:0]   brainStateUpdate_toStream_payload_outputId;
  wire                when_Stream_l581;
  reg                 io_control_fork_io_outputs_0_takeWhen_valid;
  wire                io_control_fork_io_outputs_0_takeWhen_ready;
  wire       [2:0]    io_control_fork_io_outputs_0_takeWhen_payload_command;
  wire       [1:0]    io_control_fork_io_outputs_0_takeWhen_payload_engineId;
  wire       [2:0]    io_control_fork_io_outputs_0_takeWhen_payload_vPifoId;
  wire       [4:0]    io_control_fork_io_outputs_0_takeWhen_payload_flowId;
  wire       [31:0]   io_control_fork_io_outputs_0_takeWhen_payload_data;
  wire                when_Stream_l581_1;
  reg                 io_control_fork_io_outputs_1_takeWhen_valid;
  wire                io_control_fork_io_outputs_1_takeWhen_ready;
  wire       [2:0]    io_control_fork_io_outputs_1_takeWhen_payload_command;
  wire       [1:0]    io_control_fork_io_outputs_1_takeWhen_payload_engineId;
  wire       [2:0]    io_control_fork_io_outputs_1_takeWhen_payload_vPifoId;
  wire       [4:0]    io_control_fork_io_outputs_1_takeWhen_payload_flowId;
  wire       [31:0]   io_control_fork_io_outputs_1_takeWhen_payload_data;
  wire                when_Stream_l581_2;
  reg                 io_control_fork_io_outputs_2_takeWhen_valid;
  wire                io_control_fork_io_outputs_2_takeWhen_ready;
  wire       [2:0]    io_control_fork_io_outputs_2_takeWhen_payload_command;
  wire       [1:0]    io_control_fork_io_outputs_2_takeWhen_payload_engineId;
  wire       [2:0]    io_control_fork_io_outputs_2_takeWhen_payload_vPifoId;
  wire       [4:0]    io_control_fork_io_outputs_2_takeWhen_payload_flowId;
  wire       [31:0]   io_control_fork_io_outputs_2_takeWhen_payload_data;
  wire                engineMapper_io_readRes_toStream_valid;
  wire                engineMapper_io_readRes_toStream_ready;
  wire       [1:0]    engineMapper_io_readRes_toStream_payload;
  wire                brainStateMem_io_readRes_toStream_valid;
  wire                brainStateMem_io_readRes_toStream_ready;
  wire       [31:0]   brainStateMem_io_readRes_toStream_payload;
  wire                engineCAM_io_readRes_toStream_valid;
  wire                engineCAM_io_readRes_toStream_ready;
  wire       [31:0]   engineCAM_io_readRes_toStream_payload;
  wire                lastVirtualMapper_io_readRes_toStream_valid;
  wire                lastVirtualMapper_io_readRes_toStream_ready;
  wire       [7:0]    lastVirtualMapper_io_readRes_toStream_payload;
  wire                _zz_engineStream_valid;
  wire                _zz_io_pop_ready;
  wire                engineStream_valid;
  wire                engineStream_ready;
  wire       [2:0]    engineStream_payload_pifoId;
  wire       [4:0]    engineStream_payload_flowId;
  wire       [1:0]    engineStream_payload_engineId;
  wire       [31:0]   engineStream_payload_flowState;
  wire       [31:0]   engineStream_payload_brainState;
  wire       [7:0]    engineStream_payload_virutalTime;
  reg        [7:0]    _zz_outStream_payload_entry_priority;
  reg        [31:0]   _zz_outStream_payload_flowUpdate_flow_outputId;
  reg                 _zz_outStream_payload_flowUpdate_update;
  reg        [31:0]   _zz_outStream_payload_brainUpdate_brain_outputId;
  reg                 _zz_outStream_payload_brainUpdate_update;
  wire       [1:0]    switch_PifoEngine_l367;
  wire       [1:0]    _zz_switch_PifoEngine_l367;
  wire       [7:0]    _zz_outStream_payload_entry_priority_1;
  wire       [7:0]    _zz_outStream_payload_entry_priority_2;
  wire       [7:0]    _zz_outStream_payload_entry_priority_3;
  wire       [7:0]    _zz_outStream_payload_entry_priority_4;
  wire                outStream_valid;
  reg                 outStream_ready;
  wire       [7:0]    outStream_payload_entry_priority;
  wire       [4:0]    outStream_payload_entry_data;
  wire       [2:0]    outStream_payload_entry_port;
  wire       [7:0]    outStream_payload_flowUpdate_flow_inputId;
  wire       [31:0]   outStream_payload_flowUpdate_flow_outputId;
  wire                outStream_payload_flowUpdate_update;
  wire       [2:0]    outStream_payload_brainUpdate_brain_inputId;
  wire       [31:0]   outStream_payload_brainUpdate_brain_outputId;
  wire                outStream_payload_brainUpdate_update;
  wire                output_valid;
  reg                 output_ready;
  wire       [7:0]    output_payload_entry_priority;
  wire       [4:0]    output_payload_entry_data;
  wire       [2:0]    output_payload_entry_port;
  wire       [7:0]    output_payload_flowUpdate_flow_inputId;
  wire       [31:0]   output_payload_flowUpdate_flow_outputId;
  wire                output_payload_flowUpdate_update;
  wire       [2:0]    output_payload_brainUpdate_brain_inputId;
  wire       [31:0]   output_payload_brainUpdate_brain_outputId;
  wire                output_payload_brainUpdate_update;
  wire                flowUpdates_valid;
  reg                 flowUpdates_ready;
  wire       [7:0]    flowUpdates_payload_entry_priority;
  wire       [4:0]    flowUpdates_payload_entry_data;
  wire       [2:0]    flowUpdates_payload_entry_port;
  wire       [7:0]    flowUpdates_payload_flowUpdate_flow_inputId;
  wire       [31:0]   flowUpdates_payload_flowUpdate_flow_outputId;
  wire                flowUpdates_payload_flowUpdate_update;
  wire       [2:0]    flowUpdates_payload_brainUpdate_brain_inputId;
  wire       [31:0]   flowUpdates_payload_brainUpdate_brain_outputId;
  wire                flowUpdates_payload_brainUpdate_update;
  wire                brainUpdates_valid;
  reg                 brainUpdates_ready;
  wire       [7:0]    brainUpdates_payload_entry_priority;
  wire       [4:0]    brainUpdates_payload_entry_data;
  wire       [2:0]    brainUpdates_payload_entry_port;
  wire       [7:0]    brainUpdates_payload_flowUpdate_flow_inputId;
  wire       [31:0]   brainUpdates_payload_flowUpdate_flow_outputId;
  wire                brainUpdates_payload_flowUpdate_update;
  wire       [2:0]    brainUpdates_payload_brainUpdate_brain_inputId;
  wire       [31:0]   brainUpdates_payload_brainUpdate_brain_outputId;
  wire                brainUpdates_payload_brainUpdate_update;
  reg                 outStream_fork3_logic_linkEnable_0;
  reg                 outStream_fork3_logic_linkEnable_1;
  reg                 outStream_fork3_logic_linkEnable_2;
  wire                when_Stream_l1253;
  wire                when_Stream_l1253_1;
  wire                when_Stream_l1253_2;
  wire                output_fire;
  wire                flowUpdates_fire;
  wire                brainUpdates_fire;
  wire                when_Stream_l581_3;
  reg                 output_throwWhen_valid;
  wire                output_throwWhen_ready;
  wire       [7:0]    output_throwWhen_payload_entry_priority;
  wire       [4:0]    output_throwWhen_payload_entry_data;
  wire       [2:0]    output_throwWhen_payload_entry_port;
  wire       [7:0]    output_throwWhen_payload_flowUpdate_flow_inputId;
  wire       [31:0]   output_throwWhen_payload_flowUpdate_flow_outputId;
  wire                output_throwWhen_payload_flowUpdate_update;
  wire       [2:0]    output_throwWhen_payload_brainUpdate_brain_inputId;
  wire       [31:0]   output_throwWhen_payload_brainUpdate_brain_outputId;
  wire                output_throwWhen_payload_brainUpdate_update;
  wire                output_throwWhen_map_valid;
  wire                output_throwWhen_map_ready;
  wire       [7:0]    output_throwWhen_map_payload_priority;
  wire       [4:0]    output_throwWhen_map_payload_data;
  wire       [2:0]    output_throwWhen_map_payload_port;
  wire                when_Stream_l581_4;
  reg                 flowUpdates_throwWhen_valid;
  wire                flowUpdates_throwWhen_ready;
  wire       [7:0]    flowUpdates_throwWhen_payload_entry_priority;
  wire       [4:0]    flowUpdates_throwWhen_payload_entry_data;
  wire       [2:0]    flowUpdates_throwWhen_payload_entry_port;
  wire       [7:0]    flowUpdates_throwWhen_payload_flowUpdate_flow_inputId;
  wire       [31:0]   flowUpdates_throwWhen_payload_flowUpdate_flow_outputId;
  wire                flowUpdates_throwWhen_payload_flowUpdate_update;
  wire       [2:0]    flowUpdates_throwWhen_payload_brainUpdate_brain_inputId;
  wire       [31:0]   flowUpdates_throwWhen_payload_brainUpdate_brain_outputId;
  wire                flowUpdates_throwWhen_payload_brainUpdate_update;
  wire                flowUpdates_throwWhen_map_valid;
  wire                flowUpdates_throwWhen_map_ready;
  wire       [7:0]    flowUpdates_throwWhen_map_payload_inputId;
  wire       [31:0]   flowUpdates_throwWhen_map_payload_outputId;
  wire                flowUpdates_throwWhen_map_toFlow_valid;
  wire       [7:0]    flowUpdates_throwWhen_map_toFlow_payload_inputId;
  wire       [31:0]   flowUpdates_throwWhen_map_toFlow_payload_outputId;
  wire                when_Stream_l581_5;
  reg                 brainUpdates_throwWhen_valid;
  wire                brainUpdates_throwWhen_ready;
  wire       [7:0]    brainUpdates_throwWhen_payload_entry_priority;
  wire       [4:0]    brainUpdates_throwWhen_payload_entry_data;
  wire       [2:0]    brainUpdates_throwWhen_payload_entry_port;
  wire       [7:0]    brainUpdates_throwWhen_payload_flowUpdate_flow_inputId;
  wire       [31:0]   brainUpdates_throwWhen_payload_flowUpdate_flow_outputId;
  wire                brainUpdates_throwWhen_payload_flowUpdate_update;
  wire       [2:0]    brainUpdates_throwWhen_payload_brainUpdate_brain_inputId;
  wire       [31:0]   brainUpdates_throwWhen_payload_brainUpdate_brain_outputId;
  wire                brainUpdates_throwWhen_payload_brainUpdate_update;
  wire                brainUpdates_throwWhen_map_valid;
  wire                brainUpdates_throwWhen_map_ready;
  wire       [2:0]    brainUpdates_throwWhen_map_payload_inputId;
  wire       [31:0]   brainUpdates_throwWhen_map_payload_outputId;
  wire                brainUpdates_throwWhen_map_toFlow_valid;
  wire       [2:0]    brainUpdates_throwWhen_map_toFlow_payload_inputId;
  wire       [31:0]   brainUpdates_throwWhen_map_toFlow_payload_outputId;
  `ifndef SYNTHESIS
  reg [159:0] io_control_payload_command_string;
  reg [159:0] io_control_fork_io_outputs_0_takeWhen_payload_command_string;
  reg [159:0] io_control_fork_io_outputs_1_takeWhen_payload_command_string;
  reg [159:0] io_control_fork_io_outputs_2_takeWhen_payload_command_string;
  reg [31:0] switch_PifoEngine_l367_string;
  reg [31:0] _zz_switch_PifoEngine_l367_string;
  `endif


  assign _zz__zz_outStream_payload_entry_priority_4 = engineStream_payload_brainState[7:0];
  StreamFork io_request_fork (
    .io_input_valid               (io_request_valid                                 ), //i
    .io_input_ready               (io_request_fork_io_input_ready                   ), //o
    .io_input_payload_vpifoId     (io_request_payload_vpifoId[2:0]                  ), //i
    .io_input_payload_flowId      (io_request_payload_flowId[4:0]                   ), //i
    .io_outputs_0_valid           (io_request_fork_io_outputs_0_valid               ), //o
    .io_outputs_0_ready           (io_request_fork_io_outputs_0_map_ready           ), //i
    .io_outputs_0_payload_vpifoId (io_request_fork_io_outputs_0_payload_vpifoId[2:0]), //o
    .io_outputs_0_payload_flowId  (io_request_fork_io_outputs_0_payload_flowId[4:0] ), //o
    .io_outputs_1_valid           (io_request_fork_io_outputs_1_valid               ), //o
    .io_outputs_1_ready           (io_request_fork_io_outputs_1_map_ready           ), //i
    .io_outputs_1_payload_vpifoId (io_request_fork_io_outputs_1_payload_vpifoId[2:0]), //o
    .io_outputs_1_payload_flowId  (io_request_fork_io_outputs_1_payload_flowId[4:0] ), //o
    .io_outputs_2_valid           (io_request_fork_io_outputs_2_valid               ), //o
    .io_outputs_2_ready           (io_request_fork_io_outputs_2_map_ready           ), //i
    .io_outputs_2_payload_vpifoId (io_request_fork_io_outputs_2_payload_vpifoId[2:0]), //o
    .io_outputs_2_payload_flowId  (io_request_fork_io_outputs_2_payload_flowId[4:0] ), //o
    .io_outputs_3_valid           (io_request_fork_io_outputs_3_valid               ), //o
    .io_outputs_3_ready           (io_request_fork_io_outputs_3_map_ready           ), //i
    .io_outputs_3_payload_vpifoId (io_request_fork_io_outputs_3_payload_vpifoId[2:0]), //o
    .io_outputs_3_payload_flowId  (io_request_fork_io_outputs_3_payload_flowId[4:0] ), //o
    .io_outputs_4_valid           (io_request_fork_io_outputs_4_valid               ), //o
    .io_outputs_4_ready           (io_outputs_4_fifo_io_push_ready                  ), //i
    .io_outputs_4_payload_vpifoId (io_request_fork_io_outputs_4_payload_vpifoId[2:0]), //o
    .io_outputs_4_payload_flowId  (io_request_fork_io_outputs_4_payload_flowId[4:0] ), //o
    .clk                          (clk                                              ), //i
    .reset                        (reset                                            )  //i
  );
  Mapper_4 engineMapper (
    .io_readReq_valid             (io_request_fork_io_outputs_0_map_toFlow_valid             ), //i
    .io_readReq_payload           (io_request_fork_io_outputs_0_map_toFlow_payload[2:0]      ), //i
    .io_readRes_valid             (engineMapper_io_readRes_valid                             ), //o
    .io_readRes_payload           (engineMapper_io_readRes_payload[1:0]                      ), //o
    .io_writeReq_valid            (io_control_fork_io_outputs_0_takeWhen_valid               ), //i
    .io_writeReq_payload_inputId  (io_control_fork_io_outputs_0_takeWhen_payload_vPifoId[2:0]), //i
    .io_writeReq_payload_outputId (engineMapper_io_writeReq_payload_outputId[1:0]            ), //i
    .clk                          (clk                                                       ), //i
    .reset                        (reset                                                     )  //i
  );
  Mapper_5 lastVirtualMapper (
    .io_readReq_valid             (io_request_fork_io_outputs_1_map_toFlow_valid       ), //i
    .io_readReq_payload           (io_request_fork_io_outputs_1_map_toFlow_payload[2:0]), //i
    .io_readRes_valid             (lastVirtualMapper_io_readRes_valid                  ), //o
    .io_readRes_payload           (lastVirtualMapper_io_readRes_payload[7:0]           ), //o
    .io_writeReq_valid            (io_poped_takeWhen_valid                             ), //i
    .io_writeReq_payload_inputId  (io_poped_takeWhen_payload_port[2:0]                 ), //i
    .io_writeReq_payload_outputId (io_poped_takeWhen_payload_priority[7:0]             ), //i
    .clk                          (clk                                                 ), //i
    .reset                        (reset                                               )  //i
  );
  Mapper_6 engineCAM (
    .io_readReq_valid             (io_request_fork_io_outputs_2_map_toFlow_valid       ), //i
    .io_readReq_payload           (io_request_fork_io_outputs_2_map_toFlow_payload[7:0]), //i
    .io_readRes_valid             (engineCAM_io_readRes_valid                          ), //o
    .io_readRes_payload           (engineCAM_io_readRes_payload[31:0]                  ), //o
    .io_writeReq_valid            (streamArbiter_9_io_output_valid                     ), //i
    .io_writeReq_payload_inputId  (streamArbiter_9_io_output_payload_inputId[7:0]      ), //i
    .io_writeReq_payload_outputId (streamArbiter_9_io_output_payload_outputId[31:0]    ), //i
    .clk                          (clk                                                 ), //i
    .reset                        (reset                                               )  //i
  );
  StreamFifoLowLatency_3 flowStateUpdate_toStream_fifo (
    .io_push_valid            (flowStateUpdate_toStream_valid                             ), //i
    .io_push_ready            (flowStateUpdate_toStream_fifo_io_push_ready                ), //o
    .io_push_payload_inputId  (flowStateUpdate_toStream_payload_inputId[7:0]              ), //i
    .io_push_payload_outputId (flowStateUpdate_toStream_payload_outputId[31:0]            ), //i
    .io_pop_valid             (flowStateUpdate_toStream_fifo_io_pop_valid                 ), //o
    .io_pop_ready             (streamArbiter_9_io_inputs_1_ready                          ), //i
    .io_pop_payload_inputId   (flowStateUpdate_toStream_fifo_io_pop_payload_inputId[7:0]  ), //o
    .io_pop_payload_outputId  (flowStateUpdate_toStream_fifo_io_pop_payload_outputId[31:0]), //o
    .io_flush                 (1'b0                                                       ), //i
    .io_occupancy             (flowStateUpdate_toStream_fifo_io_occupancy[1:0]            ), //o
    .io_availability          (flowStateUpdate_toStream_fifo_io_availability[1:0]         ), //o
    .clk                      (clk                                                        ), //i
    .reset                    (reset                                                      )  //i
  );
  StreamArbiter_3 streamArbiter_9 (
    .io_inputs_0_valid            (flowStateControl_toStream_valid                            ), //i
    .io_inputs_0_ready            (streamArbiter_9_io_inputs_0_ready                          ), //o
    .io_inputs_0_payload_inputId  (flowStateControl_toStream_payload_inputId[7:0]             ), //i
    .io_inputs_0_payload_outputId (flowStateControl_toStream_payload_outputId[31:0]           ), //i
    .io_inputs_1_valid            (flowStateUpdate_toStream_fifo_io_pop_valid                 ), //i
    .io_inputs_1_ready            (streamArbiter_9_io_inputs_1_ready                          ), //o
    .io_inputs_1_payload_inputId  (flowStateUpdate_toStream_fifo_io_pop_payload_inputId[7:0]  ), //i
    .io_inputs_1_payload_outputId (flowStateUpdate_toStream_fifo_io_pop_payload_outputId[31:0]), //i
    .io_output_valid              (streamArbiter_9_io_output_valid                            ), //o
    .io_output_ready              (1'b1                                                       ), //i
    .io_output_payload_inputId    (streamArbiter_9_io_output_payload_inputId[7:0]             ), //o
    .io_output_payload_outputId   (streamArbiter_9_io_output_payload_outputId[31:0]           ), //o
    .io_chosen                    (streamArbiter_9_io_chosen                                  ), //o
    .io_chosenOH                  (streamArbiter_9_io_chosenOH[1:0]                           ), //o
    .clk                          (clk                                                        ), //i
    .reset                        (reset                                                      )  //i
  );
  Mapper_7 brainStateMem (
    .io_readReq_valid             (io_request_fork_io_outputs_3_map_toFlow_valid       ), //i
    .io_readReq_payload           (io_request_fork_io_outputs_3_map_toFlow_payload[2:0]), //i
    .io_readRes_valid             (brainStateMem_io_readRes_valid                      ), //o
    .io_readRes_payload           (brainStateMem_io_readRes_payload[31:0]              ), //o
    .io_writeReq_valid            (streamArbiter_10_io_output_valid                    ), //i
    .io_writeReq_payload_inputId  (streamArbiter_10_io_output_payload_inputId[2:0]     ), //i
    .io_writeReq_payload_outputId (streamArbiter_10_io_output_payload_outputId[31:0]   ), //i
    .clk                          (clk                                                 ), //i
    .reset                        (reset                                               )  //i
  );
  StreamFifoLowLatency_4 brainStateUpdate_toStream_fifo (
    .io_push_valid            (brainStateUpdate_toStream_valid                             ), //i
    .io_push_ready            (brainStateUpdate_toStream_fifo_io_push_ready                ), //o
    .io_push_payload_inputId  (brainStateUpdate_toStream_payload_inputId[2:0]              ), //i
    .io_push_payload_outputId (brainStateUpdate_toStream_payload_outputId[31:0]            ), //i
    .io_pop_valid             (brainStateUpdate_toStream_fifo_io_pop_valid                 ), //o
    .io_pop_ready             (streamArbiter_10_io_inputs_1_ready                          ), //i
    .io_pop_payload_inputId   (brainStateUpdate_toStream_fifo_io_pop_payload_inputId[2:0]  ), //o
    .io_pop_payload_outputId  (brainStateUpdate_toStream_fifo_io_pop_payload_outputId[31:0]), //o
    .io_flush                 (1'b0                                                        ), //i
    .io_occupancy             (brainStateUpdate_toStream_fifo_io_occupancy[1:0]            ), //o
    .io_availability          (brainStateUpdate_toStream_fifo_io_availability[1:0]         ), //o
    .clk                      (clk                                                         ), //i
    .reset                    (reset                                                       )  //i
  );
  StreamArbiter_4 streamArbiter_10 (
    .io_inputs_0_valid            (brainStateControl_toStream_valid                            ), //i
    .io_inputs_0_ready            (streamArbiter_10_io_inputs_0_ready                          ), //o
    .io_inputs_0_payload_inputId  (brainStateControl_toStream_payload_inputId[2:0]             ), //i
    .io_inputs_0_payload_outputId (brainStateControl_toStream_payload_outputId[31:0]           ), //i
    .io_inputs_1_valid            (brainStateUpdate_toStream_fifo_io_pop_valid                 ), //i
    .io_inputs_1_ready            (streamArbiter_10_io_inputs_1_ready                          ), //o
    .io_inputs_1_payload_inputId  (brainStateUpdate_toStream_fifo_io_pop_payload_inputId[2:0]  ), //i
    .io_inputs_1_payload_outputId (brainStateUpdate_toStream_fifo_io_pop_payload_outputId[31:0]), //i
    .io_output_valid              (streamArbiter_10_io_output_valid                            ), //o
    .io_output_ready              (1'b1                                                        ), //i
    .io_output_payload_inputId    (streamArbiter_10_io_output_payload_inputId[2:0]             ), //o
    .io_output_payload_outputId   (streamArbiter_10_io_output_payload_outputId[31:0]           ), //o
    .io_chosen                    (streamArbiter_10_io_chosen                                  ), //o
    .io_chosenOH                  (streamArbiter_10_io_chosenOH[1:0]                           ), //o
    .clk                          (clk                                                         ), //i
    .reset                        (reset                                                       )  //i
  );
  StreamFork_1 io_control_fork (
    .io_input_valid                (io_control_valid                                  ), //i
    .io_input_ready                (io_control_fork_io_input_ready                    ), //o
    .io_input_payload_command      (io_control_payload_command[2:0]                   ), //i
    .io_input_payload_engineId     (io_control_payload_engineId[1:0]                  ), //i
    .io_input_payload_vPifoId      (io_control_payload_vPifoId[2:0]                   ), //i
    .io_input_payload_flowId       (io_control_payload_flowId[4:0]                    ), //i
    .io_input_payload_data         (io_control_payload_data[31:0]                     ), //i
    .io_outputs_0_valid            (io_control_fork_io_outputs_0_valid                ), //o
    .io_outputs_0_ready            (io_control_fork_io_outputs_0_ready                ), //i
    .io_outputs_0_payload_command  (io_control_fork_io_outputs_0_payload_command[2:0] ), //o
    .io_outputs_0_payload_engineId (io_control_fork_io_outputs_0_payload_engineId[1:0]), //o
    .io_outputs_0_payload_vPifoId  (io_control_fork_io_outputs_0_payload_vPifoId[2:0] ), //o
    .io_outputs_0_payload_flowId   (io_control_fork_io_outputs_0_payload_flowId[4:0]  ), //o
    .io_outputs_0_payload_data     (io_control_fork_io_outputs_0_payload_data[31:0]   ), //o
    .io_outputs_1_valid            (io_control_fork_io_outputs_1_valid                ), //o
    .io_outputs_1_ready            (io_control_fork_io_outputs_1_ready                ), //i
    .io_outputs_1_payload_command  (io_control_fork_io_outputs_1_payload_command[2:0] ), //o
    .io_outputs_1_payload_engineId (io_control_fork_io_outputs_1_payload_engineId[1:0]), //o
    .io_outputs_1_payload_vPifoId  (io_control_fork_io_outputs_1_payload_vPifoId[2:0] ), //o
    .io_outputs_1_payload_flowId   (io_control_fork_io_outputs_1_payload_flowId[4:0]  ), //o
    .io_outputs_1_payload_data     (io_control_fork_io_outputs_1_payload_data[31:0]   ), //o
    .io_outputs_2_valid            (io_control_fork_io_outputs_2_valid                ), //o
    .io_outputs_2_ready            (io_control_fork_io_outputs_2_ready                ), //i
    .io_outputs_2_payload_command  (io_control_fork_io_outputs_2_payload_command[2:0] ), //o
    .io_outputs_2_payload_engineId (io_control_fork_io_outputs_2_payload_engineId[1:0]), //o
    .io_outputs_2_payload_vPifoId  (io_control_fork_io_outputs_2_payload_vPifoId[2:0] ), //o
    .io_outputs_2_payload_flowId   (io_control_fork_io_outputs_2_payload_flowId[4:0]  ), //o
    .io_outputs_2_payload_data     (io_control_fork_io_outputs_2_payload_data[31:0]   ), //o
    .clk                           (clk                                               ), //i
    .reset                         (reset                                             )  //i
  );
  StreamFifoLowLatency_5 engineMapper_io_readRes_toStream_fifo (
    .io_push_valid   (engineMapper_io_readRes_toStream_valid                    ), //i
    .io_push_ready   (engineMapper_io_readRes_toStream_fifo_io_push_ready       ), //o
    .io_push_payload (engineMapper_io_readRes_toStream_payload[1:0]             ), //i
    .io_pop_valid    (engineMapper_io_readRes_toStream_fifo_io_pop_valid        ), //o
    .io_pop_ready    (_zz_io_pop_ready                                          ), //i
    .io_pop_payload  (engineMapper_io_readRes_toStream_fifo_io_pop_payload[1:0] ), //o
    .io_flush        (1'b0                                                      ), //i
    .io_occupancy    (engineMapper_io_readRes_toStream_fifo_io_occupancy[1:0]   ), //o
    .io_availability (engineMapper_io_readRes_toStream_fifo_io_availability[1:0]), //o
    .clk             (clk                                                       ), //i
    .reset           (reset                                                     )  //i
  );
  StreamFifoLowLatency_6 brainStateMem_io_readRes_toStream_fifo (
    .io_push_valid   (brainStateMem_io_readRes_toStream_valid                    ), //i
    .io_push_ready   (brainStateMem_io_readRes_toStream_fifo_io_push_ready       ), //o
    .io_push_payload (brainStateMem_io_readRes_toStream_payload[31:0]            ), //i
    .io_pop_valid    (brainStateMem_io_readRes_toStream_fifo_io_pop_valid        ), //o
    .io_pop_ready    (_zz_io_pop_ready                                           ), //i
    .io_pop_payload  (brainStateMem_io_readRes_toStream_fifo_io_pop_payload[31:0]), //o
    .io_flush        (1'b0                                                       ), //i
    .io_occupancy    (brainStateMem_io_readRes_toStream_fifo_io_occupancy[1:0]   ), //o
    .io_availability (brainStateMem_io_readRes_toStream_fifo_io_availability[1:0]), //o
    .clk             (clk                                                        ), //i
    .reset           (reset                                                      )  //i
  );
  StreamFifoLowLatency_6 engineCAM_io_readRes_toStream_fifo (
    .io_push_valid   (engineCAM_io_readRes_toStream_valid                    ), //i
    .io_push_ready   (engineCAM_io_readRes_toStream_fifo_io_push_ready       ), //o
    .io_push_payload (engineCAM_io_readRes_toStream_payload[31:0]            ), //i
    .io_pop_valid    (engineCAM_io_readRes_toStream_fifo_io_pop_valid        ), //o
    .io_pop_ready    (_zz_io_pop_ready                                       ), //i
    .io_pop_payload  (engineCAM_io_readRes_toStream_fifo_io_pop_payload[31:0]), //o
    .io_flush        (1'b0                                                   ), //i
    .io_occupancy    (engineCAM_io_readRes_toStream_fifo_io_occupancy[1:0]   ), //o
    .io_availability (engineCAM_io_readRes_toStream_fifo_io_availability[1:0]), //o
    .clk             (clk                                                    ), //i
    .reset           (reset                                                  )  //i
  );
  StreamFifoLowLatency_8 lastVirtualMapper_io_readRes_toStream_fifo (
    .io_push_valid   (lastVirtualMapper_io_readRes_toStream_valid                    ), //i
    .io_push_ready   (lastVirtualMapper_io_readRes_toStream_fifo_io_push_ready       ), //o
    .io_push_payload (lastVirtualMapper_io_readRes_toStream_payload[7:0]             ), //i
    .io_pop_valid    (lastVirtualMapper_io_readRes_toStream_fifo_io_pop_valid        ), //o
    .io_pop_ready    (_zz_io_pop_ready                                               ), //i
    .io_pop_payload  (lastVirtualMapper_io_readRes_toStream_fifo_io_pop_payload[7:0] ), //o
    .io_flush        (1'b0                                                           ), //i
    .io_occupancy    (lastVirtualMapper_io_readRes_toStream_fifo_io_occupancy[1:0]   ), //o
    .io_availability (lastVirtualMapper_io_readRes_toStream_fifo_io_availability[1:0]), //o
    .clk             (clk                                                            ), //i
    .reset           (reset                                                          )  //i
  );
  StreamFifoLowLatency_9 io_outputs_4_fifo (
    .io_push_valid           (io_request_fork_io_outputs_4_valid               ), //i
    .io_push_ready           (io_outputs_4_fifo_io_push_ready                  ), //o
    .io_push_payload_vpifoId (io_request_fork_io_outputs_4_payload_vpifoId[2:0]), //i
    .io_push_payload_flowId  (io_request_fork_io_outputs_4_payload_flowId[4:0] ), //i
    .io_pop_valid            (io_outputs_4_fifo_io_pop_valid                   ), //o
    .io_pop_ready            (_zz_io_pop_ready                                 ), //i
    .io_pop_payload_vpifoId  (io_outputs_4_fifo_io_pop_payload_vpifoId[2:0]    ), //o
    .io_pop_payload_flowId   (io_outputs_4_fifo_io_pop_payload_flowId[4:0]     ), //o
    .io_flush                (1'b0                                             ), //i
    .io_occupancy            (io_outputs_4_fifo_io_occupancy[1:0]              ), //o
    .io_availability         (io_outputs_4_fifo_io_availability[1:0]           ), //o
    .clk                     (clk                                              ), //i
    .reset                   (reset                                            )  //i
  );
  `ifndef SYNTHESIS
  always @(*) begin
    case(io_control_payload_command)
      ControlCommand_UpdateMapperPre : io_control_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_control_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_control_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_control_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_control_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_control_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_control_payload_command_string = "UpdateBrainFlowState";
      default : io_control_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_control_fork_io_outputs_0_takeWhen_payload_command)
      ControlCommand_UpdateMapperPre : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateBrainFlowState";
      default : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_control_fork_io_outputs_1_takeWhen_payload_command)
      ControlCommand_UpdateMapperPre : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateBrainFlowState";
      default : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_control_fork_io_outputs_2_takeWhen_payload_command)
      ControlCommand_UpdateMapperPre : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateBrainFlowState";
      default : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(switch_PifoEngine_l367)
      BrainType_NOP : switch_PifoEngine_l367_string = "NOP ";
      BrainType_WFQ : switch_PifoEngine_l367_string = "WFQ ";
      BrainType_SP : switch_PifoEngine_l367_string = "SP  ";
      BrainType_FIFO : switch_PifoEngine_l367_string = "FIFO";
      default : switch_PifoEngine_l367_string = "????";
    endcase
  end
  always @(*) begin
    case(_zz_switch_PifoEngine_l367)
      BrainType_NOP : _zz_switch_PifoEngine_l367_string = "NOP ";
      BrainType_WFQ : _zz_switch_PifoEngine_l367_string = "WFQ ";
      BrainType_SP : _zz_switch_PifoEngine_l367_string = "SP  ";
      BrainType_FIFO : _zz_switch_PifoEngine_l367_string = "FIFO";
      default : _zz_switch_PifoEngine_l367_string = "????";
    endcase
  end
  `endif

  assign io_request_ready = io_request_fork_io_input_ready;
  assign io_request_fork_io_outputs_0_map_valid = io_request_fork_io_outputs_0_valid;
  assign io_request_fork_io_outputs_0_map_payload = io_request_fork_io_outputs_0_payload_vpifoId;
  assign io_request_fork_io_outputs_0_map_ready = 1'b1;
  assign io_request_fork_io_outputs_0_map_toFlow_valid = io_request_fork_io_outputs_0_map_valid;
  assign io_request_fork_io_outputs_0_map_toFlow_payload = io_request_fork_io_outputs_0_map_payload;
  assign io_poped_takeWhen_valid = (io_poped_valid && (! (! io_poped_payload_exist)));
  assign io_poped_takeWhen_payload_exist = io_poped_payload_exist;
  assign io_poped_takeWhen_payload_priority = io_poped_payload_priority;
  assign io_poped_takeWhen_payload_data = io_poped_payload_data;
  assign io_poped_takeWhen_payload_port = io_poped_payload_port;
  assign io_request_fork_io_outputs_1_map_valid = io_request_fork_io_outputs_1_valid;
  assign io_request_fork_io_outputs_1_map_payload = io_request_fork_io_outputs_1_payload_vpifoId;
  assign io_request_fork_io_outputs_1_map_ready = 1'b1;
  assign io_request_fork_io_outputs_1_map_toFlow_valid = io_request_fork_io_outputs_1_map_valid;
  assign io_request_fork_io_outputs_1_map_toFlow_payload = io_request_fork_io_outputs_1_map_payload;
  assign io_request_fork_io_outputs_2_map_valid = io_request_fork_io_outputs_2_valid;
  assign io_request_fork_io_outputs_2_map_payload = {io_request_fork_io_outputs_2_payload_vpifoId,io_request_fork_io_outputs_2_payload_flowId};
  assign io_request_fork_io_outputs_2_map_ready = 1'b1;
  assign io_request_fork_io_outputs_2_map_toFlow_valid = io_request_fork_io_outputs_2_map_valid;
  assign io_request_fork_io_outputs_2_map_toFlow_payload = io_request_fork_io_outputs_2_map_payload;
  assign flowStateControl_toStream_valid = flowStateControl_valid;
  assign flowStateControl_toStream_payload_inputId = flowStateControl_payload_inputId;
  assign flowStateControl_toStream_payload_outputId = flowStateControl_payload_outputId;
  assign flowStateUpdate_toStream_valid = flowStateUpdate_valid;
  assign flowStateUpdate_toStream_payload_inputId = flowStateUpdate_payload_inputId;
  assign flowStateUpdate_toStream_payload_outputId = flowStateUpdate_payload_outputId;
  assign flowStateUpdate_toStream_ready = flowStateUpdate_toStream_fifo_io_push_ready;
  assign flowStateControl_toStream_ready = streamArbiter_9_io_inputs_0_ready;
  assign io_request_fork_io_outputs_3_map_valid = io_request_fork_io_outputs_3_valid;
  assign io_request_fork_io_outputs_3_map_payload = io_request_fork_io_outputs_3_payload_vpifoId;
  assign io_request_fork_io_outputs_3_map_ready = 1'b1;
  assign io_request_fork_io_outputs_3_map_toFlow_valid = io_request_fork_io_outputs_3_map_valid;
  assign io_request_fork_io_outputs_3_map_toFlow_payload = io_request_fork_io_outputs_3_map_payload;
  assign brainStateControl_toStream_valid = brainStateControl_valid;
  assign brainStateControl_toStream_payload_inputId = brainStateControl_payload_inputId;
  assign brainStateControl_toStream_payload_outputId = brainStateControl_payload_outputId;
  assign brainStateUpdate_toStream_valid = brainStateUpdate_valid;
  assign brainStateUpdate_toStream_payload_inputId = brainStateUpdate_payload_inputId;
  assign brainStateUpdate_toStream_payload_outputId = brainStateUpdate_payload_outputId;
  assign brainStateUpdate_toStream_ready = brainStateUpdate_toStream_fifo_io_push_ready;
  assign brainStateControl_toStream_ready = streamArbiter_10_io_inputs_0_ready;
  assign io_control_ready = io_control_fork_io_input_ready;
  assign when_Stream_l581 = (! (io_control_fork_io_outputs_0_payload_command == ControlCommand_UpdateBrainEngine));
  always @(*) begin
    io_control_fork_io_outputs_0_takeWhen_valid = io_control_fork_io_outputs_0_valid;
    if(when_Stream_l581) begin
      io_control_fork_io_outputs_0_takeWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    io_control_fork_io_outputs_0_ready = io_control_fork_io_outputs_0_takeWhen_ready;
    if(when_Stream_l581) begin
      io_control_fork_io_outputs_0_ready = 1'b1;
    end
  end

  assign io_control_fork_io_outputs_0_takeWhen_payload_command = io_control_fork_io_outputs_0_payload_command;
  assign io_control_fork_io_outputs_0_takeWhen_payload_engineId = io_control_fork_io_outputs_0_payload_engineId;
  assign io_control_fork_io_outputs_0_takeWhen_payload_vPifoId = io_control_fork_io_outputs_0_payload_vPifoId;
  assign io_control_fork_io_outputs_0_takeWhen_payload_flowId = io_control_fork_io_outputs_0_payload_flowId;
  assign io_control_fork_io_outputs_0_takeWhen_payload_data = io_control_fork_io_outputs_0_payload_data;
  assign io_control_fork_io_outputs_0_takeWhen_ready = 1'b1;
  assign engineMapper_io_writeReq_payload_outputId = io_control_fork_io_outputs_0_takeWhen_payload_data[1:0];
  assign when_Stream_l581_1 = (! (io_control_fork_io_outputs_1_payload_command == ControlCommand_UpdateBrainFlowState));
  always @(*) begin
    io_control_fork_io_outputs_1_takeWhen_valid = io_control_fork_io_outputs_1_valid;
    if(when_Stream_l581_1) begin
      io_control_fork_io_outputs_1_takeWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    io_control_fork_io_outputs_1_ready = io_control_fork_io_outputs_1_takeWhen_ready;
    if(when_Stream_l581_1) begin
      io_control_fork_io_outputs_1_ready = 1'b1;
    end
  end

  assign io_control_fork_io_outputs_1_takeWhen_payload_command = io_control_fork_io_outputs_1_payload_command;
  assign io_control_fork_io_outputs_1_takeWhen_payload_engineId = io_control_fork_io_outputs_1_payload_engineId;
  assign io_control_fork_io_outputs_1_takeWhen_payload_vPifoId = io_control_fork_io_outputs_1_payload_vPifoId;
  assign io_control_fork_io_outputs_1_takeWhen_payload_flowId = io_control_fork_io_outputs_1_payload_flowId;
  assign io_control_fork_io_outputs_1_takeWhen_payload_data = io_control_fork_io_outputs_1_payload_data;
  assign io_control_fork_io_outputs_1_takeWhen_ready = 1'b1;
  assign flowStateControl_valid = io_control_fork_io_outputs_1_takeWhen_valid;
  assign flowStateControl_payload_inputId = {io_control_fork_io_outputs_1_takeWhen_payload_vPifoId,io_control_fork_io_outputs_1_takeWhen_payload_flowId};
  assign flowStateControl_payload_outputId = io_control_fork_io_outputs_1_takeWhen_payload_data;
  assign when_Stream_l581_2 = (! (io_control_fork_io_outputs_2_payload_command == ControlCommand_UpdateBrainState));
  always @(*) begin
    io_control_fork_io_outputs_2_takeWhen_valid = io_control_fork_io_outputs_2_valid;
    if(when_Stream_l581_2) begin
      io_control_fork_io_outputs_2_takeWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    io_control_fork_io_outputs_2_ready = io_control_fork_io_outputs_2_takeWhen_ready;
    if(when_Stream_l581_2) begin
      io_control_fork_io_outputs_2_ready = 1'b1;
    end
  end

  assign io_control_fork_io_outputs_2_takeWhen_payload_command = io_control_fork_io_outputs_2_payload_command;
  assign io_control_fork_io_outputs_2_takeWhen_payload_engineId = io_control_fork_io_outputs_2_payload_engineId;
  assign io_control_fork_io_outputs_2_takeWhen_payload_vPifoId = io_control_fork_io_outputs_2_payload_vPifoId;
  assign io_control_fork_io_outputs_2_takeWhen_payload_flowId = io_control_fork_io_outputs_2_payload_flowId;
  assign io_control_fork_io_outputs_2_takeWhen_payload_data = io_control_fork_io_outputs_2_payload_data;
  assign io_control_fork_io_outputs_2_takeWhen_ready = 1'b1;
  assign brainStateControl_valid = io_control_fork_io_outputs_2_takeWhen_valid;
  assign brainStateControl_payload_inputId = io_control_fork_io_outputs_2_takeWhen_payload_vPifoId;
  assign brainStateControl_payload_outputId = io_control_fork_io_outputs_2_takeWhen_payload_data;
  assign engineMapper_io_readRes_toStream_valid = engineMapper_io_readRes_valid;
  assign engineMapper_io_readRes_toStream_payload = engineMapper_io_readRes_payload;
  assign engineMapper_io_readRes_toStream_ready = engineMapper_io_readRes_toStream_fifo_io_push_ready;
  assign brainStateMem_io_readRes_toStream_valid = brainStateMem_io_readRes_valid;
  assign brainStateMem_io_readRes_toStream_payload = brainStateMem_io_readRes_payload;
  assign brainStateMem_io_readRes_toStream_ready = brainStateMem_io_readRes_toStream_fifo_io_push_ready;
  assign engineCAM_io_readRes_toStream_valid = engineCAM_io_readRes_valid;
  assign engineCAM_io_readRes_toStream_payload = engineCAM_io_readRes_payload;
  assign engineCAM_io_readRes_toStream_ready = engineCAM_io_readRes_toStream_fifo_io_push_ready;
  assign lastVirtualMapper_io_readRes_toStream_valid = lastVirtualMapper_io_readRes_valid;
  assign lastVirtualMapper_io_readRes_toStream_payload = lastVirtualMapper_io_readRes_payload;
  assign lastVirtualMapper_io_readRes_toStream_ready = lastVirtualMapper_io_readRes_toStream_fifo_io_push_ready;
  assign _zz_io_pop_ready = (_zz_engineStream_valid && engineStream_ready);
  assign _zz_engineStream_valid = ((((engineMapper_io_readRes_toStream_fifo_io_pop_valid && brainStateMem_io_readRes_toStream_fifo_io_pop_valid) && engineCAM_io_readRes_toStream_fifo_io_pop_valid) && lastVirtualMapper_io_readRes_toStream_fifo_io_pop_valid) && io_outputs_4_fifo_io_pop_valid);
  assign engineStream_valid = _zz_engineStream_valid;
  assign engineStream_payload_pifoId = io_outputs_4_fifo_io_pop_payload_vpifoId;
  assign engineStream_payload_flowId = io_outputs_4_fifo_io_pop_payload_flowId;
  assign engineStream_payload_engineId = engineMapper_io_readRes_toStream_fifo_io_pop_payload;
  assign engineStream_payload_flowState = engineCAM_io_readRes_toStream_fifo_io_pop_payload;
  assign engineStream_payload_brainState = brainStateMem_io_readRes_toStream_fifo_io_pop_payload;
  assign engineStream_payload_virutalTime = lastVirtualMapper_io_readRes_toStream_fifo_io_pop_payload;
  always @(*) begin
    _zz_outStream_payload_entry_priority = 8'h0;
    case(switch_PifoEngine_l367)
      BrainType_SP : begin
        _zz_outStream_payload_entry_priority = engineStream_payload_flowState[7:0];
      end
      BrainType_WFQ : begin
        _zz_outStream_payload_entry_priority = _zz_outStream_payload_entry_priority_3;
      end
      BrainType_FIFO : begin
        _zz_outStream_payload_entry_priority = _zz_outStream_payload_entry_priority_4;
      end
      default : begin
      end
    endcase
  end

  always @(*) begin
    _zz_outStream_payload_flowUpdate_flow_outputId = 32'h0;
    case(switch_PifoEngine_l367)
      BrainType_WFQ : begin
        _zz_outStream_payload_flowUpdate_flow_outputId = {24'd0, _zz_outStream_payload_entry_priority_3};
      end
      default : begin
      end
    endcase
  end

  always @(*) begin
    _zz_outStream_payload_flowUpdate_update = 1'b0;
    case(switch_PifoEngine_l367)
      BrainType_WFQ : begin
        _zz_outStream_payload_flowUpdate_update = 1'b1;
      end
      default : begin
      end
    endcase
  end

  always @(*) begin
    _zz_outStream_payload_brainUpdate_brain_outputId = 32'h0;
    case(switch_PifoEngine_l367)
      BrainType_FIFO : begin
        _zz_outStream_payload_brainUpdate_brain_outputId = {24'd0, _zz_outStream_payload_entry_priority_4};
      end
      default : begin
      end
    endcase
  end

  always @(*) begin
    _zz_outStream_payload_brainUpdate_update = 1'b0;
    case(switch_PifoEngine_l367)
      BrainType_FIFO : begin
        _zz_outStream_payload_brainUpdate_update = 1'b1;
      end
      default : begin
      end
    endcase
  end

  assign _zz_switch_PifoEngine_l367 = engineStream_payload_engineId;
  assign switch_PifoEngine_l367 = _zz_switch_PifoEngine_l367;
  assign _zz_outStream_payload_entry_priority_1 = engineStream_payload_virutalTime;
  assign _zz_outStream_payload_entry_priority_2 = engineStream_payload_flowState[7:0];
  assign _zz_outStream_payload_entry_priority_3 = (((_zz_outStream_payload_entry_priority_2 < _zz_outStream_payload_entry_priority_1) ? _zz_outStream_payload_entry_priority_1 : _zz_outStream_payload_entry_priority_2) + 8'h10);
  assign _zz_outStream_payload_entry_priority_4 = (_zz__zz_outStream_payload_entry_priority_4 + 8'h01);
  assign outStream_valid = engineStream_valid;
  assign engineStream_ready = outStream_ready;
  assign outStream_payload_entry_priority = _zz_outStream_payload_entry_priority;
  assign outStream_payload_entry_data = engineStream_payload_flowId;
  assign outStream_payload_entry_port = engineStream_payload_pifoId;
  assign outStream_payload_flowUpdate_flow_inputId = {engineStream_payload_pifoId,engineStream_payload_flowId};
  assign outStream_payload_flowUpdate_flow_outputId = _zz_outStream_payload_flowUpdate_flow_outputId;
  assign outStream_payload_flowUpdate_update = _zz_outStream_payload_flowUpdate_update;
  assign outStream_payload_brainUpdate_brain_inputId = engineStream_payload_pifoId;
  assign outStream_payload_brainUpdate_brain_outputId = _zz_outStream_payload_brainUpdate_brain_outputId;
  assign outStream_payload_brainUpdate_update = _zz_outStream_payload_brainUpdate_update;
  always @(*) begin
    outStream_ready = 1'b1;
    if(when_Stream_l1253) begin
      outStream_ready = 1'b0;
    end
    if(when_Stream_l1253_1) begin
      outStream_ready = 1'b0;
    end
    if(when_Stream_l1253_2) begin
      outStream_ready = 1'b0;
    end
  end

  assign when_Stream_l1253 = ((! output_ready) && outStream_fork3_logic_linkEnable_0);
  assign when_Stream_l1253_1 = ((! flowUpdates_ready) && outStream_fork3_logic_linkEnable_1);
  assign when_Stream_l1253_2 = ((! brainUpdates_ready) && outStream_fork3_logic_linkEnable_2);
  assign output_valid = (outStream_valid && outStream_fork3_logic_linkEnable_0);
  assign output_payload_entry_priority = outStream_payload_entry_priority;
  assign output_payload_entry_data = outStream_payload_entry_data;
  assign output_payload_entry_port = outStream_payload_entry_port;
  assign output_payload_flowUpdate_flow_inputId = outStream_payload_flowUpdate_flow_inputId;
  assign output_payload_flowUpdate_flow_outputId = outStream_payload_flowUpdate_flow_outputId;
  assign output_payload_flowUpdate_update = outStream_payload_flowUpdate_update;
  assign output_payload_brainUpdate_brain_inputId = outStream_payload_brainUpdate_brain_inputId;
  assign output_payload_brainUpdate_brain_outputId = outStream_payload_brainUpdate_brain_outputId;
  assign output_payload_brainUpdate_update = outStream_payload_brainUpdate_update;
  assign output_fire = (output_valid && output_ready);
  assign flowUpdates_valid = (outStream_valid && outStream_fork3_logic_linkEnable_1);
  assign flowUpdates_payload_entry_priority = outStream_payload_entry_priority;
  assign flowUpdates_payload_entry_data = outStream_payload_entry_data;
  assign flowUpdates_payload_entry_port = outStream_payload_entry_port;
  assign flowUpdates_payload_flowUpdate_flow_inputId = outStream_payload_flowUpdate_flow_inputId;
  assign flowUpdates_payload_flowUpdate_flow_outputId = outStream_payload_flowUpdate_flow_outputId;
  assign flowUpdates_payload_flowUpdate_update = outStream_payload_flowUpdate_update;
  assign flowUpdates_payload_brainUpdate_brain_inputId = outStream_payload_brainUpdate_brain_inputId;
  assign flowUpdates_payload_brainUpdate_brain_outputId = outStream_payload_brainUpdate_brain_outputId;
  assign flowUpdates_payload_brainUpdate_update = outStream_payload_brainUpdate_update;
  assign flowUpdates_fire = (flowUpdates_valid && flowUpdates_ready);
  assign brainUpdates_valid = (outStream_valid && outStream_fork3_logic_linkEnable_2);
  assign brainUpdates_payload_entry_priority = outStream_payload_entry_priority;
  assign brainUpdates_payload_entry_data = outStream_payload_entry_data;
  assign brainUpdates_payload_entry_port = outStream_payload_entry_port;
  assign brainUpdates_payload_flowUpdate_flow_inputId = outStream_payload_flowUpdate_flow_inputId;
  assign brainUpdates_payload_flowUpdate_flow_outputId = outStream_payload_flowUpdate_flow_outputId;
  assign brainUpdates_payload_flowUpdate_update = outStream_payload_flowUpdate_update;
  assign brainUpdates_payload_brainUpdate_brain_inputId = outStream_payload_brainUpdate_brain_inputId;
  assign brainUpdates_payload_brainUpdate_brain_outputId = outStream_payload_brainUpdate_brain_outputId;
  assign brainUpdates_payload_brainUpdate_update = outStream_payload_brainUpdate_update;
  assign brainUpdates_fire = (brainUpdates_valid && brainUpdates_ready);
  assign when_Stream_l581_3 = (output_payload_entry_priority == 8'h0);
  always @(*) begin
    output_throwWhen_valid = output_valid;
    if(when_Stream_l581_3) begin
      output_throwWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    output_ready = output_throwWhen_ready;
    if(when_Stream_l581_3) begin
      output_ready = 1'b1;
    end
  end

  assign output_throwWhen_payload_entry_priority = output_payload_entry_priority;
  assign output_throwWhen_payload_entry_data = output_payload_entry_data;
  assign output_throwWhen_payload_entry_port = output_payload_entry_port;
  assign output_throwWhen_payload_flowUpdate_flow_inputId = output_payload_flowUpdate_flow_inputId;
  assign output_throwWhen_payload_flowUpdate_flow_outputId = output_payload_flowUpdate_flow_outputId;
  assign output_throwWhen_payload_flowUpdate_update = output_payload_flowUpdate_update;
  assign output_throwWhen_payload_brainUpdate_brain_inputId = output_payload_brainUpdate_brain_inputId;
  assign output_throwWhen_payload_brainUpdate_brain_outputId = output_payload_brainUpdate_brain_outputId;
  assign output_throwWhen_payload_brainUpdate_update = output_payload_brainUpdate_update;
  assign output_throwWhen_map_valid = output_throwWhen_valid;
  assign output_throwWhen_ready = output_throwWhen_map_ready;
  assign output_throwWhen_map_payload_priority = output_throwWhen_payload_entry_priority;
  assign output_throwWhen_map_payload_data = output_throwWhen_payload_entry_data;
  assign output_throwWhen_map_payload_port = output_throwWhen_payload_entry_port;
  assign io_response_valid = output_throwWhen_map_valid;
  assign output_throwWhen_map_ready = io_response_ready;
  assign io_response_payload_priority = output_throwWhen_map_payload_priority;
  assign io_response_payload_data = output_throwWhen_map_payload_data;
  assign io_response_payload_port = output_throwWhen_map_payload_port;
  assign when_Stream_l581_4 = (! flowUpdates_payload_flowUpdate_update);
  always @(*) begin
    flowUpdates_throwWhen_valid = flowUpdates_valid;
    if(when_Stream_l581_4) begin
      flowUpdates_throwWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    flowUpdates_ready = flowUpdates_throwWhen_ready;
    if(when_Stream_l581_4) begin
      flowUpdates_ready = 1'b1;
    end
  end

  assign flowUpdates_throwWhen_payload_entry_priority = flowUpdates_payload_entry_priority;
  assign flowUpdates_throwWhen_payload_entry_data = flowUpdates_payload_entry_data;
  assign flowUpdates_throwWhen_payload_entry_port = flowUpdates_payload_entry_port;
  assign flowUpdates_throwWhen_payload_flowUpdate_flow_inputId = flowUpdates_payload_flowUpdate_flow_inputId;
  assign flowUpdates_throwWhen_payload_flowUpdate_flow_outputId = flowUpdates_payload_flowUpdate_flow_outputId;
  assign flowUpdates_throwWhen_payload_flowUpdate_update = flowUpdates_payload_flowUpdate_update;
  assign flowUpdates_throwWhen_payload_brainUpdate_brain_inputId = flowUpdates_payload_brainUpdate_brain_inputId;
  assign flowUpdates_throwWhen_payload_brainUpdate_brain_outputId = flowUpdates_payload_brainUpdate_brain_outputId;
  assign flowUpdates_throwWhen_payload_brainUpdate_update = flowUpdates_payload_brainUpdate_update;
  assign flowUpdates_throwWhen_map_valid = flowUpdates_throwWhen_valid;
  assign flowUpdates_throwWhen_ready = flowUpdates_throwWhen_map_ready;
  assign flowUpdates_throwWhen_map_payload_inputId = flowUpdates_throwWhen_payload_flowUpdate_flow_inputId;
  assign flowUpdates_throwWhen_map_payload_outputId = flowUpdates_throwWhen_payload_flowUpdate_flow_outputId;
  assign flowUpdates_throwWhen_map_ready = 1'b1;
  assign flowUpdates_throwWhen_map_toFlow_valid = flowUpdates_throwWhen_map_valid;
  assign flowUpdates_throwWhen_map_toFlow_payload_inputId = flowUpdates_throwWhen_map_payload_inputId;
  assign flowUpdates_throwWhen_map_toFlow_payload_outputId = flowUpdates_throwWhen_map_payload_outputId;
  assign flowStateUpdate_valid = flowUpdates_throwWhen_map_toFlow_valid;
  assign flowStateUpdate_payload_inputId = flowUpdates_throwWhen_map_toFlow_payload_inputId;
  assign flowStateUpdate_payload_outputId = flowUpdates_throwWhen_map_toFlow_payload_outputId;
  assign when_Stream_l581_5 = (! brainUpdates_payload_brainUpdate_update);
  always @(*) begin
    brainUpdates_throwWhen_valid = brainUpdates_valid;
    if(when_Stream_l581_5) begin
      brainUpdates_throwWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    brainUpdates_ready = brainUpdates_throwWhen_ready;
    if(when_Stream_l581_5) begin
      brainUpdates_ready = 1'b1;
    end
  end

  assign brainUpdates_throwWhen_payload_entry_priority = brainUpdates_payload_entry_priority;
  assign brainUpdates_throwWhen_payload_entry_data = brainUpdates_payload_entry_data;
  assign brainUpdates_throwWhen_payload_entry_port = brainUpdates_payload_entry_port;
  assign brainUpdates_throwWhen_payload_flowUpdate_flow_inputId = brainUpdates_payload_flowUpdate_flow_inputId;
  assign brainUpdates_throwWhen_payload_flowUpdate_flow_outputId = brainUpdates_payload_flowUpdate_flow_outputId;
  assign brainUpdates_throwWhen_payload_flowUpdate_update = brainUpdates_payload_flowUpdate_update;
  assign brainUpdates_throwWhen_payload_brainUpdate_brain_inputId = brainUpdates_payload_brainUpdate_brain_inputId;
  assign brainUpdates_throwWhen_payload_brainUpdate_brain_outputId = brainUpdates_payload_brainUpdate_brain_outputId;
  assign brainUpdates_throwWhen_payload_brainUpdate_update = brainUpdates_payload_brainUpdate_update;
  assign brainUpdates_throwWhen_map_valid = brainUpdates_throwWhen_valid;
  assign brainUpdates_throwWhen_ready = brainUpdates_throwWhen_map_ready;
  assign brainUpdates_throwWhen_map_payload_inputId = brainUpdates_throwWhen_payload_brainUpdate_brain_inputId;
  assign brainUpdates_throwWhen_map_payload_outputId = brainUpdates_throwWhen_payload_brainUpdate_brain_outputId;
  assign brainUpdates_throwWhen_map_ready = 1'b1;
  assign brainUpdates_throwWhen_map_toFlow_valid = brainUpdates_throwWhen_map_valid;
  assign brainUpdates_throwWhen_map_toFlow_payload_inputId = brainUpdates_throwWhen_map_payload_inputId;
  assign brainUpdates_throwWhen_map_toFlow_payload_outputId = brainUpdates_throwWhen_map_payload_outputId;
  assign brainStateUpdate_valid = brainUpdates_throwWhen_map_toFlow_valid;
  assign brainStateUpdate_payload_inputId = brainUpdates_throwWhen_map_toFlow_payload_inputId;
  assign brainStateUpdate_payload_outputId = brainUpdates_throwWhen_map_toFlow_payload_outputId;
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      outStream_fork3_logic_linkEnable_0 <= 1'b1;
      outStream_fork3_logic_linkEnable_1 <= 1'b1;
      outStream_fork3_logic_linkEnable_2 <= 1'b1;
    end else begin
      if(output_fire) begin
        outStream_fork3_logic_linkEnable_0 <= 1'b0;
      end
      if(flowUpdates_fire) begin
        outStream_fork3_logic_linkEnable_1 <= 1'b0;
      end
      if(brainUpdates_fire) begin
        outStream_fork3_logic_linkEnable_2 <= 1'b0;
      end
      if(outStream_ready) begin
        outStream_fork3_logic_linkEnable_0 <= 1'b1;
        outStream_fork3_logic_linkEnable_1 <= 1'b1;
        outStream_fork3_logic_linkEnable_2 <= 1'b1;
      end
    end
  end


endmodule

//StreamFifoLowLatency_19 replaced by StreamFifoLowLatency_10

module ReplayMapper_2 (
  input  wire          io_readReq_valid,
  input  wire [2:0]    io_readReq_payload,
  output wire          io_readRes_valid,
  output wire [2:0]    io_readRes_payload,
  input  wire          io_writeReq_valid,
  output wire          io_writeReq_ready,
  input  wire [2:0]    io_writeReq_payload_inputId,
  input  wire [2:0]    io_writeReq_payload_outputId,
  input  wire          io_commit,
  output wire          io_commitReady,
  input  wire          clk,
  input  wire          reset
);

  reg        [2:0]    banks_0_spinal_port0;
  reg        [2:0]    banks_1_spinal_port0;
  wire       [2:0]    _zz_banks_0_port;
  wire                _zz_banks_0_port_1;
  wire       [2:0]    _zz_banks_1_port;
  wire                _zz_banks_1_port_1;
  reg                 activeBank;
  reg                 requestedBank;
  wire                _zz_bankRead_0;
  wire       [2:0]    bankRead_0;
  wire                _zz_bankRead_1;
  wire       [2:0]    bankRead_1;
  reg                 io_readReq_valid_regNext;
  wire                io_writeReq_fire;
  reg [2:0] banks_0 [0:7];
  reg [2:0] banks_1 [0:7];

  assign _zz_banks_0_port = io_writeReq_payload_outputId;
  assign _zz_banks_0_port_1 = (io_writeReq_fire && activeBank);
  assign _zz_banks_1_port = io_writeReq_payload_outputId;
  assign _zz_banks_1_port_1 = (io_writeReq_fire && (! activeBank));
  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_1_enque_enqueMapper_banks_0.bin",banks_0);
  end
  always @(posedge clk) begin
    if(_zz_bankRead_0) begin
      banks_0_spinal_port0 <= banks_0[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_banks_0_port_1) begin
      banks_0[io_writeReq_payload_inputId] <= _zz_banks_0_port;
    end
  end

  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_1_enque_enqueMapper_banks_1.bin",banks_1);
  end
  always @(posedge clk) begin
    if(_zz_bankRead_1) begin
      banks_1_spinal_port0 <= banks_1[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_banks_1_port_1) begin
      banks_1[io_writeReq_payload_inputId] <= _zz_banks_1_port;
    end
  end

  assign _zz_bankRead_0 = (io_readReq_valid && (! activeBank));
  assign bankRead_0 = banks_0_spinal_port0;
  assign _zz_bankRead_1 = (io_readReq_valid && activeBank);
  assign bankRead_1 = banks_1_spinal_port0;
  assign io_readRes_valid = io_readReq_valid_regNext;
  assign io_readRes_payload = (requestedBank ? bankRead_1 : bankRead_0);
  assign io_writeReq_ready = 1'b1;
  assign io_commitReady = 1'b1;
  assign io_writeReq_fire = (io_writeReq_valid && io_writeReq_ready);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      activeBank <= 1'b0;
      requestedBank <= 1'b0;
      io_readReq_valid_regNext <= 1'b0;
    end else begin
      if(io_readReq_valid) begin
        requestedBank <= activeBank;
      end
      io_readReq_valid_regNext <= io_readReq_valid;
      if(io_commit) begin
        activeBank <= (! activeBank);
      end
    end
  end


endmodule

//ExternalPifoCore_1 replaced by ExternalPifoCore

//StreamFork_3 replaced by StreamFork_1

module StreamFifoLowLatency_11 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire          io_push_payload_exist,
  input  wire [7:0]    io_push_payload_priority,
  input  wire [4:0]    io_push_payload_data,
  input  wire [2:0]    io_push_payload_port,
  output wire          io_pop_valid,
  input  wire          io_pop_ready,
  output wire          io_pop_payload_exist,
  output wire [7:0]    io_pop_payload_priority,
  output wire [4:0]    io_pop_payload_data,
  output wire [2:0]    io_pop_payload_port,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire                fifo_io_push_ready;
  wire                fifo_io_pop_valid;
  wire                fifo_io_pop_payload_exist;
  wire       [7:0]    fifo_io_pop_payload_priority;
  wire       [4:0]    fifo_io_pop_payload_data;
  wire       [2:0]    fifo_io_pop_payload_port;
  wire       [1:0]    fifo_io_occupancy;
  wire       [1:0]    fifo_io_availability;

  StreamFifo_11 fifo (
    .io_push_valid            (io_push_valid                    ), //i
    .io_push_ready            (fifo_io_push_ready               ), //o
    .io_push_payload_exist    (io_push_payload_exist            ), //i
    .io_push_payload_priority (io_push_payload_priority[7:0]    ), //i
    .io_push_payload_data     (io_push_payload_data[4:0]        ), //i
    .io_push_payload_port     (io_push_payload_port[2:0]        ), //i
    .io_pop_valid             (fifo_io_pop_valid                ), //o
    .io_pop_ready             (io_pop_ready                     ), //i
    .io_pop_payload_exist     (fifo_io_pop_payload_exist        ), //o
    .io_pop_payload_priority  (fifo_io_pop_payload_priority[7:0]), //o
    .io_pop_payload_data      (fifo_io_pop_payload_data[4:0]    ), //o
    .io_pop_payload_port      (fifo_io_pop_payload_port[2:0]    ), //o
    .io_flush                 (io_flush                         ), //i
    .io_occupancy             (fifo_io_occupancy[1:0]           ), //o
    .io_availability          (fifo_io_availability[1:0]        ), //o
    .clk                      (clk                              ), //i
    .reset                    (reset                            )  //i
  );
  assign io_push_ready = fifo_io_push_ready;
  assign io_pop_valid = fifo_io_pop_valid;
  assign io_pop_payload_exist = fifo_io_pop_payload_exist;
  assign io_pop_payload_priority = fifo_io_pop_payload_priority;
  assign io_pop_payload_data = fifo_io_pop_payload_data;
  assign io_pop_payload_port = fifo_io_pop_payload_port;
  assign io_occupancy = fifo_io_occupancy;
  assign io_availability = fifo_io_availability;

endmodule

module StreamFork_2 (
  input  wire          io_input_valid,
  output reg           io_input_ready,
  input  wire          io_input_payload_exist,
  input  wire [7:0]    io_input_payload_priority,
  input  wire [4:0]    io_input_payload_data,
  input  wire [2:0]    io_input_payload_port,
  output wire          io_outputs_0_valid,
  input  wire          io_outputs_0_ready,
  output wire          io_outputs_0_payload_exist,
  output wire [7:0]    io_outputs_0_payload_priority,
  output wire [4:0]    io_outputs_0_payload_data,
  output wire [2:0]    io_outputs_0_payload_port,
  output wire          io_outputs_1_valid,
  input  wire          io_outputs_1_ready,
  output wire          io_outputs_1_payload_exist,
  output wire [7:0]    io_outputs_1_payload_priority,
  output wire [4:0]    io_outputs_1_payload_data,
  output wire [2:0]    io_outputs_1_payload_port,
  output wire          io_outputs_2_valid,
  input  wire          io_outputs_2_ready,
  output wire          io_outputs_2_payload_exist,
  output wire [7:0]    io_outputs_2_payload_priority,
  output wire [4:0]    io_outputs_2_payload_data,
  output wire [2:0]    io_outputs_2_payload_port,
  input  wire          clk,
  input  wire          reset
);

  reg                 logic_linkEnable_0;
  reg                 logic_linkEnable_1;
  reg                 logic_linkEnable_2;
  wire                when_Stream_l1253;
  wire                when_Stream_l1253_1;
  wire                when_Stream_l1253_2;
  wire                io_outputs_0_fire;
  wire                io_outputs_1_fire;
  wire                io_outputs_2_fire;

  always @(*) begin
    io_input_ready = 1'b1;
    if(when_Stream_l1253) begin
      io_input_ready = 1'b0;
    end
    if(when_Stream_l1253_1) begin
      io_input_ready = 1'b0;
    end
    if(when_Stream_l1253_2) begin
      io_input_ready = 1'b0;
    end
  end

  assign when_Stream_l1253 = ((! io_outputs_0_ready) && logic_linkEnable_0);
  assign when_Stream_l1253_1 = ((! io_outputs_1_ready) && logic_linkEnable_1);
  assign when_Stream_l1253_2 = ((! io_outputs_2_ready) && logic_linkEnable_2);
  assign io_outputs_0_valid = (io_input_valid && logic_linkEnable_0);
  assign io_outputs_0_payload_exist = io_input_payload_exist;
  assign io_outputs_0_payload_priority = io_input_payload_priority;
  assign io_outputs_0_payload_data = io_input_payload_data;
  assign io_outputs_0_payload_port = io_input_payload_port;
  assign io_outputs_0_fire = (io_outputs_0_valid && io_outputs_0_ready);
  assign io_outputs_1_valid = (io_input_valid && logic_linkEnable_1);
  assign io_outputs_1_payload_exist = io_input_payload_exist;
  assign io_outputs_1_payload_priority = io_input_payload_priority;
  assign io_outputs_1_payload_data = io_input_payload_data;
  assign io_outputs_1_payload_port = io_input_payload_port;
  assign io_outputs_1_fire = (io_outputs_1_valid && io_outputs_1_ready);
  assign io_outputs_2_valid = (io_input_valid && logic_linkEnable_2);
  assign io_outputs_2_payload_exist = io_input_payload_exist;
  assign io_outputs_2_payload_priority = io_input_payload_priority;
  assign io_outputs_2_payload_data = io_input_payload_data;
  assign io_outputs_2_payload_port = io_input_payload_port;
  assign io_outputs_2_fire = (io_outputs_2_valid && io_outputs_2_ready);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      logic_linkEnable_0 <= 1'b1;
      logic_linkEnable_1 <= 1'b1;
      logic_linkEnable_2 <= 1'b1;
    end else begin
      if(io_outputs_0_fire) begin
        logic_linkEnable_0 <= 1'b0;
      end
      if(io_outputs_1_fire) begin
        logic_linkEnable_1 <= 1'b0;
      end
      if(io_outputs_2_fire) begin
        logic_linkEnable_2 <= 1'b0;
      end
      if(io_input_ready) begin
        logic_linkEnable_0 <= 1'b1;
        logic_linkEnable_1 <= 1'b1;
        logic_linkEnable_2 <= 1'b1;
      end
    end
  end


endmodule

module FrontRewriteTable (
  input  wire [2:0]    io_lookupSource,
  output wire [2:0]    io_lookupTarget,
  output wire          io_lookupEnabled,
  output wire          io_lookupCanEnable,
  input  wire          io_drained_valid,
  input  wire [2:0]    io_drained_payload,
  output wire          io_drainEnablesRewrite,
  input  wire          io_emptySource_valid,
  input  wire [2:0]    io_emptySource_payload,
  output wire          io_emptyEnablesRewrite,
  input  wire          io_writeReq_valid,
  output wire          io_writeReq_ready,
  input  wire [2:0]    io_writeReq_payload_inputId,
  input  wire [2:0]    io_writeReq_payload_outputId,
  input  wire          io_commit,
  input  wire          clk,
  input  wire          reset
);

  reg                 _zz_drainedEntryEligible;
  reg                 _zz_drainedEntryEligible_1;
  reg                 _zz_io_drainEnablesRewrite;
  reg        [2:0]    _zz_io_lookupTarget;
  reg                 _zz__zz_io_lookupEnabled;
  reg                 _zz_io_lookupCanEnable;
  reg                 _zz_io_lookupCanEnable_1;
  reg                 _zz_io_lookupCanEnable_2;
  reg                 _zz_emptyEntryEligible;
  reg                 _zz_emptyEntryEligible_1;
  reg                 _zz_io_emptyEnablesRewrite;
  reg        [2:0]    targets_0;
  reg        [2:0]    targets_1;
  reg        [2:0]    targets_2;
  reg        [2:0]    targets_3;
  reg        [2:0]    targets_4;
  reg        [2:0]    targets_5;
  reg        [2:0]    targets_6;
  reg        [2:0]    targets_7;
  reg                 configured_0;
  reg                 configured_1;
  reg                 configured_2;
  reg                 configured_3;
  reg                 configured_4;
  reg                 configured_5;
  reg                 configured_6;
  reg                 configured_7;
  reg                 pending_0;
  reg                 pending_1;
  reg                 pending_2;
  reg                 pending_3;
  reg                 pending_4;
  reg                 pending_5;
  reg                 pending_6;
  reg                 pending_7;
  reg                 armed_0;
  reg                 armed_1;
  reg                 armed_2;
  reg                 armed_3;
  reg                 armed_4;
  reg                 armed_5;
  reg                 armed_6;
  reg                 armed_7;
  reg                 enabled_0;
  reg                 enabled_1;
  reg                 enabled_2;
  reg                 enabled_3;
  reg                 enabled_4;
  reg                 enabled_5;
  reg                 enabled_6;
  reg                 enabled_7;
  wire                drainedEntryEligible;
  wire                _zz_io_lookupEnabled;
  wire                emptyEntryEligible;
  wire       [7:0]    _zz_1;
  wire       [7:0]    _zz_2;
  wire                io_writeReq_fire;
  wire       [7:0]    _zz_3;
  wire       [7:0]    _zz_4;
  wire       [7:0]    _zz_5;
  wire       [7:0]    _zz_6;
  wire       [7:0]    _zz_7;

  always @(*) begin
    case(io_drained_payload)
      3'b000 : begin
        _zz_drainedEntryEligible = armed_0;
        _zz_drainedEntryEligible_1 = pending_0;
        _zz_io_drainEnablesRewrite = configured_0;
      end
      3'b001 : begin
        _zz_drainedEntryEligible = armed_1;
        _zz_drainedEntryEligible_1 = pending_1;
        _zz_io_drainEnablesRewrite = configured_1;
      end
      3'b010 : begin
        _zz_drainedEntryEligible = armed_2;
        _zz_drainedEntryEligible_1 = pending_2;
        _zz_io_drainEnablesRewrite = configured_2;
      end
      3'b011 : begin
        _zz_drainedEntryEligible = armed_3;
        _zz_drainedEntryEligible_1 = pending_3;
        _zz_io_drainEnablesRewrite = configured_3;
      end
      3'b100 : begin
        _zz_drainedEntryEligible = armed_4;
        _zz_drainedEntryEligible_1 = pending_4;
        _zz_io_drainEnablesRewrite = configured_4;
      end
      3'b101 : begin
        _zz_drainedEntryEligible = armed_5;
        _zz_drainedEntryEligible_1 = pending_5;
        _zz_io_drainEnablesRewrite = configured_5;
      end
      3'b110 : begin
        _zz_drainedEntryEligible = armed_6;
        _zz_drainedEntryEligible_1 = pending_6;
        _zz_io_drainEnablesRewrite = configured_6;
      end
      default : begin
        _zz_drainedEntryEligible = armed_7;
        _zz_drainedEntryEligible_1 = pending_7;
        _zz_io_drainEnablesRewrite = configured_7;
      end
    endcase
  end

  always @(*) begin
    case(io_lookupSource)
      3'b000 : begin
        _zz_io_lookupTarget = targets_0;
        _zz__zz_io_lookupEnabled = enabled_0;
        _zz_io_lookupCanEnable = configured_0;
        _zz_io_lookupCanEnable_1 = armed_0;
        _zz_io_lookupCanEnable_2 = pending_0;
      end
      3'b001 : begin
        _zz_io_lookupTarget = targets_1;
        _zz__zz_io_lookupEnabled = enabled_1;
        _zz_io_lookupCanEnable = configured_1;
        _zz_io_lookupCanEnable_1 = armed_1;
        _zz_io_lookupCanEnable_2 = pending_1;
      end
      3'b010 : begin
        _zz_io_lookupTarget = targets_2;
        _zz__zz_io_lookupEnabled = enabled_2;
        _zz_io_lookupCanEnable = configured_2;
        _zz_io_lookupCanEnable_1 = armed_2;
        _zz_io_lookupCanEnable_2 = pending_2;
      end
      3'b011 : begin
        _zz_io_lookupTarget = targets_3;
        _zz__zz_io_lookupEnabled = enabled_3;
        _zz_io_lookupCanEnable = configured_3;
        _zz_io_lookupCanEnable_1 = armed_3;
        _zz_io_lookupCanEnable_2 = pending_3;
      end
      3'b100 : begin
        _zz_io_lookupTarget = targets_4;
        _zz__zz_io_lookupEnabled = enabled_4;
        _zz_io_lookupCanEnable = configured_4;
        _zz_io_lookupCanEnable_1 = armed_4;
        _zz_io_lookupCanEnable_2 = pending_4;
      end
      3'b101 : begin
        _zz_io_lookupTarget = targets_5;
        _zz__zz_io_lookupEnabled = enabled_5;
        _zz_io_lookupCanEnable = configured_5;
        _zz_io_lookupCanEnable_1 = armed_5;
        _zz_io_lookupCanEnable_2 = pending_5;
      end
      3'b110 : begin
        _zz_io_lookupTarget = targets_6;
        _zz__zz_io_lookupEnabled = enabled_6;
        _zz_io_lookupCanEnable = configured_6;
        _zz_io_lookupCanEnable_1 = armed_6;
        _zz_io_lookupCanEnable_2 = pending_6;
      end
      default : begin
        _zz_io_lookupTarget = targets_7;
        _zz__zz_io_lookupEnabled = enabled_7;
        _zz_io_lookupCanEnable = configured_7;
        _zz_io_lookupCanEnable_1 = armed_7;
        _zz_io_lookupCanEnable_2 = pending_7;
      end
    endcase
  end

  always @(*) begin
    case(io_emptySource_payload)
      3'b000 : begin
        _zz_emptyEntryEligible = armed_0;
        _zz_emptyEntryEligible_1 = pending_0;
        _zz_io_emptyEnablesRewrite = configured_0;
      end
      3'b001 : begin
        _zz_emptyEntryEligible = armed_1;
        _zz_emptyEntryEligible_1 = pending_1;
        _zz_io_emptyEnablesRewrite = configured_1;
      end
      3'b010 : begin
        _zz_emptyEntryEligible = armed_2;
        _zz_emptyEntryEligible_1 = pending_2;
        _zz_io_emptyEnablesRewrite = configured_2;
      end
      3'b011 : begin
        _zz_emptyEntryEligible = armed_3;
        _zz_emptyEntryEligible_1 = pending_3;
        _zz_io_emptyEnablesRewrite = configured_3;
      end
      3'b100 : begin
        _zz_emptyEntryEligible = armed_4;
        _zz_emptyEntryEligible_1 = pending_4;
        _zz_io_emptyEnablesRewrite = configured_4;
      end
      3'b101 : begin
        _zz_emptyEntryEligible = armed_5;
        _zz_emptyEntryEligible_1 = pending_5;
        _zz_io_emptyEnablesRewrite = configured_5;
      end
      3'b110 : begin
        _zz_emptyEntryEligible = armed_6;
        _zz_emptyEntryEligible_1 = pending_6;
        _zz_io_emptyEnablesRewrite = configured_6;
      end
      default : begin
        _zz_emptyEntryEligible = armed_7;
        _zz_emptyEntryEligible_1 = pending_7;
        _zz_io_emptyEnablesRewrite = configured_7;
      end
    endcase
  end

  assign drainedEntryEligible = (_zz_drainedEntryEligible || (io_commit && _zz_drainedEntryEligible_1));
  assign io_drainEnablesRewrite = ((io_drained_valid && _zz_io_drainEnablesRewrite) && drainedEntryEligible);
  assign io_lookupTarget = _zz_io_lookupTarget;
  assign _zz_io_lookupEnabled = _zz__zz_io_lookupEnabled;
  assign io_lookupEnabled = _zz_io_lookupEnabled;
  assign io_lookupCanEnable = ((_zz_io_lookupCanEnable && (! _zz_io_lookupEnabled)) && (_zz_io_lookupCanEnable_1 || (io_commit && _zz_io_lookupCanEnable_2)));
  assign emptyEntryEligible = (_zz_emptyEntryEligible || (io_commit && _zz_emptyEntryEligible_1));
  assign io_emptyEnablesRewrite = ((io_emptySource_valid && _zz_io_emptyEnablesRewrite) && emptyEntryEligible);
  assign io_writeReq_ready = 1'b1;
  assign _zz_1 = ({7'd0,1'b1} <<< io_drained_payload);
  assign _zz_2 = ({7'd0,1'b1} <<< io_emptySource_payload);
  assign io_writeReq_fire = (io_writeReq_valid && io_writeReq_ready);
  assign _zz_3 = ({7'd0,1'b1} <<< io_writeReq_payload_inputId);
  assign _zz_4 = ({7'd0,1'b1} <<< io_writeReq_payload_inputId);
  assign _zz_5 = ({7'd0,1'b1} <<< io_writeReq_payload_inputId);
  assign _zz_6 = ({7'd0,1'b1} <<< io_writeReq_payload_inputId);
  assign _zz_7 = ({7'd0,1'b1} <<< io_writeReq_payload_inputId);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      targets_0 <= 3'b000;
      targets_1 <= 3'b000;
      targets_2 <= 3'b000;
      targets_3 <= 3'b000;
      targets_4 <= 3'b000;
      targets_5 <= 3'b000;
      targets_6 <= 3'b000;
      targets_7 <= 3'b000;
      configured_0 <= 1'b0;
      configured_1 <= 1'b0;
      configured_2 <= 1'b0;
      configured_3 <= 1'b0;
      configured_4 <= 1'b0;
      configured_5 <= 1'b0;
      configured_6 <= 1'b0;
      configured_7 <= 1'b0;
      pending_0 <= 1'b0;
      pending_1 <= 1'b0;
      pending_2 <= 1'b0;
      pending_3 <= 1'b0;
      pending_4 <= 1'b0;
      pending_5 <= 1'b0;
      pending_6 <= 1'b0;
      pending_7 <= 1'b0;
      armed_0 <= 1'b0;
      armed_1 <= 1'b0;
      armed_2 <= 1'b0;
      armed_3 <= 1'b0;
      armed_4 <= 1'b0;
      armed_5 <= 1'b0;
      armed_6 <= 1'b0;
      armed_7 <= 1'b0;
      enabled_0 <= 1'b0;
      enabled_1 <= 1'b0;
      enabled_2 <= 1'b0;
      enabled_3 <= 1'b0;
      enabled_4 <= 1'b0;
      enabled_5 <= 1'b0;
      enabled_6 <= 1'b0;
      enabled_7 <= 1'b0;
    end else begin
      if(io_drainEnablesRewrite) begin
        if(_zz_1[0]) begin
          enabled_0 <= 1'b1;
        end
        if(_zz_1[1]) begin
          enabled_1 <= 1'b1;
        end
        if(_zz_1[2]) begin
          enabled_2 <= 1'b1;
        end
        if(_zz_1[3]) begin
          enabled_3 <= 1'b1;
        end
        if(_zz_1[4]) begin
          enabled_4 <= 1'b1;
        end
        if(_zz_1[5]) begin
          enabled_5 <= 1'b1;
        end
        if(_zz_1[6]) begin
          enabled_6 <= 1'b1;
        end
        if(_zz_1[7]) begin
          enabled_7 <= 1'b1;
        end
      end
      if(io_emptyEnablesRewrite) begin
        if(_zz_2[0]) begin
          enabled_0 <= 1'b1;
        end
        if(_zz_2[1]) begin
          enabled_1 <= 1'b1;
        end
        if(_zz_2[2]) begin
          enabled_2 <= 1'b1;
        end
        if(_zz_2[3]) begin
          enabled_3 <= 1'b1;
        end
        if(_zz_2[4]) begin
          enabled_4 <= 1'b1;
        end
        if(_zz_2[5]) begin
          enabled_5 <= 1'b1;
        end
        if(_zz_2[6]) begin
          enabled_6 <= 1'b1;
        end
        if(_zz_2[7]) begin
          enabled_7 <= 1'b1;
        end
      end
      if(io_commit) begin
        if(pending_0) begin
          pending_0 <= 1'b0;
          armed_0 <= 1'b1;
        end
        if(pending_1) begin
          pending_1 <= 1'b0;
          armed_1 <= 1'b1;
        end
        if(pending_2) begin
          pending_2 <= 1'b0;
          armed_2 <= 1'b1;
        end
        if(pending_3) begin
          pending_3 <= 1'b0;
          armed_3 <= 1'b1;
        end
        if(pending_4) begin
          pending_4 <= 1'b0;
          armed_4 <= 1'b1;
        end
        if(pending_5) begin
          pending_5 <= 1'b0;
          armed_5 <= 1'b1;
        end
        if(pending_6) begin
          pending_6 <= 1'b0;
          armed_6 <= 1'b1;
        end
        if(pending_7) begin
          pending_7 <= 1'b0;
          armed_7 <= 1'b1;
        end
      end
      if(io_writeReq_fire) begin
        if(_zz_3[0]) begin
          targets_0 <= io_writeReq_payload_outputId;
        end
        if(_zz_3[1]) begin
          targets_1 <= io_writeReq_payload_outputId;
        end
        if(_zz_3[2]) begin
          targets_2 <= io_writeReq_payload_outputId;
        end
        if(_zz_3[3]) begin
          targets_3 <= io_writeReq_payload_outputId;
        end
        if(_zz_3[4]) begin
          targets_4 <= io_writeReq_payload_outputId;
        end
        if(_zz_3[5]) begin
          targets_5 <= io_writeReq_payload_outputId;
        end
        if(_zz_3[6]) begin
          targets_6 <= io_writeReq_payload_outputId;
        end
        if(_zz_3[7]) begin
          targets_7 <= io_writeReq_payload_outputId;
        end
        if(_zz_4[0]) begin
          configured_0 <= 1'b1;
        end
        if(_zz_4[1]) begin
          configured_1 <= 1'b1;
        end
        if(_zz_4[2]) begin
          configured_2 <= 1'b1;
        end
        if(_zz_4[3]) begin
          configured_3 <= 1'b1;
        end
        if(_zz_4[4]) begin
          configured_4 <= 1'b1;
        end
        if(_zz_4[5]) begin
          configured_5 <= 1'b1;
        end
        if(_zz_4[6]) begin
          configured_6 <= 1'b1;
        end
        if(_zz_4[7]) begin
          configured_7 <= 1'b1;
        end
        if(_zz_5[0]) begin
          pending_0 <= 1'b1;
        end
        if(_zz_5[1]) begin
          pending_1 <= 1'b1;
        end
        if(_zz_5[2]) begin
          pending_2 <= 1'b1;
        end
        if(_zz_5[3]) begin
          pending_3 <= 1'b1;
        end
        if(_zz_5[4]) begin
          pending_4 <= 1'b1;
        end
        if(_zz_5[5]) begin
          pending_5 <= 1'b1;
        end
        if(_zz_5[6]) begin
          pending_6 <= 1'b1;
        end
        if(_zz_5[7]) begin
          pending_7 <= 1'b1;
        end
        if(_zz_6[0]) begin
          armed_0 <= 1'b0;
        end
        if(_zz_6[1]) begin
          armed_1 <= 1'b0;
        end
        if(_zz_6[2]) begin
          armed_2 <= 1'b0;
        end
        if(_zz_6[3]) begin
          armed_3 <= 1'b0;
        end
        if(_zz_6[4]) begin
          armed_4 <= 1'b0;
        end
        if(_zz_6[5]) begin
          armed_5 <= 1'b0;
        end
        if(_zz_6[6]) begin
          armed_6 <= 1'b0;
        end
        if(_zz_6[7]) begin
          armed_7 <= 1'b0;
        end
        if(_zz_7[0]) begin
          enabled_0 <= 1'b0;
        end
        if(_zz_7[1]) begin
          enabled_1 <= 1'b0;
        end
        if(_zz_7[2]) begin
          enabled_2 <= 1'b0;
        end
        if(_zz_7[3]) begin
          enabled_3 <= 1'b0;
        end
        if(_zz_7[4]) begin
          enabled_4 <= 1'b0;
        end
        if(_zz_7[5]) begin
          enabled_5 <= 1'b0;
        end
        if(_zz_7[6]) begin
          enabled_6 <= 1'b0;
        end
        if(_zz_7[7]) begin
          enabled_7 <= 1'b0;
        end
      end
    end
  end


endmodule

module ReplayMapper_1 (
  input  wire          io_readReq_valid,
  input  wire [7:0]    io_readReq_payload,
  output wire          io_readRes_valid,
  output wire [4:0]    io_readRes_payload,
  input  wire          io_writeReq_valid,
  output wire          io_writeReq_ready,
  input  wire [7:0]    io_writeReq_payload_inputId,
  input  wire [4:0]    io_writeReq_payload_outputId,
  input  wire          io_commit,
  output wire          io_commitReady,
  input  wire          clk,
  input  wire          reset
);

  reg        [4:0]    banks_0_spinal_port0;
  reg        [4:0]    banks_1_spinal_port0;
  wire       [4:0]    _zz_banks_0_port;
  wire                _zz_banks_0_port_1;
  wire       [4:0]    _zz_banks_1_port;
  wire                _zz_banks_1_port_1;
  reg                 activeBank;
  reg                 requestedBank;
  wire                _zz_bankRead_0;
  wire       [4:0]    bankRead_0;
  wire                _zz_bankRead_1;
  wire       [4:0]    bankRead_1;
  reg                 io_readReq_valid_regNext;
  wire                io_writeReq_fire;
  reg [4:0] banks_0 [0:255];
  reg [4:0] banks_1 [0:255];

  assign _zz_banks_0_port = io_writeReq_payload_outputId;
  assign _zz_banks_0_port_1 = (io_writeReq_fire && activeBank);
  assign _zz_banks_1_port = io_writeReq_payload_outputId;
  assign _zz_banks_1_port_1 = (io_writeReq_fire && (! activeBank));
  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_0_deque_dequeMapper_banks_0.bin",banks_0);
  end
  always @(posedge clk) begin
    if(_zz_bankRead_0) begin
      banks_0_spinal_port0 <= banks_0[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_banks_0_port_1) begin
      banks_0[io_writeReq_payload_inputId] <= _zz_banks_0_port;
    end
  end

  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_0_deque_dequeMapper_banks_1.bin",banks_1);
  end
  always @(posedge clk) begin
    if(_zz_bankRead_1) begin
      banks_1_spinal_port0 <= banks_1[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_banks_1_port_1) begin
      banks_1[io_writeReq_payload_inputId] <= _zz_banks_1_port;
    end
  end

  assign _zz_bankRead_0 = (io_readReq_valid && (! activeBank));
  assign bankRead_0 = banks_0_spinal_port0;
  assign _zz_bankRead_1 = (io_readReq_valid && activeBank);
  assign bankRead_1 = banks_1_spinal_port0;
  assign io_readRes_valid = io_readReq_valid_regNext;
  assign io_readRes_payload = (requestedBank ? bankRead_1 : bankRead_0);
  assign io_writeReq_ready = 1'b1;
  assign io_commitReady = 1'b1;
  assign io_writeReq_fire = (io_writeReq_valid && io_writeReq_ready);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      activeBank <= 1'b0;
      requestedBank <= 1'b0;
      io_readReq_valid_regNext <= 1'b0;
    end else begin
      if(io_readReq_valid) begin
        requestedBank <= activeBank;
      end
      io_readReq_valid_regNext <= io_readReq_valid;
      if(io_commit) begin
        activeBank <= (! activeBank);
      end
    end
  end


endmodule

module PIFOBrain (
  input  wire          io_request_valid,
  output wire          io_request_ready,
  input  wire [2:0]    io_request_payload_vpifoId,
  input  wire [4:0]    io_request_payload_flowId,
  output wire          io_response_valid,
  input  wire          io_response_ready,
  output wire [7:0]    io_response_payload_priority,
  output wire [4:0]    io_response_payload_data,
  output wire [2:0]    io_response_payload_port,
  input  wire          io_control_valid,
  output wire          io_control_ready,
  input  wire [2:0]    io_control_payload_command,
  input  wire [1:0]    io_control_payload_engineId,
  input  wire [2:0]    io_control_payload_vPifoId,
  input  wire [4:0]    io_control_payload_flowId,
  input  wire [31:0]   io_control_payload_data,
  input  wire          io_poped_valid,
  input  wire          io_poped_payload_exist,
  input  wire [7:0]    io_poped_payload_priority,
  input  wire [4:0]    io_poped_payload_data,
  input  wire [2:0]    io_poped_payload_port,
  input  wire          clk,
  input  wire          reset
);
  localparam ControlCommand_UpdateMapperPre = 3'd0;
  localparam ControlCommand_UpdateMapperPost = 3'd1;
  localparam ControlCommand_UpdateMapperNonExist = 3'd2;
  localparam ControlCommand_CommitMapper = 3'd3;
  localparam ControlCommand_UpdateBrainEngine = 3'd4;
  localparam ControlCommand_UpdateBrainState = 3'd5;
  localparam ControlCommand_UpdateBrainFlowState = 3'd6;
  localparam BrainType_NOP = 2'd0;
  localparam BrainType_WFQ = 2'd1;
  localparam BrainType_SP = 2'd2;
  localparam BrainType_FIFO = 2'd3;

  wire       [1:0]    engineMapper_io_writeReq_payload_outputId;
  reg                 io_control_fork_io_outputs_0_ready;
  reg                 io_control_fork_io_outputs_1_ready;
  reg                 io_control_fork_io_outputs_2_ready;
  wire                io_request_fork_io_input_ready;
  wire                io_request_fork_io_outputs_0_valid;
  wire       [2:0]    io_request_fork_io_outputs_0_payload_vpifoId;
  wire       [4:0]    io_request_fork_io_outputs_0_payload_flowId;
  wire                io_request_fork_io_outputs_1_valid;
  wire       [2:0]    io_request_fork_io_outputs_1_payload_vpifoId;
  wire       [4:0]    io_request_fork_io_outputs_1_payload_flowId;
  wire                io_request_fork_io_outputs_2_valid;
  wire       [2:0]    io_request_fork_io_outputs_2_payload_vpifoId;
  wire       [4:0]    io_request_fork_io_outputs_2_payload_flowId;
  wire                io_request_fork_io_outputs_3_valid;
  wire       [2:0]    io_request_fork_io_outputs_3_payload_vpifoId;
  wire       [4:0]    io_request_fork_io_outputs_3_payload_flowId;
  wire                io_request_fork_io_outputs_4_valid;
  wire       [2:0]    io_request_fork_io_outputs_4_payload_vpifoId;
  wire       [4:0]    io_request_fork_io_outputs_4_payload_flowId;
  wire                engineMapper_io_readRes_valid;
  wire       [1:0]    engineMapper_io_readRes_payload;
  wire                lastVirtualMapper_io_readRes_valid;
  wire       [7:0]    lastVirtualMapper_io_readRes_payload;
  wire                engineCAM_io_readRes_valid;
  wire       [31:0]   engineCAM_io_readRes_payload;
  wire                flowStateUpdate_toStream_fifo_io_push_ready;
  wire                flowStateUpdate_toStream_fifo_io_pop_valid;
  wire       [7:0]    flowStateUpdate_toStream_fifo_io_pop_payload_inputId;
  wire       [31:0]   flowStateUpdate_toStream_fifo_io_pop_payload_outputId;
  wire       [1:0]    flowStateUpdate_toStream_fifo_io_occupancy;
  wire       [1:0]    flowStateUpdate_toStream_fifo_io_availability;
  wire                streamArbiter_9_io_inputs_0_ready;
  wire                streamArbiter_9_io_inputs_1_ready;
  wire                streamArbiter_9_io_output_valid;
  wire       [7:0]    streamArbiter_9_io_output_payload_inputId;
  wire       [31:0]   streamArbiter_9_io_output_payload_outputId;
  wire       [0:0]    streamArbiter_9_io_chosen;
  wire       [1:0]    streamArbiter_9_io_chosenOH;
  wire                brainStateMem_io_readRes_valid;
  wire       [31:0]   brainStateMem_io_readRes_payload;
  wire                brainStateUpdate_toStream_fifo_io_push_ready;
  wire                brainStateUpdate_toStream_fifo_io_pop_valid;
  wire       [2:0]    brainStateUpdate_toStream_fifo_io_pop_payload_inputId;
  wire       [31:0]   brainStateUpdate_toStream_fifo_io_pop_payload_outputId;
  wire       [1:0]    brainStateUpdate_toStream_fifo_io_occupancy;
  wire       [1:0]    brainStateUpdate_toStream_fifo_io_availability;
  wire                streamArbiter_10_io_inputs_0_ready;
  wire                streamArbiter_10_io_inputs_1_ready;
  wire                streamArbiter_10_io_output_valid;
  wire       [2:0]    streamArbiter_10_io_output_payload_inputId;
  wire       [31:0]   streamArbiter_10_io_output_payload_outputId;
  wire       [0:0]    streamArbiter_10_io_chosen;
  wire       [1:0]    streamArbiter_10_io_chosenOH;
  wire                io_control_fork_io_input_ready;
  wire                io_control_fork_io_outputs_0_valid;
  wire       [2:0]    io_control_fork_io_outputs_0_payload_command;
  wire       [1:0]    io_control_fork_io_outputs_0_payload_engineId;
  wire       [2:0]    io_control_fork_io_outputs_0_payload_vPifoId;
  wire       [4:0]    io_control_fork_io_outputs_0_payload_flowId;
  wire       [31:0]   io_control_fork_io_outputs_0_payload_data;
  wire                io_control_fork_io_outputs_1_valid;
  wire       [2:0]    io_control_fork_io_outputs_1_payload_command;
  wire       [1:0]    io_control_fork_io_outputs_1_payload_engineId;
  wire       [2:0]    io_control_fork_io_outputs_1_payload_vPifoId;
  wire       [4:0]    io_control_fork_io_outputs_1_payload_flowId;
  wire       [31:0]   io_control_fork_io_outputs_1_payload_data;
  wire                io_control_fork_io_outputs_2_valid;
  wire       [2:0]    io_control_fork_io_outputs_2_payload_command;
  wire       [1:0]    io_control_fork_io_outputs_2_payload_engineId;
  wire       [2:0]    io_control_fork_io_outputs_2_payload_vPifoId;
  wire       [4:0]    io_control_fork_io_outputs_2_payload_flowId;
  wire       [31:0]   io_control_fork_io_outputs_2_payload_data;
  wire                engineMapper_io_readRes_toStream_fifo_io_push_ready;
  wire                engineMapper_io_readRes_toStream_fifo_io_pop_valid;
  wire       [1:0]    engineMapper_io_readRes_toStream_fifo_io_pop_payload;
  wire       [1:0]    engineMapper_io_readRes_toStream_fifo_io_occupancy;
  wire       [1:0]    engineMapper_io_readRes_toStream_fifo_io_availability;
  wire                brainStateMem_io_readRes_toStream_fifo_io_push_ready;
  wire                brainStateMem_io_readRes_toStream_fifo_io_pop_valid;
  wire       [31:0]   brainStateMem_io_readRes_toStream_fifo_io_pop_payload;
  wire       [1:0]    brainStateMem_io_readRes_toStream_fifo_io_occupancy;
  wire       [1:0]    brainStateMem_io_readRes_toStream_fifo_io_availability;
  wire                engineCAM_io_readRes_toStream_fifo_io_push_ready;
  wire                engineCAM_io_readRes_toStream_fifo_io_pop_valid;
  wire       [31:0]   engineCAM_io_readRes_toStream_fifo_io_pop_payload;
  wire       [1:0]    engineCAM_io_readRes_toStream_fifo_io_occupancy;
  wire       [1:0]    engineCAM_io_readRes_toStream_fifo_io_availability;
  wire                lastVirtualMapper_io_readRes_toStream_fifo_io_push_ready;
  wire                lastVirtualMapper_io_readRes_toStream_fifo_io_pop_valid;
  wire       [7:0]    lastVirtualMapper_io_readRes_toStream_fifo_io_pop_payload;
  wire       [1:0]    lastVirtualMapper_io_readRes_toStream_fifo_io_occupancy;
  wire       [1:0]    lastVirtualMapper_io_readRes_toStream_fifo_io_availability;
  wire                io_outputs_4_fifo_io_push_ready;
  wire                io_outputs_4_fifo_io_pop_valid;
  wire       [2:0]    io_outputs_4_fifo_io_pop_payload_vpifoId;
  wire       [4:0]    io_outputs_4_fifo_io_pop_payload_flowId;
  wire       [1:0]    io_outputs_4_fifo_io_occupancy;
  wire       [1:0]    io_outputs_4_fifo_io_availability;
  wire       [7:0]    _zz__zz_outStream_payload_entry_priority_4;
  wire                io_request_fork_io_outputs_0_map_valid;
  wire                io_request_fork_io_outputs_0_map_ready;
  wire       [2:0]    io_request_fork_io_outputs_0_map_payload;
  wire                io_request_fork_io_outputs_0_map_toFlow_valid;
  wire       [2:0]    io_request_fork_io_outputs_0_map_toFlow_payload;
  wire                io_poped_takeWhen_valid;
  wire                io_poped_takeWhen_payload_exist;
  wire       [7:0]    io_poped_takeWhen_payload_priority;
  wire       [4:0]    io_poped_takeWhen_payload_data;
  wire       [2:0]    io_poped_takeWhen_payload_port;
  wire                io_request_fork_io_outputs_1_map_valid;
  wire                io_request_fork_io_outputs_1_map_ready;
  wire       [2:0]    io_request_fork_io_outputs_1_map_payload;
  wire                io_request_fork_io_outputs_1_map_toFlow_valid;
  wire       [2:0]    io_request_fork_io_outputs_1_map_toFlow_payload;
  wire                io_request_fork_io_outputs_2_map_valid;
  wire                io_request_fork_io_outputs_2_map_ready;
  wire       [7:0]    io_request_fork_io_outputs_2_map_payload;
  wire                io_request_fork_io_outputs_2_map_toFlow_valid;
  wire       [7:0]    io_request_fork_io_outputs_2_map_toFlow_payload;
  wire                flowStateControl_valid;
  wire       [7:0]    flowStateControl_payload_inputId;
  wire       [31:0]   flowStateControl_payload_outputId;
  wire                flowStateUpdate_valid;
  wire       [7:0]    flowStateUpdate_payload_inputId;
  wire       [31:0]   flowStateUpdate_payload_outputId;
  wire                flowStateControl_toStream_valid;
  wire                flowStateControl_toStream_ready;
  wire       [7:0]    flowStateControl_toStream_payload_inputId;
  wire       [31:0]   flowStateControl_toStream_payload_outputId;
  wire                flowStateUpdate_toStream_valid;
  wire                flowStateUpdate_toStream_ready;
  wire       [7:0]    flowStateUpdate_toStream_payload_inputId;
  wire       [31:0]   flowStateUpdate_toStream_payload_outputId;
  wire                io_request_fork_io_outputs_3_map_valid;
  wire                io_request_fork_io_outputs_3_map_ready;
  wire       [2:0]    io_request_fork_io_outputs_3_map_payload;
  wire                io_request_fork_io_outputs_3_map_toFlow_valid;
  wire       [2:0]    io_request_fork_io_outputs_3_map_toFlow_payload;
  wire                brainStateControl_valid;
  wire       [2:0]    brainStateControl_payload_inputId;
  wire       [31:0]   brainStateControl_payload_outputId;
  wire                brainStateUpdate_valid;
  wire       [2:0]    brainStateUpdate_payload_inputId;
  wire       [31:0]   brainStateUpdate_payload_outputId;
  wire                brainStateControl_toStream_valid;
  wire                brainStateControl_toStream_ready;
  wire       [2:0]    brainStateControl_toStream_payload_inputId;
  wire       [31:0]   brainStateControl_toStream_payload_outputId;
  wire                brainStateUpdate_toStream_valid;
  wire                brainStateUpdate_toStream_ready;
  wire       [2:0]    brainStateUpdate_toStream_payload_inputId;
  wire       [31:0]   brainStateUpdate_toStream_payload_outputId;
  wire                when_Stream_l581;
  reg                 io_control_fork_io_outputs_0_takeWhen_valid;
  wire                io_control_fork_io_outputs_0_takeWhen_ready;
  wire       [2:0]    io_control_fork_io_outputs_0_takeWhen_payload_command;
  wire       [1:0]    io_control_fork_io_outputs_0_takeWhen_payload_engineId;
  wire       [2:0]    io_control_fork_io_outputs_0_takeWhen_payload_vPifoId;
  wire       [4:0]    io_control_fork_io_outputs_0_takeWhen_payload_flowId;
  wire       [31:0]   io_control_fork_io_outputs_0_takeWhen_payload_data;
  wire                when_Stream_l581_1;
  reg                 io_control_fork_io_outputs_1_takeWhen_valid;
  wire                io_control_fork_io_outputs_1_takeWhen_ready;
  wire       [2:0]    io_control_fork_io_outputs_1_takeWhen_payload_command;
  wire       [1:0]    io_control_fork_io_outputs_1_takeWhen_payload_engineId;
  wire       [2:0]    io_control_fork_io_outputs_1_takeWhen_payload_vPifoId;
  wire       [4:0]    io_control_fork_io_outputs_1_takeWhen_payload_flowId;
  wire       [31:0]   io_control_fork_io_outputs_1_takeWhen_payload_data;
  wire                when_Stream_l581_2;
  reg                 io_control_fork_io_outputs_2_takeWhen_valid;
  wire                io_control_fork_io_outputs_2_takeWhen_ready;
  wire       [2:0]    io_control_fork_io_outputs_2_takeWhen_payload_command;
  wire       [1:0]    io_control_fork_io_outputs_2_takeWhen_payload_engineId;
  wire       [2:0]    io_control_fork_io_outputs_2_takeWhen_payload_vPifoId;
  wire       [4:0]    io_control_fork_io_outputs_2_takeWhen_payload_flowId;
  wire       [31:0]   io_control_fork_io_outputs_2_takeWhen_payload_data;
  wire                engineMapper_io_readRes_toStream_valid;
  wire                engineMapper_io_readRes_toStream_ready;
  wire       [1:0]    engineMapper_io_readRes_toStream_payload;
  wire                brainStateMem_io_readRes_toStream_valid;
  wire                brainStateMem_io_readRes_toStream_ready;
  wire       [31:0]   brainStateMem_io_readRes_toStream_payload;
  wire                engineCAM_io_readRes_toStream_valid;
  wire                engineCAM_io_readRes_toStream_ready;
  wire       [31:0]   engineCAM_io_readRes_toStream_payload;
  wire                lastVirtualMapper_io_readRes_toStream_valid;
  wire                lastVirtualMapper_io_readRes_toStream_ready;
  wire       [7:0]    lastVirtualMapper_io_readRes_toStream_payload;
  wire                _zz_engineStream_valid;
  wire                _zz_io_pop_ready;
  wire                engineStream_valid;
  wire                engineStream_ready;
  wire       [2:0]    engineStream_payload_pifoId;
  wire       [4:0]    engineStream_payload_flowId;
  wire       [1:0]    engineStream_payload_engineId;
  wire       [31:0]   engineStream_payload_flowState;
  wire       [31:0]   engineStream_payload_brainState;
  wire       [7:0]    engineStream_payload_virutalTime;
  reg        [7:0]    _zz_outStream_payload_entry_priority;
  reg        [31:0]   _zz_outStream_payload_flowUpdate_flow_outputId;
  reg                 _zz_outStream_payload_flowUpdate_update;
  reg        [31:0]   _zz_outStream_payload_brainUpdate_brain_outputId;
  reg                 _zz_outStream_payload_brainUpdate_update;
  wire       [1:0]    switch_PifoEngine_l367;
  wire       [1:0]    _zz_switch_PifoEngine_l367;
  wire       [7:0]    _zz_outStream_payload_entry_priority_1;
  wire       [7:0]    _zz_outStream_payload_entry_priority_2;
  wire       [7:0]    _zz_outStream_payload_entry_priority_3;
  wire       [7:0]    _zz_outStream_payload_entry_priority_4;
  wire                outStream_valid;
  reg                 outStream_ready;
  wire       [7:0]    outStream_payload_entry_priority;
  wire       [4:0]    outStream_payload_entry_data;
  wire       [2:0]    outStream_payload_entry_port;
  wire       [7:0]    outStream_payload_flowUpdate_flow_inputId;
  wire       [31:0]   outStream_payload_flowUpdate_flow_outputId;
  wire                outStream_payload_flowUpdate_update;
  wire       [2:0]    outStream_payload_brainUpdate_brain_inputId;
  wire       [31:0]   outStream_payload_brainUpdate_brain_outputId;
  wire                outStream_payload_brainUpdate_update;
  wire                output_valid;
  reg                 output_ready;
  wire       [7:0]    output_payload_entry_priority;
  wire       [4:0]    output_payload_entry_data;
  wire       [2:0]    output_payload_entry_port;
  wire       [7:0]    output_payload_flowUpdate_flow_inputId;
  wire       [31:0]   output_payload_flowUpdate_flow_outputId;
  wire                output_payload_flowUpdate_update;
  wire       [2:0]    output_payload_brainUpdate_brain_inputId;
  wire       [31:0]   output_payload_brainUpdate_brain_outputId;
  wire                output_payload_brainUpdate_update;
  wire                flowUpdates_valid;
  reg                 flowUpdates_ready;
  wire       [7:0]    flowUpdates_payload_entry_priority;
  wire       [4:0]    flowUpdates_payload_entry_data;
  wire       [2:0]    flowUpdates_payload_entry_port;
  wire       [7:0]    flowUpdates_payload_flowUpdate_flow_inputId;
  wire       [31:0]   flowUpdates_payload_flowUpdate_flow_outputId;
  wire                flowUpdates_payload_flowUpdate_update;
  wire       [2:0]    flowUpdates_payload_brainUpdate_brain_inputId;
  wire       [31:0]   flowUpdates_payload_brainUpdate_brain_outputId;
  wire                flowUpdates_payload_brainUpdate_update;
  wire                brainUpdates_valid;
  reg                 brainUpdates_ready;
  wire       [7:0]    brainUpdates_payload_entry_priority;
  wire       [4:0]    brainUpdates_payload_entry_data;
  wire       [2:0]    brainUpdates_payload_entry_port;
  wire       [7:0]    brainUpdates_payload_flowUpdate_flow_inputId;
  wire       [31:0]   brainUpdates_payload_flowUpdate_flow_outputId;
  wire                brainUpdates_payload_flowUpdate_update;
  wire       [2:0]    brainUpdates_payload_brainUpdate_brain_inputId;
  wire       [31:0]   brainUpdates_payload_brainUpdate_brain_outputId;
  wire                brainUpdates_payload_brainUpdate_update;
  reg                 outStream_fork3_logic_linkEnable_0;
  reg                 outStream_fork3_logic_linkEnable_1;
  reg                 outStream_fork3_logic_linkEnable_2;
  wire                when_Stream_l1253;
  wire                when_Stream_l1253_1;
  wire                when_Stream_l1253_2;
  wire                output_fire;
  wire                flowUpdates_fire;
  wire                brainUpdates_fire;
  wire                when_Stream_l581_3;
  reg                 output_throwWhen_valid;
  wire                output_throwWhen_ready;
  wire       [7:0]    output_throwWhen_payload_entry_priority;
  wire       [4:0]    output_throwWhen_payload_entry_data;
  wire       [2:0]    output_throwWhen_payload_entry_port;
  wire       [7:0]    output_throwWhen_payload_flowUpdate_flow_inputId;
  wire       [31:0]   output_throwWhen_payload_flowUpdate_flow_outputId;
  wire                output_throwWhen_payload_flowUpdate_update;
  wire       [2:0]    output_throwWhen_payload_brainUpdate_brain_inputId;
  wire       [31:0]   output_throwWhen_payload_brainUpdate_brain_outputId;
  wire                output_throwWhen_payload_brainUpdate_update;
  wire                output_throwWhen_map_valid;
  wire                output_throwWhen_map_ready;
  wire       [7:0]    output_throwWhen_map_payload_priority;
  wire       [4:0]    output_throwWhen_map_payload_data;
  wire       [2:0]    output_throwWhen_map_payload_port;
  wire                when_Stream_l581_4;
  reg                 flowUpdates_throwWhen_valid;
  wire                flowUpdates_throwWhen_ready;
  wire       [7:0]    flowUpdates_throwWhen_payload_entry_priority;
  wire       [4:0]    flowUpdates_throwWhen_payload_entry_data;
  wire       [2:0]    flowUpdates_throwWhen_payload_entry_port;
  wire       [7:0]    flowUpdates_throwWhen_payload_flowUpdate_flow_inputId;
  wire       [31:0]   flowUpdates_throwWhen_payload_flowUpdate_flow_outputId;
  wire                flowUpdates_throwWhen_payload_flowUpdate_update;
  wire       [2:0]    flowUpdates_throwWhen_payload_brainUpdate_brain_inputId;
  wire       [31:0]   flowUpdates_throwWhen_payload_brainUpdate_brain_outputId;
  wire                flowUpdates_throwWhen_payload_brainUpdate_update;
  wire                flowUpdates_throwWhen_map_valid;
  wire                flowUpdates_throwWhen_map_ready;
  wire       [7:0]    flowUpdates_throwWhen_map_payload_inputId;
  wire       [31:0]   flowUpdates_throwWhen_map_payload_outputId;
  wire                flowUpdates_throwWhen_map_toFlow_valid;
  wire       [7:0]    flowUpdates_throwWhen_map_toFlow_payload_inputId;
  wire       [31:0]   flowUpdates_throwWhen_map_toFlow_payload_outputId;
  wire                when_Stream_l581_5;
  reg                 brainUpdates_throwWhen_valid;
  wire                brainUpdates_throwWhen_ready;
  wire       [7:0]    brainUpdates_throwWhen_payload_entry_priority;
  wire       [4:0]    brainUpdates_throwWhen_payload_entry_data;
  wire       [2:0]    brainUpdates_throwWhen_payload_entry_port;
  wire       [7:0]    brainUpdates_throwWhen_payload_flowUpdate_flow_inputId;
  wire       [31:0]   brainUpdates_throwWhen_payload_flowUpdate_flow_outputId;
  wire                brainUpdates_throwWhen_payload_flowUpdate_update;
  wire       [2:0]    brainUpdates_throwWhen_payload_brainUpdate_brain_inputId;
  wire       [31:0]   brainUpdates_throwWhen_payload_brainUpdate_brain_outputId;
  wire                brainUpdates_throwWhen_payload_brainUpdate_update;
  wire                brainUpdates_throwWhen_map_valid;
  wire                brainUpdates_throwWhen_map_ready;
  wire       [2:0]    brainUpdates_throwWhen_map_payload_inputId;
  wire       [31:0]   brainUpdates_throwWhen_map_payload_outputId;
  wire                brainUpdates_throwWhen_map_toFlow_valid;
  wire       [2:0]    brainUpdates_throwWhen_map_toFlow_payload_inputId;
  wire       [31:0]   brainUpdates_throwWhen_map_toFlow_payload_outputId;
  `ifndef SYNTHESIS
  reg [159:0] io_control_payload_command_string;
  reg [159:0] io_control_fork_io_outputs_0_takeWhen_payload_command_string;
  reg [159:0] io_control_fork_io_outputs_1_takeWhen_payload_command_string;
  reg [159:0] io_control_fork_io_outputs_2_takeWhen_payload_command_string;
  reg [31:0] switch_PifoEngine_l367_string;
  reg [31:0] _zz_switch_PifoEngine_l367_string;
  `endif


  assign _zz__zz_outStream_payload_entry_priority_4 = engineStream_payload_brainState[7:0];
  StreamFork io_request_fork (
    .io_input_valid               (io_request_valid                                 ), //i
    .io_input_ready               (io_request_fork_io_input_ready                   ), //o
    .io_input_payload_vpifoId     (io_request_payload_vpifoId[2:0]                  ), //i
    .io_input_payload_flowId      (io_request_payload_flowId[4:0]                   ), //i
    .io_outputs_0_valid           (io_request_fork_io_outputs_0_valid               ), //o
    .io_outputs_0_ready           (io_request_fork_io_outputs_0_map_ready           ), //i
    .io_outputs_0_payload_vpifoId (io_request_fork_io_outputs_0_payload_vpifoId[2:0]), //o
    .io_outputs_0_payload_flowId  (io_request_fork_io_outputs_0_payload_flowId[4:0] ), //o
    .io_outputs_1_valid           (io_request_fork_io_outputs_1_valid               ), //o
    .io_outputs_1_ready           (io_request_fork_io_outputs_1_map_ready           ), //i
    .io_outputs_1_payload_vpifoId (io_request_fork_io_outputs_1_payload_vpifoId[2:0]), //o
    .io_outputs_1_payload_flowId  (io_request_fork_io_outputs_1_payload_flowId[4:0] ), //o
    .io_outputs_2_valid           (io_request_fork_io_outputs_2_valid               ), //o
    .io_outputs_2_ready           (io_request_fork_io_outputs_2_map_ready           ), //i
    .io_outputs_2_payload_vpifoId (io_request_fork_io_outputs_2_payload_vpifoId[2:0]), //o
    .io_outputs_2_payload_flowId  (io_request_fork_io_outputs_2_payload_flowId[4:0] ), //o
    .io_outputs_3_valid           (io_request_fork_io_outputs_3_valid               ), //o
    .io_outputs_3_ready           (io_request_fork_io_outputs_3_map_ready           ), //i
    .io_outputs_3_payload_vpifoId (io_request_fork_io_outputs_3_payload_vpifoId[2:0]), //o
    .io_outputs_3_payload_flowId  (io_request_fork_io_outputs_3_payload_flowId[4:0] ), //o
    .io_outputs_4_valid           (io_request_fork_io_outputs_4_valid               ), //o
    .io_outputs_4_ready           (io_outputs_4_fifo_io_push_ready                  ), //i
    .io_outputs_4_payload_vpifoId (io_request_fork_io_outputs_4_payload_vpifoId[2:0]), //o
    .io_outputs_4_payload_flowId  (io_request_fork_io_outputs_4_payload_flowId[4:0] ), //o
    .clk                          (clk                                              ), //i
    .reset                        (reset                                            )  //i
  );
  Mapper engineMapper (
    .io_readReq_valid             (io_request_fork_io_outputs_0_map_toFlow_valid             ), //i
    .io_readReq_payload           (io_request_fork_io_outputs_0_map_toFlow_payload[2:0]      ), //i
    .io_readRes_valid             (engineMapper_io_readRes_valid                             ), //o
    .io_readRes_payload           (engineMapper_io_readRes_payload[1:0]                      ), //o
    .io_writeReq_valid            (io_control_fork_io_outputs_0_takeWhen_valid               ), //i
    .io_writeReq_payload_inputId  (io_control_fork_io_outputs_0_takeWhen_payload_vPifoId[2:0]), //i
    .io_writeReq_payload_outputId (engineMapper_io_writeReq_payload_outputId[1:0]            ), //i
    .clk                          (clk                                                       ), //i
    .reset                        (reset                                                     )  //i
  );
  Mapper_1 lastVirtualMapper (
    .io_readReq_valid             (io_request_fork_io_outputs_1_map_toFlow_valid       ), //i
    .io_readReq_payload           (io_request_fork_io_outputs_1_map_toFlow_payload[2:0]), //i
    .io_readRes_valid             (lastVirtualMapper_io_readRes_valid                  ), //o
    .io_readRes_payload           (lastVirtualMapper_io_readRes_payload[7:0]           ), //o
    .io_writeReq_valid            (io_poped_takeWhen_valid                             ), //i
    .io_writeReq_payload_inputId  (io_poped_takeWhen_payload_port[2:0]                 ), //i
    .io_writeReq_payload_outputId (io_poped_takeWhen_payload_priority[7:0]             ), //i
    .clk                          (clk                                                 ), //i
    .reset                        (reset                                               )  //i
  );
  Mapper_2 engineCAM (
    .io_readReq_valid             (io_request_fork_io_outputs_2_map_toFlow_valid       ), //i
    .io_readReq_payload           (io_request_fork_io_outputs_2_map_toFlow_payload[7:0]), //i
    .io_readRes_valid             (engineCAM_io_readRes_valid                          ), //o
    .io_readRes_payload           (engineCAM_io_readRes_payload[31:0]                  ), //o
    .io_writeReq_valid            (streamArbiter_9_io_output_valid                     ), //i
    .io_writeReq_payload_inputId  (streamArbiter_9_io_output_payload_inputId[7:0]      ), //i
    .io_writeReq_payload_outputId (streamArbiter_9_io_output_payload_outputId[31:0]    ), //i
    .clk                          (clk                                                 ), //i
    .reset                        (reset                                               )  //i
  );
  StreamFifoLowLatency_3 flowStateUpdate_toStream_fifo (
    .io_push_valid            (flowStateUpdate_toStream_valid                             ), //i
    .io_push_ready            (flowStateUpdate_toStream_fifo_io_push_ready                ), //o
    .io_push_payload_inputId  (flowStateUpdate_toStream_payload_inputId[7:0]              ), //i
    .io_push_payload_outputId (flowStateUpdate_toStream_payload_outputId[31:0]            ), //i
    .io_pop_valid             (flowStateUpdate_toStream_fifo_io_pop_valid                 ), //o
    .io_pop_ready             (streamArbiter_9_io_inputs_1_ready                          ), //i
    .io_pop_payload_inputId   (flowStateUpdate_toStream_fifo_io_pop_payload_inputId[7:0]  ), //o
    .io_pop_payload_outputId  (flowStateUpdate_toStream_fifo_io_pop_payload_outputId[31:0]), //o
    .io_flush                 (1'b0                                                       ), //i
    .io_occupancy             (flowStateUpdate_toStream_fifo_io_occupancy[1:0]            ), //o
    .io_availability          (flowStateUpdate_toStream_fifo_io_availability[1:0]         ), //o
    .clk                      (clk                                                        ), //i
    .reset                    (reset                                                      )  //i
  );
  StreamArbiter_3 streamArbiter_9 (
    .io_inputs_0_valid            (flowStateControl_toStream_valid                            ), //i
    .io_inputs_0_ready            (streamArbiter_9_io_inputs_0_ready                          ), //o
    .io_inputs_0_payload_inputId  (flowStateControl_toStream_payload_inputId[7:0]             ), //i
    .io_inputs_0_payload_outputId (flowStateControl_toStream_payload_outputId[31:0]           ), //i
    .io_inputs_1_valid            (flowStateUpdate_toStream_fifo_io_pop_valid                 ), //i
    .io_inputs_1_ready            (streamArbiter_9_io_inputs_1_ready                          ), //o
    .io_inputs_1_payload_inputId  (flowStateUpdate_toStream_fifo_io_pop_payload_inputId[7:0]  ), //i
    .io_inputs_1_payload_outputId (flowStateUpdate_toStream_fifo_io_pop_payload_outputId[31:0]), //i
    .io_output_valid              (streamArbiter_9_io_output_valid                            ), //o
    .io_output_ready              (1'b1                                                       ), //i
    .io_output_payload_inputId    (streamArbiter_9_io_output_payload_inputId[7:0]             ), //o
    .io_output_payload_outputId   (streamArbiter_9_io_output_payload_outputId[31:0]           ), //o
    .io_chosen                    (streamArbiter_9_io_chosen                                  ), //o
    .io_chosenOH                  (streamArbiter_9_io_chosenOH[1:0]                           ), //o
    .clk                          (clk                                                        ), //i
    .reset                        (reset                                                      )  //i
  );
  Mapper_3 brainStateMem (
    .io_readReq_valid             (io_request_fork_io_outputs_3_map_toFlow_valid       ), //i
    .io_readReq_payload           (io_request_fork_io_outputs_3_map_toFlow_payload[2:0]), //i
    .io_readRes_valid             (brainStateMem_io_readRes_valid                      ), //o
    .io_readRes_payload           (brainStateMem_io_readRes_payload[31:0]              ), //o
    .io_writeReq_valid            (streamArbiter_10_io_output_valid                    ), //i
    .io_writeReq_payload_inputId  (streamArbiter_10_io_output_payload_inputId[2:0]     ), //i
    .io_writeReq_payload_outputId (streamArbiter_10_io_output_payload_outputId[31:0]   ), //i
    .clk                          (clk                                                 ), //i
    .reset                        (reset                                               )  //i
  );
  StreamFifoLowLatency_4 brainStateUpdate_toStream_fifo (
    .io_push_valid            (brainStateUpdate_toStream_valid                             ), //i
    .io_push_ready            (brainStateUpdate_toStream_fifo_io_push_ready                ), //o
    .io_push_payload_inputId  (brainStateUpdate_toStream_payload_inputId[2:0]              ), //i
    .io_push_payload_outputId (brainStateUpdate_toStream_payload_outputId[31:0]            ), //i
    .io_pop_valid             (brainStateUpdate_toStream_fifo_io_pop_valid                 ), //o
    .io_pop_ready             (streamArbiter_10_io_inputs_1_ready                          ), //i
    .io_pop_payload_inputId   (brainStateUpdate_toStream_fifo_io_pop_payload_inputId[2:0]  ), //o
    .io_pop_payload_outputId  (brainStateUpdate_toStream_fifo_io_pop_payload_outputId[31:0]), //o
    .io_flush                 (1'b0                                                        ), //i
    .io_occupancy             (brainStateUpdate_toStream_fifo_io_occupancy[1:0]            ), //o
    .io_availability          (brainStateUpdate_toStream_fifo_io_availability[1:0]         ), //o
    .clk                      (clk                                                         ), //i
    .reset                    (reset                                                       )  //i
  );
  StreamArbiter_4 streamArbiter_10 (
    .io_inputs_0_valid            (brainStateControl_toStream_valid                            ), //i
    .io_inputs_0_ready            (streamArbiter_10_io_inputs_0_ready                          ), //o
    .io_inputs_0_payload_inputId  (brainStateControl_toStream_payload_inputId[2:0]             ), //i
    .io_inputs_0_payload_outputId (brainStateControl_toStream_payload_outputId[31:0]           ), //i
    .io_inputs_1_valid            (brainStateUpdate_toStream_fifo_io_pop_valid                 ), //i
    .io_inputs_1_ready            (streamArbiter_10_io_inputs_1_ready                          ), //o
    .io_inputs_1_payload_inputId  (brainStateUpdate_toStream_fifo_io_pop_payload_inputId[2:0]  ), //i
    .io_inputs_1_payload_outputId (brainStateUpdate_toStream_fifo_io_pop_payload_outputId[31:0]), //i
    .io_output_valid              (streamArbiter_10_io_output_valid                            ), //o
    .io_output_ready              (1'b1                                                        ), //i
    .io_output_payload_inputId    (streamArbiter_10_io_output_payload_inputId[2:0]             ), //o
    .io_output_payload_outputId   (streamArbiter_10_io_output_payload_outputId[31:0]           ), //o
    .io_chosen                    (streamArbiter_10_io_chosen                                  ), //o
    .io_chosenOH                  (streamArbiter_10_io_chosenOH[1:0]                           ), //o
    .clk                          (clk                                                         ), //i
    .reset                        (reset                                                       )  //i
  );
  StreamFork_1 io_control_fork (
    .io_input_valid                (io_control_valid                                  ), //i
    .io_input_ready                (io_control_fork_io_input_ready                    ), //o
    .io_input_payload_command      (io_control_payload_command[2:0]                   ), //i
    .io_input_payload_engineId     (io_control_payload_engineId[1:0]                  ), //i
    .io_input_payload_vPifoId      (io_control_payload_vPifoId[2:0]                   ), //i
    .io_input_payload_flowId       (io_control_payload_flowId[4:0]                    ), //i
    .io_input_payload_data         (io_control_payload_data[31:0]                     ), //i
    .io_outputs_0_valid            (io_control_fork_io_outputs_0_valid                ), //o
    .io_outputs_0_ready            (io_control_fork_io_outputs_0_ready                ), //i
    .io_outputs_0_payload_command  (io_control_fork_io_outputs_0_payload_command[2:0] ), //o
    .io_outputs_0_payload_engineId (io_control_fork_io_outputs_0_payload_engineId[1:0]), //o
    .io_outputs_0_payload_vPifoId  (io_control_fork_io_outputs_0_payload_vPifoId[2:0] ), //o
    .io_outputs_0_payload_flowId   (io_control_fork_io_outputs_0_payload_flowId[4:0]  ), //o
    .io_outputs_0_payload_data     (io_control_fork_io_outputs_0_payload_data[31:0]   ), //o
    .io_outputs_1_valid            (io_control_fork_io_outputs_1_valid                ), //o
    .io_outputs_1_ready            (io_control_fork_io_outputs_1_ready                ), //i
    .io_outputs_1_payload_command  (io_control_fork_io_outputs_1_payload_command[2:0] ), //o
    .io_outputs_1_payload_engineId (io_control_fork_io_outputs_1_payload_engineId[1:0]), //o
    .io_outputs_1_payload_vPifoId  (io_control_fork_io_outputs_1_payload_vPifoId[2:0] ), //o
    .io_outputs_1_payload_flowId   (io_control_fork_io_outputs_1_payload_flowId[4:0]  ), //o
    .io_outputs_1_payload_data     (io_control_fork_io_outputs_1_payload_data[31:0]   ), //o
    .io_outputs_2_valid            (io_control_fork_io_outputs_2_valid                ), //o
    .io_outputs_2_ready            (io_control_fork_io_outputs_2_ready                ), //i
    .io_outputs_2_payload_command  (io_control_fork_io_outputs_2_payload_command[2:0] ), //o
    .io_outputs_2_payload_engineId (io_control_fork_io_outputs_2_payload_engineId[1:0]), //o
    .io_outputs_2_payload_vPifoId  (io_control_fork_io_outputs_2_payload_vPifoId[2:0] ), //o
    .io_outputs_2_payload_flowId   (io_control_fork_io_outputs_2_payload_flowId[4:0]  ), //o
    .io_outputs_2_payload_data     (io_control_fork_io_outputs_2_payload_data[31:0]   ), //o
    .clk                           (clk                                               ), //i
    .reset                         (reset                                             )  //i
  );
  StreamFifoLowLatency_5 engineMapper_io_readRes_toStream_fifo (
    .io_push_valid   (engineMapper_io_readRes_toStream_valid                    ), //i
    .io_push_ready   (engineMapper_io_readRes_toStream_fifo_io_push_ready       ), //o
    .io_push_payload (engineMapper_io_readRes_toStream_payload[1:0]             ), //i
    .io_pop_valid    (engineMapper_io_readRes_toStream_fifo_io_pop_valid        ), //o
    .io_pop_ready    (_zz_io_pop_ready                                          ), //i
    .io_pop_payload  (engineMapper_io_readRes_toStream_fifo_io_pop_payload[1:0] ), //o
    .io_flush        (1'b0                                                      ), //i
    .io_occupancy    (engineMapper_io_readRes_toStream_fifo_io_occupancy[1:0]   ), //o
    .io_availability (engineMapper_io_readRes_toStream_fifo_io_availability[1:0]), //o
    .clk             (clk                                                       ), //i
    .reset           (reset                                                     )  //i
  );
  StreamFifoLowLatency_6 brainStateMem_io_readRes_toStream_fifo (
    .io_push_valid   (brainStateMem_io_readRes_toStream_valid                    ), //i
    .io_push_ready   (brainStateMem_io_readRes_toStream_fifo_io_push_ready       ), //o
    .io_push_payload (brainStateMem_io_readRes_toStream_payload[31:0]            ), //i
    .io_pop_valid    (brainStateMem_io_readRes_toStream_fifo_io_pop_valid        ), //o
    .io_pop_ready    (_zz_io_pop_ready                                           ), //i
    .io_pop_payload  (brainStateMem_io_readRes_toStream_fifo_io_pop_payload[31:0]), //o
    .io_flush        (1'b0                                                       ), //i
    .io_occupancy    (brainStateMem_io_readRes_toStream_fifo_io_occupancy[1:0]   ), //o
    .io_availability (brainStateMem_io_readRes_toStream_fifo_io_availability[1:0]), //o
    .clk             (clk                                                        ), //i
    .reset           (reset                                                      )  //i
  );
  StreamFifoLowLatency_6 engineCAM_io_readRes_toStream_fifo (
    .io_push_valid   (engineCAM_io_readRes_toStream_valid                    ), //i
    .io_push_ready   (engineCAM_io_readRes_toStream_fifo_io_push_ready       ), //o
    .io_push_payload (engineCAM_io_readRes_toStream_payload[31:0]            ), //i
    .io_pop_valid    (engineCAM_io_readRes_toStream_fifo_io_pop_valid        ), //o
    .io_pop_ready    (_zz_io_pop_ready                                       ), //i
    .io_pop_payload  (engineCAM_io_readRes_toStream_fifo_io_pop_payload[31:0]), //o
    .io_flush        (1'b0                                                   ), //i
    .io_occupancy    (engineCAM_io_readRes_toStream_fifo_io_occupancy[1:0]   ), //o
    .io_availability (engineCAM_io_readRes_toStream_fifo_io_availability[1:0]), //o
    .clk             (clk                                                    ), //i
    .reset           (reset                                                  )  //i
  );
  StreamFifoLowLatency_8 lastVirtualMapper_io_readRes_toStream_fifo (
    .io_push_valid   (lastVirtualMapper_io_readRes_toStream_valid                    ), //i
    .io_push_ready   (lastVirtualMapper_io_readRes_toStream_fifo_io_push_ready       ), //o
    .io_push_payload (lastVirtualMapper_io_readRes_toStream_payload[7:0]             ), //i
    .io_pop_valid    (lastVirtualMapper_io_readRes_toStream_fifo_io_pop_valid        ), //o
    .io_pop_ready    (_zz_io_pop_ready                                               ), //i
    .io_pop_payload  (lastVirtualMapper_io_readRes_toStream_fifo_io_pop_payload[7:0] ), //o
    .io_flush        (1'b0                                                           ), //i
    .io_occupancy    (lastVirtualMapper_io_readRes_toStream_fifo_io_occupancy[1:0]   ), //o
    .io_availability (lastVirtualMapper_io_readRes_toStream_fifo_io_availability[1:0]), //o
    .clk             (clk                                                            ), //i
    .reset           (reset                                                          )  //i
  );
  StreamFifoLowLatency_9 io_outputs_4_fifo (
    .io_push_valid           (io_request_fork_io_outputs_4_valid               ), //i
    .io_push_ready           (io_outputs_4_fifo_io_push_ready                  ), //o
    .io_push_payload_vpifoId (io_request_fork_io_outputs_4_payload_vpifoId[2:0]), //i
    .io_push_payload_flowId  (io_request_fork_io_outputs_4_payload_flowId[4:0] ), //i
    .io_pop_valid            (io_outputs_4_fifo_io_pop_valid                   ), //o
    .io_pop_ready            (_zz_io_pop_ready                                 ), //i
    .io_pop_payload_vpifoId  (io_outputs_4_fifo_io_pop_payload_vpifoId[2:0]    ), //o
    .io_pop_payload_flowId   (io_outputs_4_fifo_io_pop_payload_flowId[4:0]     ), //o
    .io_flush                (1'b0                                             ), //i
    .io_occupancy            (io_outputs_4_fifo_io_occupancy[1:0]              ), //o
    .io_availability         (io_outputs_4_fifo_io_availability[1:0]           ), //o
    .clk                     (clk                                              ), //i
    .reset                   (reset                                            )  //i
  );
  `ifndef SYNTHESIS
  always @(*) begin
    case(io_control_payload_command)
      ControlCommand_UpdateMapperPre : io_control_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_control_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_control_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_control_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_control_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_control_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_control_payload_command_string = "UpdateBrainFlowState";
      default : io_control_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_control_fork_io_outputs_0_takeWhen_payload_command)
      ControlCommand_UpdateMapperPre : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "UpdateBrainFlowState";
      default : io_control_fork_io_outputs_0_takeWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_control_fork_io_outputs_1_takeWhen_payload_command)
      ControlCommand_UpdateMapperPre : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "UpdateBrainFlowState";
      default : io_control_fork_io_outputs_1_takeWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_control_fork_io_outputs_2_takeWhen_payload_command)
      ControlCommand_UpdateMapperPre : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "UpdateBrainFlowState";
      default : io_control_fork_io_outputs_2_takeWhen_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(switch_PifoEngine_l367)
      BrainType_NOP : switch_PifoEngine_l367_string = "NOP ";
      BrainType_WFQ : switch_PifoEngine_l367_string = "WFQ ";
      BrainType_SP : switch_PifoEngine_l367_string = "SP  ";
      BrainType_FIFO : switch_PifoEngine_l367_string = "FIFO";
      default : switch_PifoEngine_l367_string = "????";
    endcase
  end
  always @(*) begin
    case(_zz_switch_PifoEngine_l367)
      BrainType_NOP : _zz_switch_PifoEngine_l367_string = "NOP ";
      BrainType_WFQ : _zz_switch_PifoEngine_l367_string = "WFQ ";
      BrainType_SP : _zz_switch_PifoEngine_l367_string = "SP  ";
      BrainType_FIFO : _zz_switch_PifoEngine_l367_string = "FIFO";
      default : _zz_switch_PifoEngine_l367_string = "????";
    endcase
  end
  `endif

  assign io_request_ready = io_request_fork_io_input_ready;
  assign io_request_fork_io_outputs_0_map_valid = io_request_fork_io_outputs_0_valid;
  assign io_request_fork_io_outputs_0_map_payload = io_request_fork_io_outputs_0_payload_vpifoId;
  assign io_request_fork_io_outputs_0_map_ready = 1'b1;
  assign io_request_fork_io_outputs_0_map_toFlow_valid = io_request_fork_io_outputs_0_map_valid;
  assign io_request_fork_io_outputs_0_map_toFlow_payload = io_request_fork_io_outputs_0_map_payload;
  assign io_poped_takeWhen_valid = (io_poped_valid && (! (! io_poped_payload_exist)));
  assign io_poped_takeWhen_payload_exist = io_poped_payload_exist;
  assign io_poped_takeWhen_payload_priority = io_poped_payload_priority;
  assign io_poped_takeWhen_payload_data = io_poped_payload_data;
  assign io_poped_takeWhen_payload_port = io_poped_payload_port;
  assign io_request_fork_io_outputs_1_map_valid = io_request_fork_io_outputs_1_valid;
  assign io_request_fork_io_outputs_1_map_payload = io_request_fork_io_outputs_1_payload_vpifoId;
  assign io_request_fork_io_outputs_1_map_ready = 1'b1;
  assign io_request_fork_io_outputs_1_map_toFlow_valid = io_request_fork_io_outputs_1_map_valid;
  assign io_request_fork_io_outputs_1_map_toFlow_payload = io_request_fork_io_outputs_1_map_payload;
  assign io_request_fork_io_outputs_2_map_valid = io_request_fork_io_outputs_2_valid;
  assign io_request_fork_io_outputs_2_map_payload = {io_request_fork_io_outputs_2_payload_vpifoId,io_request_fork_io_outputs_2_payload_flowId};
  assign io_request_fork_io_outputs_2_map_ready = 1'b1;
  assign io_request_fork_io_outputs_2_map_toFlow_valid = io_request_fork_io_outputs_2_map_valid;
  assign io_request_fork_io_outputs_2_map_toFlow_payload = io_request_fork_io_outputs_2_map_payload;
  assign flowStateControl_toStream_valid = flowStateControl_valid;
  assign flowStateControl_toStream_payload_inputId = flowStateControl_payload_inputId;
  assign flowStateControl_toStream_payload_outputId = flowStateControl_payload_outputId;
  assign flowStateUpdate_toStream_valid = flowStateUpdate_valid;
  assign flowStateUpdate_toStream_payload_inputId = flowStateUpdate_payload_inputId;
  assign flowStateUpdate_toStream_payload_outputId = flowStateUpdate_payload_outputId;
  assign flowStateUpdate_toStream_ready = flowStateUpdate_toStream_fifo_io_push_ready;
  assign flowStateControl_toStream_ready = streamArbiter_9_io_inputs_0_ready;
  assign io_request_fork_io_outputs_3_map_valid = io_request_fork_io_outputs_3_valid;
  assign io_request_fork_io_outputs_3_map_payload = io_request_fork_io_outputs_3_payload_vpifoId;
  assign io_request_fork_io_outputs_3_map_ready = 1'b1;
  assign io_request_fork_io_outputs_3_map_toFlow_valid = io_request_fork_io_outputs_3_map_valid;
  assign io_request_fork_io_outputs_3_map_toFlow_payload = io_request_fork_io_outputs_3_map_payload;
  assign brainStateControl_toStream_valid = brainStateControl_valid;
  assign brainStateControl_toStream_payload_inputId = brainStateControl_payload_inputId;
  assign brainStateControl_toStream_payload_outputId = brainStateControl_payload_outputId;
  assign brainStateUpdate_toStream_valid = brainStateUpdate_valid;
  assign brainStateUpdate_toStream_payload_inputId = brainStateUpdate_payload_inputId;
  assign brainStateUpdate_toStream_payload_outputId = brainStateUpdate_payload_outputId;
  assign brainStateUpdate_toStream_ready = brainStateUpdate_toStream_fifo_io_push_ready;
  assign brainStateControl_toStream_ready = streamArbiter_10_io_inputs_0_ready;
  assign io_control_ready = io_control_fork_io_input_ready;
  assign when_Stream_l581 = (! (io_control_fork_io_outputs_0_payload_command == ControlCommand_UpdateBrainEngine));
  always @(*) begin
    io_control_fork_io_outputs_0_takeWhen_valid = io_control_fork_io_outputs_0_valid;
    if(when_Stream_l581) begin
      io_control_fork_io_outputs_0_takeWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    io_control_fork_io_outputs_0_ready = io_control_fork_io_outputs_0_takeWhen_ready;
    if(when_Stream_l581) begin
      io_control_fork_io_outputs_0_ready = 1'b1;
    end
  end

  assign io_control_fork_io_outputs_0_takeWhen_payload_command = io_control_fork_io_outputs_0_payload_command;
  assign io_control_fork_io_outputs_0_takeWhen_payload_engineId = io_control_fork_io_outputs_0_payload_engineId;
  assign io_control_fork_io_outputs_0_takeWhen_payload_vPifoId = io_control_fork_io_outputs_0_payload_vPifoId;
  assign io_control_fork_io_outputs_0_takeWhen_payload_flowId = io_control_fork_io_outputs_0_payload_flowId;
  assign io_control_fork_io_outputs_0_takeWhen_payload_data = io_control_fork_io_outputs_0_payload_data;
  assign io_control_fork_io_outputs_0_takeWhen_ready = 1'b1;
  assign engineMapper_io_writeReq_payload_outputId = io_control_fork_io_outputs_0_takeWhen_payload_data[1:0];
  assign when_Stream_l581_1 = (! (io_control_fork_io_outputs_1_payload_command == ControlCommand_UpdateBrainFlowState));
  always @(*) begin
    io_control_fork_io_outputs_1_takeWhen_valid = io_control_fork_io_outputs_1_valid;
    if(when_Stream_l581_1) begin
      io_control_fork_io_outputs_1_takeWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    io_control_fork_io_outputs_1_ready = io_control_fork_io_outputs_1_takeWhen_ready;
    if(when_Stream_l581_1) begin
      io_control_fork_io_outputs_1_ready = 1'b1;
    end
  end

  assign io_control_fork_io_outputs_1_takeWhen_payload_command = io_control_fork_io_outputs_1_payload_command;
  assign io_control_fork_io_outputs_1_takeWhen_payload_engineId = io_control_fork_io_outputs_1_payload_engineId;
  assign io_control_fork_io_outputs_1_takeWhen_payload_vPifoId = io_control_fork_io_outputs_1_payload_vPifoId;
  assign io_control_fork_io_outputs_1_takeWhen_payload_flowId = io_control_fork_io_outputs_1_payload_flowId;
  assign io_control_fork_io_outputs_1_takeWhen_payload_data = io_control_fork_io_outputs_1_payload_data;
  assign io_control_fork_io_outputs_1_takeWhen_ready = 1'b1;
  assign flowStateControl_valid = io_control_fork_io_outputs_1_takeWhen_valid;
  assign flowStateControl_payload_inputId = {io_control_fork_io_outputs_1_takeWhen_payload_vPifoId,io_control_fork_io_outputs_1_takeWhen_payload_flowId};
  assign flowStateControl_payload_outputId = io_control_fork_io_outputs_1_takeWhen_payload_data;
  assign when_Stream_l581_2 = (! (io_control_fork_io_outputs_2_payload_command == ControlCommand_UpdateBrainState));
  always @(*) begin
    io_control_fork_io_outputs_2_takeWhen_valid = io_control_fork_io_outputs_2_valid;
    if(when_Stream_l581_2) begin
      io_control_fork_io_outputs_2_takeWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    io_control_fork_io_outputs_2_ready = io_control_fork_io_outputs_2_takeWhen_ready;
    if(when_Stream_l581_2) begin
      io_control_fork_io_outputs_2_ready = 1'b1;
    end
  end

  assign io_control_fork_io_outputs_2_takeWhen_payload_command = io_control_fork_io_outputs_2_payload_command;
  assign io_control_fork_io_outputs_2_takeWhen_payload_engineId = io_control_fork_io_outputs_2_payload_engineId;
  assign io_control_fork_io_outputs_2_takeWhen_payload_vPifoId = io_control_fork_io_outputs_2_payload_vPifoId;
  assign io_control_fork_io_outputs_2_takeWhen_payload_flowId = io_control_fork_io_outputs_2_payload_flowId;
  assign io_control_fork_io_outputs_2_takeWhen_payload_data = io_control_fork_io_outputs_2_payload_data;
  assign io_control_fork_io_outputs_2_takeWhen_ready = 1'b1;
  assign brainStateControl_valid = io_control_fork_io_outputs_2_takeWhen_valid;
  assign brainStateControl_payload_inputId = io_control_fork_io_outputs_2_takeWhen_payload_vPifoId;
  assign brainStateControl_payload_outputId = io_control_fork_io_outputs_2_takeWhen_payload_data;
  assign engineMapper_io_readRes_toStream_valid = engineMapper_io_readRes_valid;
  assign engineMapper_io_readRes_toStream_payload = engineMapper_io_readRes_payload;
  assign engineMapper_io_readRes_toStream_ready = engineMapper_io_readRes_toStream_fifo_io_push_ready;
  assign brainStateMem_io_readRes_toStream_valid = brainStateMem_io_readRes_valid;
  assign brainStateMem_io_readRes_toStream_payload = brainStateMem_io_readRes_payload;
  assign brainStateMem_io_readRes_toStream_ready = brainStateMem_io_readRes_toStream_fifo_io_push_ready;
  assign engineCAM_io_readRes_toStream_valid = engineCAM_io_readRes_valid;
  assign engineCAM_io_readRes_toStream_payload = engineCAM_io_readRes_payload;
  assign engineCAM_io_readRes_toStream_ready = engineCAM_io_readRes_toStream_fifo_io_push_ready;
  assign lastVirtualMapper_io_readRes_toStream_valid = lastVirtualMapper_io_readRes_valid;
  assign lastVirtualMapper_io_readRes_toStream_payload = lastVirtualMapper_io_readRes_payload;
  assign lastVirtualMapper_io_readRes_toStream_ready = lastVirtualMapper_io_readRes_toStream_fifo_io_push_ready;
  assign _zz_io_pop_ready = (_zz_engineStream_valid && engineStream_ready);
  assign _zz_engineStream_valid = ((((engineMapper_io_readRes_toStream_fifo_io_pop_valid && brainStateMem_io_readRes_toStream_fifo_io_pop_valid) && engineCAM_io_readRes_toStream_fifo_io_pop_valid) && lastVirtualMapper_io_readRes_toStream_fifo_io_pop_valid) && io_outputs_4_fifo_io_pop_valid);
  assign engineStream_valid = _zz_engineStream_valid;
  assign engineStream_payload_pifoId = io_outputs_4_fifo_io_pop_payload_vpifoId;
  assign engineStream_payload_flowId = io_outputs_4_fifo_io_pop_payload_flowId;
  assign engineStream_payload_engineId = engineMapper_io_readRes_toStream_fifo_io_pop_payload;
  assign engineStream_payload_flowState = engineCAM_io_readRes_toStream_fifo_io_pop_payload;
  assign engineStream_payload_brainState = brainStateMem_io_readRes_toStream_fifo_io_pop_payload;
  assign engineStream_payload_virutalTime = lastVirtualMapper_io_readRes_toStream_fifo_io_pop_payload;
  always @(*) begin
    _zz_outStream_payload_entry_priority = 8'h0;
    case(switch_PifoEngine_l367)
      BrainType_SP : begin
        _zz_outStream_payload_entry_priority = engineStream_payload_flowState[7:0];
      end
      BrainType_WFQ : begin
        _zz_outStream_payload_entry_priority = _zz_outStream_payload_entry_priority_3;
      end
      BrainType_FIFO : begin
        _zz_outStream_payload_entry_priority = _zz_outStream_payload_entry_priority_4;
      end
      default : begin
      end
    endcase
  end

  always @(*) begin
    _zz_outStream_payload_flowUpdate_flow_outputId = 32'h0;
    case(switch_PifoEngine_l367)
      BrainType_WFQ : begin
        _zz_outStream_payload_flowUpdate_flow_outputId = {24'd0, _zz_outStream_payload_entry_priority_3};
      end
      default : begin
      end
    endcase
  end

  always @(*) begin
    _zz_outStream_payload_flowUpdate_update = 1'b0;
    case(switch_PifoEngine_l367)
      BrainType_WFQ : begin
        _zz_outStream_payload_flowUpdate_update = 1'b1;
      end
      default : begin
      end
    endcase
  end

  always @(*) begin
    _zz_outStream_payload_brainUpdate_brain_outputId = 32'h0;
    case(switch_PifoEngine_l367)
      BrainType_FIFO : begin
        _zz_outStream_payload_brainUpdate_brain_outputId = {24'd0, _zz_outStream_payload_entry_priority_4};
      end
      default : begin
      end
    endcase
  end

  always @(*) begin
    _zz_outStream_payload_brainUpdate_update = 1'b0;
    case(switch_PifoEngine_l367)
      BrainType_FIFO : begin
        _zz_outStream_payload_brainUpdate_update = 1'b1;
      end
      default : begin
      end
    endcase
  end

  assign _zz_switch_PifoEngine_l367 = engineStream_payload_engineId;
  assign switch_PifoEngine_l367 = _zz_switch_PifoEngine_l367;
  assign _zz_outStream_payload_entry_priority_1 = engineStream_payload_virutalTime;
  assign _zz_outStream_payload_entry_priority_2 = engineStream_payload_flowState[7:0];
  assign _zz_outStream_payload_entry_priority_3 = (((_zz_outStream_payload_entry_priority_2 < _zz_outStream_payload_entry_priority_1) ? _zz_outStream_payload_entry_priority_1 : _zz_outStream_payload_entry_priority_2) + 8'h10);
  assign _zz_outStream_payload_entry_priority_4 = (_zz__zz_outStream_payload_entry_priority_4 + 8'h01);
  assign outStream_valid = engineStream_valid;
  assign engineStream_ready = outStream_ready;
  assign outStream_payload_entry_priority = _zz_outStream_payload_entry_priority;
  assign outStream_payload_entry_data = engineStream_payload_flowId;
  assign outStream_payload_entry_port = engineStream_payload_pifoId;
  assign outStream_payload_flowUpdate_flow_inputId = {engineStream_payload_pifoId,engineStream_payload_flowId};
  assign outStream_payload_flowUpdate_flow_outputId = _zz_outStream_payload_flowUpdate_flow_outputId;
  assign outStream_payload_flowUpdate_update = _zz_outStream_payload_flowUpdate_update;
  assign outStream_payload_brainUpdate_brain_inputId = engineStream_payload_pifoId;
  assign outStream_payload_brainUpdate_brain_outputId = _zz_outStream_payload_brainUpdate_brain_outputId;
  assign outStream_payload_brainUpdate_update = _zz_outStream_payload_brainUpdate_update;
  always @(*) begin
    outStream_ready = 1'b1;
    if(when_Stream_l1253) begin
      outStream_ready = 1'b0;
    end
    if(when_Stream_l1253_1) begin
      outStream_ready = 1'b0;
    end
    if(when_Stream_l1253_2) begin
      outStream_ready = 1'b0;
    end
  end

  assign when_Stream_l1253 = ((! output_ready) && outStream_fork3_logic_linkEnable_0);
  assign when_Stream_l1253_1 = ((! flowUpdates_ready) && outStream_fork3_logic_linkEnable_1);
  assign when_Stream_l1253_2 = ((! brainUpdates_ready) && outStream_fork3_logic_linkEnable_2);
  assign output_valid = (outStream_valid && outStream_fork3_logic_linkEnable_0);
  assign output_payload_entry_priority = outStream_payload_entry_priority;
  assign output_payload_entry_data = outStream_payload_entry_data;
  assign output_payload_entry_port = outStream_payload_entry_port;
  assign output_payload_flowUpdate_flow_inputId = outStream_payload_flowUpdate_flow_inputId;
  assign output_payload_flowUpdate_flow_outputId = outStream_payload_flowUpdate_flow_outputId;
  assign output_payload_flowUpdate_update = outStream_payload_flowUpdate_update;
  assign output_payload_brainUpdate_brain_inputId = outStream_payload_brainUpdate_brain_inputId;
  assign output_payload_brainUpdate_brain_outputId = outStream_payload_brainUpdate_brain_outputId;
  assign output_payload_brainUpdate_update = outStream_payload_brainUpdate_update;
  assign output_fire = (output_valid && output_ready);
  assign flowUpdates_valid = (outStream_valid && outStream_fork3_logic_linkEnable_1);
  assign flowUpdates_payload_entry_priority = outStream_payload_entry_priority;
  assign flowUpdates_payload_entry_data = outStream_payload_entry_data;
  assign flowUpdates_payload_entry_port = outStream_payload_entry_port;
  assign flowUpdates_payload_flowUpdate_flow_inputId = outStream_payload_flowUpdate_flow_inputId;
  assign flowUpdates_payload_flowUpdate_flow_outputId = outStream_payload_flowUpdate_flow_outputId;
  assign flowUpdates_payload_flowUpdate_update = outStream_payload_flowUpdate_update;
  assign flowUpdates_payload_brainUpdate_brain_inputId = outStream_payload_brainUpdate_brain_inputId;
  assign flowUpdates_payload_brainUpdate_brain_outputId = outStream_payload_brainUpdate_brain_outputId;
  assign flowUpdates_payload_brainUpdate_update = outStream_payload_brainUpdate_update;
  assign flowUpdates_fire = (flowUpdates_valid && flowUpdates_ready);
  assign brainUpdates_valid = (outStream_valid && outStream_fork3_logic_linkEnable_2);
  assign brainUpdates_payload_entry_priority = outStream_payload_entry_priority;
  assign brainUpdates_payload_entry_data = outStream_payload_entry_data;
  assign brainUpdates_payload_entry_port = outStream_payload_entry_port;
  assign brainUpdates_payload_flowUpdate_flow_inputId = outStream_payload_flowUpdate_flow_inputId;
  assign brainUpdates_payload_flowUpdate_flow_outputId = outStream_payload_flowUpdate_flow_outputId;
  assign brainUpdates_payload_flowUpdate_update = outStream_payload_flowUpdate_update;
  assign brainUpdates_payload_brainUpdate_brain_inputId = outStream_payload_brainUpdate_brain_inputId;
  assign brainUpdates_payload_brainUpdate_brain_outputId = outStream_payload_brainUpdate_brain_outputId;
  assign brainUpdates_payload_brainUpdate_update = outStream_payload_brainUpdate_update;
  assign brainUpdates_fire = (brainUpdates_valid && brainUpdates_ready);
  assign when_Stream_l581_3 = (output_payload_entry_priority == 8'h0);
  always @(*) begin
    output_throwWhen_valid = output_valid;
    if(when_Stream_l581_3) begin
      output_throwWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    output_ready = output_throwWhen_ready;
    if(when_Stream_l581_3) begin
      output_ready = 1'b1;
    end
  end

  assign output_throwWhen_payload_entry_priority = output_payload_entry_priority;
  assign output_throwWhen_payload_entry_data = output_payload_entry_data;
  assign output_throwWhen_payload_entry_port = output_payload_entry_port;
  assign output_throwWhen_payload_flowUpdate_flow_inputId = output_payload_flowUpdate_flow_inputId;
  assign output_throwWhen_payload_flowUpdate_flow_outputId = output_payload_flowUpdate_flow_outputId;
  assign output_throwWhen_payload_flowUpdate_update = output_payload_flowUpdate_update;
  assign output_throwWhen_payload_brainUpdate_brain_inputId = output_payload_brainUpdate_brain_inputId;
  assign output_throwWhen_payload_brainUpdate_brain_outputId = output_payload_brainUpdate_brain_outputId;
  assign output_throwWhen_payload_brainUpdate_update = output_payload_brainUpdate_update;
  assign output_throwWhen_map_valid = output_throwWhen_valid;
  assign output_throwWhen_ready = output_throwWhen_map_ready;
  assign output_throwWhen_map_payload_priority = output_throwWhen_payload_entry_priority;
  assign output_throwWhen_map_payload_data = output_throwWhen_payload_entry_data;
  assign output_throwWhen_map_payload_port = output_throwWhen_payload_entry_port;
  assign io_response_valid = output_throwWhen_map_valid;
  assign output_throwWhen_map_ready = io_response_ready;
  assign io_response_payload_priority = output_throwWhen_map_payload_priority;
  assign io_response_payload_data = output_throwWhen_map_payload_data;
  assign io_response_payload_port = output_throwWhen_map_payload_port;
  assign when_Stream_l581_4 = (! flowUpdates_payload_flowUpdate_update);
  always @(*) begin
    flowUpdates_throwWhen_valid = flowUpdates_valid;
    if(when_Stream_l581_4) begin
      flowUpdates_throwWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    flowUpdates_ready = flowUpdates_throwWhen_ready;
    if(when_Stream_l581_4) begin
      flowUpdates_ready = 1'b1;
    end
  end

  assign flowUpdates_throwWhen_payload_entry_priority = flowUpdates_payload_entry_priority;
  assign flowUpdates_throwWhen_payload_entry_data = flowUpdates_payload_entry_data;
  assign flowUpdates_throwWhen_payload_entry_port = flowUpdates_payload_entry_port;
  assign flowUpdates_throwWhen_payload_flowUpdate_flow_inputId = flowUpdates_payload_flowUpdate_flow_inputId;
  assign flowUpdates_throwWhen_payload_flowUpdate_flow_outputId = flowUpdates_payload_flowUpdate_flow_outputId;
  assign flowUpdates_throwWhen_payload_flowUpdate_update = flowUpdates_payload_flowUpdate_update;
  assign flowUpdates_throwWhen_payload_brainUpdate_brain_inputId = flowUpdates_payload_brainUpdate_brain_inputId;
  assign flowUpdates_throwWhen_payload_brainUpdate_brain_outputId = flowUpdates_payload_brainUpdate_brain_outputId;
  assign flowUpdates_throwWhen_payload_brainUpdate_update = flowUpdates_payload_brainUpdate_update;
  assign flowUpdates_throwWhen_map_valid = flowUpdates_throwWhen_valid;
  assign flowUpdates_throwWhen_ready = flowUpdates_throwWhen_map_ready;
  assign flowUpdates_throwWhen_map_payload_inputId = flowUpdates_throwWhen_payload_flowUpdate_flow_inputId;
  assign flowUpdates_throwWhen_map_payload_outputId = flowUpdates_throwWhen_payload_flowUpdate_flow_outputId;
  assign flowUpdates_throwWhen_map_ready = 1'b1;
  assign flowUpdates_throwWhen_map_toFlow_valid = flowUpdates_throwWhen_map_valid;
  assign flowUpdates_throwWhen_map_toFlow_payload_inputId = flowUpdates_throwWhen_map_payload_inputId;
  assign flowUpdates_throwWhen_map_toFlow_payload_outputId = flowUpdates_throwWhen_map_payload_outputId;
  assign flowStateUpdate_valid = flowUpdates_throwWhen_map_toFlow_valid;
  assign flowStateUpdate_payload_inputId = flowUpdates_throwWhen_map_toFlow_payload_inputId;
  assign flowStateUpdate_payload_outputId = flowUpdates_throwWhen_map_toFlow_payload_outputId;
  assign when_Stream_l581_5 = (! brainUpdates_payload_brainUpdate_update);
  always @(*) begin
    brainUpdates_throwWhen_valid = brainUpdates_valid;
    if(when_Stream_l581_5) begin
      brainUpdates_throwWhen_valid = 1'b0;
    end
  end

  always @(*) begin
    brainUpdates_ready = brainUpdates_throwWhen_ready;
    if(when_Stream_l581_5) begin
      brainUpdates_ready = 1'b1;
    end
  end

  assign brainUpdates_throwWhen_payload_entry_priority = brainUpdates_payload_entry_priority;
  assign brainUpdates_throwWhen_payload_entry_data = brainUpdates_payload_entry_data;
  assign brainUpdates_throwWhen_payload_entry_port = brainUpdates_payload_entry_port;
  assign brainUpdates_throwWhen_payload_flowUpdate_flow_inputId = brainUpdates_payload_flowUpdate_flow_inputId;
  assign brainUpdates_throwWhen_payload_flowUpdate_flow_outputId = brainUpdates_payload_flowUpdate_flow_outputId;
  assign brainUpdates_throwWhen_payload_flowUpdate_update = brainUpdates_payload_flowUpdate_update;
  assign brainUpdates_throwWhen_payload_brainUpdate_brain_inputId = brainUpdates_payload_brainUpdate_brain_inputId;
  assign brainUpdates_throwWhen_payload_brainUpdate_brain_outputId = brainUpdates_payload_brainUpdate_brain_outputId;
  assign brainUpdates_throwWhen_payload_brainUpdate_update = brainUpdates_payload_brainUpdate_update;
  assign brainUpdates_throwWhen_map_valid = brainUpdates_throwWhen_valid;
  assign brainUpdates_throwWhen_ready = brainUpdates_throwWhen_map_ready;
  assign brainUpdates_throwWhen_map_payload_inputId = brainUpdates_throwWhen_payload_brainUpdate_brain_inputId;
  assign brainUpdates_throwWhen_map_payload_outputId = brainUpdates_throwWhen_payload_brainUpdate_brain_outputId;
  assign brainUpdates_throwWhen_map_ready = 1'b1;
  assign brainUpdates_throwWhen_map_toFlow_valid = brainUpdates_throwWhen_map_valid;
  assign brainUpdates_throwWhen_map_toFlow_payload_inputId = brainUpdates_throwWhen_map_payload_inputId;
  assign brainUpdates_throwWhen_map_toFlow_payload_outputId = brainUpdates_throwWhen_map_payload_outputId;
  assign brainStateUpdate_valid = brainUpdates_throwWhen_map_toFlow_valid;
  assign brainStateUpdate_payload_inputId = brainUpdates_throwWhen_map_toFlow_payload_inputId;
  assign brainStateUpdate_payload_outputId = brainUpdates_throwWhen_map_toFlow_payload_outputId;
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      outStream_fork3_logic_linkEnable_0 <= 1'b1;
      outStream_fork3_logic_linkEnable_1 <= 1'b1;
      outStream_fork3_logic_linkEnable_2 <= 1'b1;
    end else begin
      if(output_fire) begin
        outStream_fork3_logic_linkEnable_0 <= 1'b0;
      end
      if(flowUpdates_fire) begin
        outStream_fork3_logic_linkEnable_1 <= 1'b0;
      end
      if(brainUpdates_fire) begin
        outStream_fork3_logic_linkEnable_2 <= 1'b0;
      end
      if(outStream_ready) begin
        outStream_fork3_logic_linkEnable_0 <= 1'b1;
        outStream_fork3_logic_linkEnable_1 <= 1'b1;
        outStream_fork3_logic_linkEnable_2 <= 1'b1;
      end
    end
  end


endmodule

module StreamFifoLowLatency_10 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [1:0]    io_push_payload_engineId,
  input  wire [2:0]    io_push_payload_vPifoId,
  output wire          io_pop_valid,
  input  wire          io_pop_ready,
  output wire [1:0]    io_pop_payload_engineId,
  output wire [2:0]    io_pop_payload_vPifoId,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire                fifo_io_push_ready;
  wire                fifo_io_pop_valid;
  wire       [1:0]    fifo_io_pop_payload_engineId;
  wire       [2:0]    fifo_io_pop_payload_vPifoId;
  wire       [1:0]    fifo_io_occupancy;
  wire       [1:0]    fifo_io_availability;

  StreamFifo_3 fifo (
    .io_push_valid            (io_push_valid                    ), //i
    .io_push_ready            (fifo_io_push_ready               ), //o
    .io_push_payload_engineId (io_push_payload_engineId[1:0]    ), //i
    .io_push_payload_vPifoId  (io_push_payload_vPifoId[2:0]     ), //i
    .io_pop_valid             (fifo_io_pop_valid                ), //o
    .io_pop_ready             (io_pop_ready                     ), //i
    .io_pop_payload_engineId  (fifo_io_pop_payload_engineId[1:0]), //o
    .io_pop_payload_vPifoId   (fifo_io_pop_payload_vPifoId[2:0] ), //o
    .io_flush                 (io_flush                         ), //i
    .io_occupancy             (fifo_io_occupancy[1:0]           ), //o
    .io_availability          (fifo_io_availability[1:0]        ), //o
    .clk                      (clk                              ), //i
    .reset                    (reset                            )  //i
  );
  assign io_push_ready = fifo_io_push_ready;
  assign io_pop_valid = fifo_io_pop_valid;
  assign io_pop_payload_engineId = fifo_io_pop_payload_engineId;
  assign io_pop_payload_vPifoId = fifo_io_pop_payload_vPifoId;
  assign io_occupancy = fifo_io_occupancy;
  assign io_availability = fifo_io_availability;

endmodule

module ReplayMapper (
  input  wire          io_readReq_valid,
  input  wire [2:0]    io_readReq_payload,
  output wire          io_readRes_valid,
  output wire [2:0]    io_readRes_payload,
  input  wire          io_writeReq_valid,
  output wire          io_writeReq_ready,
  input  wire [2:0]    io_writeReq_payload_inputId,
  input  wire [2:0]    io_writeReq_payload_outputId,
  input  wire          io_commit,
  output wire          io_commitReady,
  input  wire          clk,
  input  wire          reset
);

  reg        [2:0]    banks_0_spinal_port0;
  reg        [2:0]    banks_1_spinal_port0;
  wire       [2:0]    _zz_banks_0_port;
  wire                _zz_banks_0_port_1;
  wire       [2:0]    _zz_banks_1_port;
  wire                _zz_banks_1_port_1;
  reg                 activeBank;
  reg                 requestedBank;
  wire                _zz_bankRead_0;
  wire       [2:0]    bankRead_0;
  wire                _zz_bankRead_1;
  wire       [2:0]    bankRead_1;
  reg                 io_readReq_valid_regNext;
  wire                io_writeReq_fire;
  reg [2:0] banks_0 [0:7];
  reg [2:0] banks_1 [0:7];

  assign _zz_banks_0_port = io_writeReq_payload_outputId;
  assign _zz_banks_0_port_1 = (io_writeReq_fire && activeBank);
  assign _zz_banks_1_port = io_writeReq_payload_outputId;
  assign _zz_banks_1_port_1 = (io_writeReq_fire && (! activeBank));
  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_0_enque_enqueMapper_banks_0.bin",banks_0);
  end
  always @(posedge clk) begin
    if(_zz_bankRead_0) begin
      banks_0_spinal_port0 <= banks_0[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_banks_0_port_1) begin
      banks_0[io_writeReq_payload_inputId] <= _zz_banks_0_port;
    end
  end

  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_0_enque_enqueMapper_banks_1.bin",banks_1);
  end
  always @(posedge clk) begin
    if(_zz_bankRead_1) begin
      banks_1_spinal_port0 <= banks_1[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_banks_1_port_1) begin
      banks_1[io_writeReq_payload_inputId] <= _zz_banks_1_port;
    end
  end

  assign _zz_bankRead_0 = (io_readReq_valid && (! activeBank));
  assign bankRead_0 = banks_0_spinal_port0;
  assign _zz_bankRead_1 = (io_readReq_valid && activeBank);
  assign bankRead_1 = banks_1_spinal_port0;
  assign io_readRes_valid = io_readReq_valid_regNext;
  assign io_readRes_payload = (requestedBank ? bankRead_1 : bankRead_0);
  assign io_writeReq_ready = 1'b1;
  assign io_commitReady = 1'b1;
  assign io_writeReq_fire = (io_writeReq_valid && io_writeReq_ready);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      activeBank <= 1'b0;
      requestedBank <= 1'b0;
      io_readReq_valid_regNext <= 1'b0;
    end else begin
      if(io_readReq_valid) begin
        requestedBank <= activeBank;
      end
      io_readReq_valid_regNext <= io_readReq_valid;
      if(io_commit) begin
        activeBank <= (! activeBank);
      end
    end
  end


endmodule

module ExternalPifoCore (
  input  wire          io_push1_valid,
  input  wire [7:0]    io_push1_payload_priority,
  input  wire [4:0]    io_push1_payload_data,
  input  wire [2:0]    io_push1_payload_port,
  input  wire          io_push2_valid,
  input  wire [7:0]    io_push2_payload_priority,
  input  wire [4:0]    io_push2_payload_data,
  input  wire [2:0]    io_push2_payload_port,
  input  wire          io_popRequest_valid,
  input  wire [2:0]    io_popRequest_payload_port,
  output wire          io_popResponse_valid,
  output wire          io_popResponse_payload_exist,
  output wire [7:0]    io_popResponse_payload_priority,
  output wire [4:0]    io_popResponse_payload_data,
  output wire [2:0]    io_popResponse_payload_port,
  output wire          io_popPortEmpty,
  output wire          io_portDrained_valid,
  output wire [2:0]    io_portDrained_payload,
  output wire          boundary_push1_valid,
  output wire [7:0]    boundary_push1_payload_priority,
  output wire [4:0]    boundary_push1_payload_data,
  output wire [2:0]    boundary_push1_payload_port,
  output wire          boundary_push2_valid,
  output wire [7:0]    boundary_push2_payload_priority,
  output wire [4:0]    boundary_push2_payload_data,
  output wire [2:0]    boundary_push2_payload_port,
  output wire          boundary_popRequest_valid,
  output wire [2:0]    boundary_popRequest_payload_port,
  input  wire          boundary_popResponse_valid,
  input  wire          boundary_popResponse_payload_exist,
  input  wire [7:0]    boundary_popResponse_payload_priority,
  input  wire [4:0]    boundary_popResponse_payload_data,
  input  wire [2:0]    boundary_popResponse_payload_port,
  input  wire          boundary_popPortEmpty,
  input  wire          boundary_portDrained_valid,
  input  wire [2:0]    boundary_portDrained_payload
);


  assign boundary_push1_valid = io_push1_valid;
  assign boundary_push1_payload_priority = io_push1_payload_priority;
  assign boundary_push1_payload_data = io_push1_payload_data;
  assign boundary_push1_payload_port = io_push1_payload_port;
  assign boundary_push2_valid = io_push2_valid;
  assign boundary_push2_payload_priority = io_push2_payload_priority;
  assign boundary_push2_payload_data = io_push2_payload_data;
  assign boundary_push2_payload_port = io_push2_payload_port;
  assign boundary_popRequest_valid = io_popRequest_valid;
  assign boundary_popRequest_payload_port = io_popRequest_payload_port;
  assign io_popResponse_valid = boundary_popResponse_valid;
  assign io_popResponse_payload_exist = boundary_popResponse_payload_exist;
  assign io_popResponse_payload_priority = boundary_popResponse_payload_priority;
  assign io_popResponse_payload_data = boundary_popResponse_payload_data;
  assign io_popResponse_payload_port = boundary_popResponse_payload_port;
  assign io_popPortEmpty = boundary_popPortEmpty;
  assign io_portDrained_valid = boundary_portDrained_valid;
  assign io_portDrained_payload = boundary_portDrained_payload;

endmodule

//StreamArbiter_2 replaced by StreamArbiter

//StreamArbiter_1 replaced by StreamArbiter

module StreamArbiter (
  input  wire          io_inputs_0_valid,
  output wire          io_inputs_0_ready,
  input  wire [1:0]    io_inputs_0_payload_engineId,
  input  wire [2:0]    io_inputs_0_payload_vPifoId,
  input  wire          io_inputs_1_valid,
  output wire          io_inputs_1_ready,
  input  wire [1:0]    io_inputs_1_payload_engineId,
  input  wire [2:0]    io_inputs_1_payload_vPifoId,
  input  wire          io_inputs_2_valid,
  output wire          io_inputs_2_ready,
  input  wire [1:0]    io_inputs_2_payload_engineId,
  input  wire [2:0]    io_inputs_2_payload_vPifoId,
  output wire          io_output_valid,
  input  wire          io_output_ready,
  output wire [1:0]    io_output_payload_engineId,
  output wire [2:0]    io_output_payload_vPifoId,
  output wire [1:0]    io_chosen,
  output wire [2:0]    io_chosenOH,
  input  wire          clk,
  input  wire          reset
);

  wire       [2:0]    _zz__zz_maskProposal_1_1;
  reg        [1:0]    _zz_io_output_payload_engineId_1;
  reg        [2:0]    _zz_io_output_payload_vPifoId;
  reg                 locked;
  wire                maskProposal_0;
  wire                maskProposal_1;
  wire                maskProposal_2;
  reg                 maskLocked_0;
  reg                 maskLocked_1;
  reg                 maskLocked_2;
  wire                maskRouted_0;
  wire                maskRouted_1;
  wire                maskRouted_2;
  wire       [2:0]    _zz_maskProposal_1;
  wire       [2:0]    _zz_maskProposal_1_1;
  wire                io_output_fire;
  wire       [1:0]    _zz_io_output_payload_engineId;
  wire                _zz_io_chosen;
  wire                _zz_io_chosen_1;

  assign _zz__zz_maskProposal_1_1 = (_zz_maskProposal_1 - 3'b001);
  always @(*) begin
    case(_zz_io_output_payload_engineId)
      2'b00 : begin
        _zz_io_output_payload_engineId_1 = io_inputs_0_payload_engineId;
        _zz_io_output_payload_vPifoId = io_inputs_0_payload_vPifoId;
      end
      2'b01 : begin
        _zz_io_output_payload_engineId_1 = io_inputs_1_payload_engineId;
        _zz_io_output_payload_vPifoId = io_inputs_1_payload_vPifoId;
      end
      default : begin
        _zz_io_output_payload_engineId_1 = io_inputs_2_payload_engineId;
        _zz_io_output_payload_vPifoId = io_inputs_2_payload_vPifoId;
      end
    endcase
  end

  assign maskRouted_0 = (locked ? maskLocked_0 : maskProposal_0);
  assign maskRouted_1 = (locked ? maskLocked_1 : maskProposal_1);
  assign maskRouted_2 = (locked ? maskLocked_2 : maskProposal_2);
  assign _zz_maskProposal_1 = {io_inputs_2_valid,{io_inputs_1_valid,io_inputs_0_valid}};
  assign _zz_maskProposal_1_1 = (_zz_maskProposal_1 & (~ _zz__zz_maskProposal_1_1));
  assign maskProposal_0 = io_inputs_0_valid;
  assign maskProposal_1 = _zz_maskProposal_1_1[1];
  assign maskProposal_2 = _zz_maskProposal_1_1[2];
  assign io_output_fire = (io_output_valid && io_output_ready);
  assign io_output_valid = (((io_inputs_0_valid && maskRouted_0) || (io_inputs_1_valid && maskRouted_1)) || (io_inputs_2_valid && maskRouted_2));
  assign _zz_io_output_payload_engineId = {maskRouted_2,maskRouted_1};
  assign io_output_payload_engineId = _zz_io_output_payload_engineId_1;
  assign io_output_payload_vPifoId = _zz_io_output_payload_vPifoId;
  assign io_inputs_0_ready = ((1'b0 || maskRouted_0) && io_output_ready);
  assign io_inputs_1_ready = ((1'b0 || maskRouted_1) && io_output_ready);
  assign io_inputs_2_ready = ((1'b0 || maskRouted_2) && io_output_ready);
  assign io_chosenOH = {maskRouted_2,{maskRouted_1,maskRouted_0}};
  assign _zz_io_chosen = io_chosenOH[1];
  assign _zz_io_chosen_1 = io_chosenOH[2];
  assign io_chosen = {_zz_io_chosen_1,_zz_io_chosen};
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      locked <= 1'b0;
    end else begin
      if(io_output_valid) begin
        locked <= 1'b1;
      end
      if(io_output_fire) begin
        locked <= 1'b0;
      end
    end
  end

  always @(posedge clk) begin
    if(io_output_valid) begin
      maskLocked_0 <= maskRouted_0;
      maskLocked_1 <= maskRouted_1;
      maskLocked_2 <= maskRouted_2;
    end
  end


endmodule

//StreamDemux_2 replaced by StreamDemux

//StreamFifoLowLatency_2 replaced by StreamFifoLowLatency

//StreamDemux_1 replaced by StreamDemux

//StreamFifoLowLatency_1 replaced by StreamFifoLowLatency

module StreamDemux (
  input  wire [1:0]    io_select,
  input  wire          io_input_valid,
  output reg           io_input_ready,
  input  wire [1:0]    io_input_payload_engineId,
  input  wire [2:0]    io_input_payload_vPifoId,
  output reg           io_outputs_0_valid,
  input  wire          io_outputs_0_ready,
  output wire [1:0]    io_outputs_0_payload_engineId,
  output wire [2:0]    io_outputs_0_payload_vPifoId,
  output reg           io_outputs_1_valid,
  input  wire          io_outputs_1_ready,
  output wire [1:0]    io_outputs_1_payload_engineId,
  output wire [2:0]    io_outputs_1_payload_vPifoId,
  output reg           io_outputs_2_valid,
  input  wire          io_outputs_2_ready,
  output wire [1:0]    io_outputs_2_payload_engineId,
  output wire [2:0]    io_outputs_2_payload_vPifoId
);

  wire                when_Stream_l1168;
  wire                when_Stream_l1168_1;
  wire                when_Stream_l1168_2;

  always @(*) begin
    io_input_ready = 1'b0;
    if(!when_Stream_l1168) begin
      io_input_ready = io_outputs_0_ready;
    end
    if(!when_Stream_l1168_1) begin
      io_input_ready = io_outputs_1_ready;
    end
    if(!when_Stream_l1168_2) begin
      io_input_ready = io_outputs_2_ready;
    end
  end

  assign io_outputs_0_payload_engineId = io_input_payload_engineId;
  assign io_outputs_0_payload_vPifoId = io_input_payload_vPifoId;
  assign when_Stream_l1168 = (2'b00 != io_select);
  always @(*) begin
    if(when_Stream_l1168) begin
      io_outputs_0_valid = 1'b0;
    end else begin
      io_outputs_0_valid = io_input_valid;
    end
  end

  assign io_outputs_1_payload_engineId = io_input_payload_engineId;
  assign io_outputs_1_payload_vPifoId = io_input_payload_vPifoId;
  assign when_Stream_l1168_1 = (2'b01 != io_select);
  always @(*) begin
    if(when_Stream_l1168_1) begin
      io_outputs_1_valid = 1'b0;
    end else begin
      io_outputs_1_valid = io_input_valid;
    end
  end

  assign io_outputs_2_payload_engineId = io_input_payload_engineId;
  assign io_outputs_2_payload_vPifoId = io_input_payload_vPifoId;
  assign when_Stream_l1168_2 = (2'b10 != io_select);
  always @(*) begin
    if(when_Stream_l1168_2) begin
      io_outputs_2_valid = 1'b0;
    end else begin
      io_outputs_2_valid = io_input_valid;
    end
  end


endmodule

module StreamFifoLowLatency (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [1:0]    io_push_payload_engineId,
  input  wire [2:0]    io_push_payload_vPifoId,
  output wire          io_pop_valid,
  input  wire          io_pop_ready,
  output wire [1:0]    io_pop_payload_engineId,
  output wire [2:0]    io_pop_payload_vPifoId,
  input  wire          io_flush,
  output wire [3:0]    io_occupancy,
  output wire [3:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire                fifo_io_push_ready;
  wire                fifo_io_pop_valid;
  wire       [1:0]    fifo_io_pop_payload_engineId;
  wire       [2:0]    fifo_io_pop_payload_vPifoId;
  wire       [3:0]    fifo_io_occupancy;
  wire       [3:0]    fifo_io_availability;

  StreamFifo fifo (
    .io_push_valid            (io_push_valid                    ), //i
    .io_push_ready            (fifo_io_push_ready               ), //o
    .io_push_payload_engineId (io_push_payload_engineId[1:0]    ), //i
    .io_push_payload_vPifoId  (io_push_payload_vPifoId[2:0]     ), //i
    .io_pop_valid             (fifo_io_pop_valid                ), //o
    .io_pop_ready             (io_pop_ready                     ), //i
    .io_pop_payload_engineId  (fifo_io_pop_payload_engineId[1:0]), //o
    .io_pop_payload_vPifoId   (fifo_io_pop_payload_vPifoId[2:0] ), //o
    .io_flush                 (io_flush                         ), //i
    .io_occupancy             (fifo_io_occupancy[3:0]           ), //o
    .io_availability          (fifo_io_availability[3:0]        ), //o
    .clk                      (clk                              ), //i
    .reset                    (reset                            )  //i
  );
  assign io_push_ready = fifo_io_push_ready;
  assign io_pop_valid = fifo_io_pop_valid;
  assign io_pop_payload_engineId = fifo_io_pop_payload_engineId;
  assign io_pop_payload_vPifoId = fifo_io_pop_payload_vPifoId;
  assign io_occupancy = fifo_io_occupancy;
  assign io_availability = fifo_io_availability;

endmodule

//StreamFifo_20 replaced by StreamFifo_11

//StreamFifoLowLatency_18 replaced by StreamFifoLowLatency_9

//StreamFifoLowLatency_17 replaced by StreamFifoLowLatency_8

//StreamFifoLowLatency_16 replaced by StreamFifoLowLatency_6

//StreamFifoLowLatency_15 replaced by StreamFifoLowLatency_6

//StreamFifoLowLatency_14 replaced by StreamFifoLowLatency_5

//StreamFork_5 replaced by StreamFork_1

//StreamArbiter_6 replaced by StreamArbiter_4

//StreamFifoLowLatency_13 replaced by StreamFifoLowLatency_4

module Mapper_7 (
  input  wire          io_readReq_valid,
  input  wire [2:0]    io_readReq_payload,
  output wire          io_readRes_valid,
  output wire [31:0]   io_readRes_payload,
  input  wire          io_writeReq_valid,
  input  wire [2:0]    io_writeReq_payload_inputId,
  input  wire [31:0]   io_writeReq_payload_outputId,
  input  wire          clk,
  input  wire          reset
);

  reg        [31:0]   ram_spinal_port0;
  wire                _zz_ram_port;
  wire                _zz_io_readRes_payload;
  wire       [31:0]   _zz_ram_port_1;
  reg                 _zz_1;
  reg                 io_readReq_valid_regNext;
  reg [31:0] ram [0:7];

  assign _zz_io_readRes_payload = 1'b1;
  assign _zz_ram_port_1 = io_writeReq_payload_outputId;
  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_1_enque_brain_brainStateMem_ram.bin",ram);
  end
  always @(posedge clk) begin
    if(_zz_io_readRes_payload) begin
      ram_spinal_port0 <= ram[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_1) begin
      ram[io_writeReq_payload_inputId] <= _zz_ram_port_1;
    end
  end

  always @(*) begin
    _zz_1 = 1'b0;
    if(io_writeReq_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign io_readRes_valid = io_readReq_valid_regNext;
  assign io_readRes_payload = ram_spinal_port0;
  always @(posedge clk) begin
    io_readReq_valid_regNext <= io_readReq_valid;
  end


endmodule

//StreamArbiter_5 replaced by StreamArbiter_3

//StreamFifoLowLatency_12 replaced by StreamFifoLowLatency_3

module Mapper_6 (
  input  wire          io_readReq_valid,
  input  wire [7:0]    io_readReq_payload,
  output wire          io_readRes_valid,
  output wire [31:0]   io_readRes_payload,
  input  wire          io_writeReq_valid,
  input  wire [7:0]    io_writeReq_payload_inputId,
  input  wire [31:0]   io_writeReq_payload_outputId,
  input  wire          clk,
  input  wire          reset
);

  reg        [31:0]   ram_spinal_port0;
  wire                _zz_ram_port;
  wire                _zz_io_readRes_payload;
  wire       [31:0]   _zz_ram_port_1;
  reg                 _zz_1;
  reg                 io_readReq_valid_regNext;
  reg [31:0] ram [0:255];

  assign _zz_io_readRes_payload = 1'b1;
  assign _zz_ram_port_1 = io_writeReq_payload_outputId;
  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_1_enque_brain_engineCAM_ram.bin",ram);
  end
  always @(posedge clk) begin
    if(_zz_io_readRes_payload) begin
      ram_spinal_port0 <= ram[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_1) begin
      ram[io_writeReq_payload_inputId] <= _zz_ram_port_1;
    end
  end

  always @(*) begin
    _zz_1 = 1'b0;
    if(io_writeReq_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign io_readRes_valid = io_readReq_valid_regNext;
  assign io_readRes_payload = ram_spinal_port0;
  always @(posedge clk) begin
    io_readReq_valid_regNext <= io_readReq_valid;
  end


endmodule

module Mapper_5 (
  input  wire          io_readReq_valid,
  input  wire [2:0]    io_readReq_payload,
  output wire          io_readRes_valid,
  output wire [7:0]    io_readRes_payload,
  input  wire          io_writeReq_valid,
  input  wire [2:0]    io_writeReq_payload_inputId,
  input  wire [7:0]    io_writeReq_payload_outputId,
  input  wire          clk,
  input  wire          reset
);

  reg        [7:0]    ram_spinal_port0;
  wire                _zz_ram_port;
  wire                _zz_io_readRes_payload;
  wire       [7:0]    _zz_ram_port_1;
  reg                 _zz_1;
  reg                 io_readReq_valid_regNext;
  reg [7:0] ram [0:7];

  assign _zz_io_readRes_payload = 1'b1;
  assign _zz_ram_port_1 = io_writeReq_payload_outputId;
  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_1_enque_brain_lastVirtualMapper_ram.bin",ram);
  end
  always @(posedge clk) begin
    if(_zz_io_readRes_payload) begin
      ram_spinal_port0 <= ram[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_1) begin
      ram[io_writeReq_payload_inputId] <= _zz_ram_port_1;
    end
  end

  always @(*) begin
    _zz_1 = 1'b0;
    if(io_writeReq_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign io_readRes_valid = io_readReq_valid_regNext;
  assign io_readRes_payload = ram_spinal_port0;
  always @(posedge clk) begin
    io_readReq_valid_regNext <= io_readReq_valid;
  end


endmodule

module Mapper_4 (
  input  wire          io_readReq_valid,
  input  wire [2:0]    io_readReq_payload,
  output wire          io_readRes_valid,
  output wire [1:0]    io_readRes_payload,
  input  wire          io_writeReq_valid,
  input  wire [2:0]    io_writeReq_payload_inputId,
  input  wire [1:0]    io_writeReq_payload_outputId,
  input  wire          clk,
  input  wire          reset
);

  reg        [1:0]    ram_spinal_port0;
  wire                _zz_ram_port;
  wire                _zz_io_readRes_payload;
  wire       [1:0]    _zz_ram_port_1;
  reg                 _zz_1;
  reg                 io_readReq_valid_regNext;
  reg [1:0] ram [0:7];

  assign _zz_io_readRes_payload = 1'b1;
  assign _zz_ram_port_1 = io_writeReq_payload_outputId;
  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_1_enque_brain_engineMapper_ram.bin",ram);
  end
  always @(posedge clk) begin
    if(_zz_io_readRes_payload) begin
      ram_spinal_port0 <= ram[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_1) begin
      ram[io_writeReq_payload_inputId] <= _zz_ram_port_1;
    end
  end

  always @(*) begin
    _zz_1 = 1'b0;
    if(io_writeReq_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign io_readRes_valid = io_readReq_valid_regNext;
  assign io_readRes_payload = ram_spinal_port0;
  always @(posedge clk) begin
    io_readReq_valid_regNext <= io_readReq_valid;
  end


endmodule

//StreamFork_4 replaced by StreamFork

//StreamFifo_12 replaced by StreamFifo_3

module StreamFifo_11 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire          io_push_payload_exist,
  input  wire [7:0]    io_push_payload_priority,
  input  wire [4:0]    io_push_payload_data,
  input  wire [2:0]    io_push_payload_port,
  output reg           io_pop_valid,
  input  wire          io_pop_ready,
  output reg           io_pop_payload_exist,
  output reg  [7:0]    io_pop_payload_priority,
  output reg  [4:0]    io_pop_payload_data,
  output reg  [2:0]    io_pop_payload_port,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire       [16:0]   logic_ram_spinal_port1;
  wire       [16:0]   _zz_logic_ram_port;
  reg                 _zz_1;
  reg                 logic_ptr_doPush;
  wire                logic_ptr_doPop;
  wire                logic_ptr_full;
  wire                logic_ptr_empty;
  reg        [1:0]    logic_ptr_push;
  reg        [1:0]    logic_ptr_pop;
  wire       [1:0]    logic_ptr_occupancy;
  wire       [1:0]    logic_ptr_popOnIo;
  wire                when_Stream_l1455;
  reg                 logic_ptr_wentUp;
  wire                io_push_fire;
  wire                logic_push_onRam_write_valid;
  wire       [0:0]    logic_push_onRam_write_payload_address;
  wire                logic_push_onRam_write_payload_data_exist;
  wire       [7:0]    logic_push_onRam_write_payload_data_priority;
  wire       [4:0]    logic_push_onRam_write_payload_data_data;
  wire       [2:0]    logic_push_onRam_write_payload_data_port;
  wire                logic_pop_addressGen_valid;
  wire                logic_pop_addressGen_ready;
  wire       [0:0]    logic_pop_addressGen_payload;
  wire                logic_pop_addressGen_fire;
  wire                logic_pop_async_readed_exist;
  wire       [7:0]    logic_pop_async_readed_priority;
  wire       [4:0]    logic_pop_async_readed_data;
  wire       [2:0]    logic_pop_async_readed_port;
  wire       [16:0]   _zz_logic_pop_async_readed_exist;
  wire                logic_pop_addressGen_translated_valid;
  wire                logic_pop_addressGen_translated_ready;
  wire                logic_pop_addressGen_translated_payload_exist;
  wire       [7:0]    logic_pop_addressGen_translated_payload_priority;
  wire       [4:0]    logic_pop_addressGen_translated_payload_data;
  wire       [2:0]    logic_pop_addressGen_translated_payload_port;
  (* ram_style = "distributed" *) reg [16:0] logic_ram [0:1];

  assign _zz_logic_ram_port = {logic_push_onRam_write_payload_data_port,{logic_push_onRam_write_payload_data_data,{logic_push_onRam_write_payload_data_priority,logic_push_onRam_write_payload_data_exist}}};
  always @(posedge clk) begin
    if(_zz_1) begin
      logic_ram[logic_push_onRam_write_payload_address] <= _zz_logic_ram_port;
    end
  end

  assign logic_ram_spinal_port1 = logic_ram[logic_pop_addressGen_payload];
  always @(*) begin
    _zz_1 = 1'b0;
    if(logic_push_onRam_write_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign when_Stream_l1455 = (logic_ptr_doPush != logic_ptr_doPop);
  assign logic_ptr_full = (((logic_ptr_push ^ logic_ptr_popOnIo) ^ 2'b10) == 2'b00);
  assign logic_ptr_empty = (logic_ptr_push == logic_ptr_pop);
  assign logic_ptr_occupancy = (logic_ptr_push - logic_ptr_popOnIo);
  assign io_push_ready = (! logic_ptr_full);
  assign io_push_fire = (io_push_valid && io_push_ready);
  always @(*) begin
    logic_ptr_doPush = io_push_fire;
    if(logic_ptr_empty) begin
      if(io_pop_ready) begin
        logic_ptr_doPush = 1'b0;
      end
    end
  end

  assign logic_push_onRam_write_valid = io_push_fire;
  assign logic_push_onRam_write_payload_address = logic_ptr_push[0:0];
  assign logic_push_onRam_write_payload_data_exist = io_push_payload_exist;
  assign logic_push_onRam_write_payload_data_priority = io_push_payload_priority;
  assign logic_push_onRam_write_payload_data_data = io_push_payload_data;
  assign logic_push_onRam_write_payload_data_port = io_push_payload_port;
  assign logic_pop_addressGen_valid = (! logic_ptr_empty);
  assign logic_pop_addressGen_payload = logic_ptr_pop[0:0];
  assign logic_pop_addressGen_fire = (logic_pop_addressGen_valid && logic_pop_addressGen_ready);
  assign logic_ptr_doPop = logic_pop_addressGen_fire;
  assign _zz_logic_pop_async_readed_exist = logic_ram_spinal_port1;
  assign logic_pop_async_readed_exist = _zz_logic_pop_async_readed_exist[0];
  assign logic_pop_async_readed_priority = _zz_logic_pop_async_readed_exist[8 : 1];
  assign logic_pop_async_readed_data = _zz_logic_pop_async_readed_exist[13 : 9];
  assign logic_pop_async_readed_port = _zz_logic_pop_async_readed_exist[16 : 14];
  assign logic_pop_addressGen_translated_valid = logic_pop_addressGen_valid;
  assign logic_pop_addressGen_ready = logic_pop_addressGen_translated_ready;
  assign logic_pop_addressGen_translated_payload_exist = logic_pop_async_readed_exist;
  assign logic_pop_addressGen_translated_payload_priority = logic_pop_async_readed_priority;
  assign logic_pop_addressGen_translated_payload_data = logic_pop_async_readed_data;
  assign logic_pop_addressGen_translated_payload_port = logic_pop_async_readed_port;
  always @(*) begin
    io_pop_valid = logic_pop_addressGen_translated_valid;
    if(logic_ptr_empty) begin
      io_pop_valid = io_push_valid;
    end
  end

  assign logic_pop_addressGen_translated_ready = io_pop_ready;
  always @(*) begin
    io_pop_payload_exist = logic_pop_addressGen_translated_payload_exist;
    if(logic_ptr_empty) begin
      io_pop_payload_exist = io_push_payload_exist;
    end
  end

  always @(*) begin
    io_pop_payload_priority = logic_pop_addressGen_translated_payload_priority;
    if(logic_ptr_empty) begin
      io_pop_payload_priority = io_push_payload_priority;
    end
  end

  always @(*) begin
    io_pop_payload_data = logic_pop_addressGen_translated_payload_data;
    if(logic_ptr_empty) begin
      io_pop_payload_data = io_push_payload_data;
    end
  end

  always @(*) begin
    io_pop_payload_port = logic_pop_addressGen_translated_payload_port;
    if(logic_ptr_empty) begin
      io_pop_payload_port = io_push_payload_port;
    end
  end

  assign logic_ptr_popOnIo = logic_ptr_pop;
  assign io_occupancy = logic_ptr_occupancy;
  assign io_availability = (2'b10 - logic_ptr_occupancy);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      logic_ptr_push <= 2'b00;
      logic_ptr_pop <= 2'b00;
      logic_ptr_wentUp <= 1'b0;
    end else begin
      if(when_Stream_l1455) begin
        logic_ptr_wentUp <= logic_ptr_doPush;
      end
      if(io_flush) begin
        logic_ptr_wentUp <= 1'b0;
      end
      if(logic_ptr_doPush) begin
        logic_ptr_push <= (logic_ptr_push + 2'b01);
      end
      if(logic_ptr_doPop) begin
        logic_ptr_pop <= (logic_ptr_pop + 2'b01);
      end
      if(io_flush) begin
        logic_ptr_push <= 2'b00;
        logic_ptr_pop <= 2'b00;
      end
    end
  end


endmodule

module StreamFifoLowLatency_9 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [2:0]    io_push_payload_vpifoId,
  input  wire [4:0]    io_push_payload_flowId,
  output wire          io_pop_valid,
  input  wire          io_pop_ready,
  output wire [2:0]    io_pop_payload_vpifoId,
  output wire [4:0]    io_pop_payload_flowId,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire                fifo_io_push_ready;
  wire                fifo_io_pop_valid;
  wire       [2:0]    fifo_io_pop_payload_vpifoId;
  wire       [4:0]    fifo_io_pop_payload_flowId;
  wire       [1:0]    fifo_io_occupancy;
  wire       [1:0]    fifo_io_availability;

  StreamFifo_10 fifo (
    .io_push_valid           (io_push_valid                   ), //i
    .io_push_ready           (fifo_io_push_ready              ), //o
    .io_push_payload_vpifoId (io_push_payload_vpifoId[2:0]    ), //i
    .io_push_payload_flowId  (io_push_payload_flowId[4:0]     ), //i
    .io_pop_valid            (fifo_io_pop_valid               ), //o
    .io_pop_ready            (io_pop_ready                    ), //i
    .io_pop_payload_vpifoId  (fifo_io_pop_payload_vpifoId[2:0]), //o
    .io_pop_payload_flowId   (fifo_io_pop_payload_flowId[4:0] ), //o
    .io_flush                (io_flush                        ), //i
    .io_occupancy            (fifo_io_occupancy[1:0]          ), //o
    .io_availability         (fifo_io_availability[1:0]       ), //o
    .clk                     (clk                             ), //i
    .reset                   (reset                           )  //i
  );
  assign io_push_ready = fifo_io_push_ready;
  assign io_pop_valid = fifo_io_pop_valid;
  assign io_pop_payload_vpifoId = fifo_io_pop_payload_vpifoId;
  assign io_pop_payload_flowId = fifo_io_pop_payload_flowId;
  assign io_occupancy = fifo_io_occupancy;
  assign io_availability = fifo_io_availability;

endmodule

module StreamFifoLowLatency_8 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [7:0]    io_push_payload,
  output wire          io_pop_valid,
  input  wire          io_pop_ready,
  output wire [7:0]    io_pop_payload,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire                fifo_io_push_ready;
  wire                fifo_io_pop_valid;
  wire       [7:0]    fifo_io_pop_payload;
  wire       [1:0]    fifo_io_occupancy;
  wire       [1:0]    fifo_io_availability;

  StreamFifo_9 fifo (
    .io_push_valid   (io_push_valid            ), //i
    .io_push_ready   (fifo_io_push_ready       ), //o
    .io_push_payload (io_push_payload[7:0]     ), //i
    .io_pop_valid    (fifo_io_pop_valid        ), //o
    .io_pop_ready    (io_pop_ready             ), //i
    .io_pop_payload  (fifo_io_pop_payload[7:0] ), //o
    .io_flush        (io_flush                 ), //i
    .io_occupancy    (fifo_io_occupancy[1:0]   ), //o
    .io_availability (fifo_io_availability[1:0]), //o
    .clk             (clk                      ), //i
    .reset           (reset                    )  //i
  );
  assign io_push_ready = fifo_io_push_ready;
  assign io_pop_valid = fifo_io_pop_valid;
  assign io_pop_payload = fifo_io_pop_payload;
  assign io_occupancy = fifo_io_occupancy;
  assign io_availability = fifo_io_availability;

endmodule

//StreamFifoLowLatency_7 replaced by StreamFifoLowLatency_6

module StreamFifoLowLatency_6 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [31:0]   io_push_payload,
  output wire          io_pop_valid,
  input  wire          io_pop_ready,
  output wire [31:0]   io_pop_payload,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire                fifo_io_push_ready;
  wire                fifo_io_pop_valid;
  wire       [31:0]   fifo_io_pop_payload;
  wire       [1:0]    fifo_io_occupancy;
  wire       [1:0]    fifo_io_availability;

  StreamFifo_7 fifo (
    .io_push_valid   (io_push_valid            ), //i
    .io_push_ready   (fifo_io_push_ready       ), //o
    .io_push_payload (io_push_payload[31:0]    ), //i
    .io_pop_valid    (fifo_io_pop_valid        ), //o
    .io_pop_ready    (io_pop_ready             ), //i
    .io_pop_payload  (fifo_io_pop_payload[31:0]), //o
    .io_flush        (io_flush                 ), //i
    .io_occupancy    (fifo_io_occupancy[1:0]   ), //o
    .io_availability (fifo_io_availability[1:0]), //o
    .clk             (clk                      ), //i
    .reset           (reset                    )  //i
  );
  assign io_push_ready = fifo_io_push_ready;
  assign io_pop_valid = fifo_io_pop_valid;
  assign io_pop_payload = fifo_io_pop_payload;
  assign io_occupancy = fifo_io_occupancy;
  assign io_availability = fifo_io_availability;

endmodule

module StreamFifoLowLatency_5 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [1:0]    io_push_payload,
  output wire          io_pop_valid,
  input  wire          io_pop_ready,
  output wire [1:0]    io_pop_payload,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire                fifo_io_push_ready;
  wire                fifo_io_pop_valid;
  wire       [1:0]    fifo_io_pop_payload;
  wire       [1:0]    fifo_io_occupancy;
  wire       [1:0]    fifo_io_availability;

  StreamFifo_6 fifo (
    .io_push_valid   (io_push_valid            ), //i
    .io_push_ready   (fifo_io_push_ready       ), //o
    .io_push_payload (io_push_payload[1:0]     ), //i
    .io_pop_valid    (fifo_io_pop_valid        ), //o
    .io_pop_ready    (io_pop_ready             ), //i
    .io_pop_payload  (fifo_io_pop_payload[1:0] ), //o
    .io_flush        (io_flush                 ), //i
    .io_occupancy    (fifo_io_occupancy[1:0]   ), //o
    .io_availability (fifo_io_availability[1:0]), //o
    .clk             (clk                      ), //i
    .reset           (reset                    )  //i
  );
  assign io_push_ready = fifo_io_push_ready;
  assign io_pop_valid = fifo_io_pop_valid;
  assign io_pop_payload = fifo_io_pop_payload;
  assign io_occupancy = fifo_io_occupancy;
  assign io_availability = fifo_io_availability;

endmodule

module StreamFork_1 (
  input  wire          io_input_valid,
  output reg           io_input_ready,
  input  wire [2:0]    io_input_payload_command,
  input  wire [1:0]    io_input_payload_engineId,
  input  wire [2:0]    io_input_payload_vPifoId,
  input  wire [4:0]    io_input_payload_flowId,
  input  wire [31:0]   io_input_payload_data,
  output wire          io_outputs_0_valid,
  input  wire          io_outputs_0_ready,
  output wire [2:0]    io_outputs_0_payload_command,
  output wire [1:0]    io_outputs_0_payload_engineId,
  output wire [2:0]    io_outputs_0_payload_vPifoId,
  output wire [4:0]    io_outputs_0_payload_flowId,
  output wire [31:0]   io_outputs_0_payload_data,
  output wire          io_outputs_1_valid,
  input  wire          io_outputs_1_ready,
  output wire [2:0]    io_outputs_1_payload_command,
  output wire [1:0]    io_outputs_1_payload_engineId,
  output wire [2:0]    io_outputs_1_payload_vPifoId,
  output wire [4:0]    io_outputs_1_payload_flowId,
  output wire [31:0]   io_outputs_1_payload_data,
  output wire          io_outputs_2_valid,
  input  wire          io_outputs_2_ready,
  output wire [2:0]    io_outputs_2_payload_command,
  output wire [1:0]    io_outputs_2_payload_engineId,
  output wire [2:0]    io_outputs_2_payload_vPifoId,
  output wire [4:0]    io_outputs_2_payload_flowId,
  output wire [31:0]   io_outputs_2_payload_data,
  input  wire          clk,
  input  wire          reset
);
  localparam ControlCommand_UpdateMapperPre = 3'd0;
  localparam ControlCommand_UpdateMapperPost = 3'd1;
  localparam ControlCommand_UpdateMapperNonExist = 3'd2;
  localparam ControlCommand_CommitMapper = 3'd3;
  localparam ControlCommand_UpdateBrainEngine = 3'd4;
  localparam ControlCommand_UpdateBrainState = 3'd5;
  localparam ControlCommand_UpdateBrainFlowState = 3'd6;

  reg                 logic_linkEnable_0;
  reg                 logic_linkEnable_1;
  reg                 logic_linkEnable_2;
  wire                when_Stream_l1253;
  wire                when_Stream_l1253_1;
  wire                when_Stream_l1253_2;
  wire                io_outputs_0_fire;
  wire                io_outputs_1_fire;
  wire                io_outputs_2_fire;
  `ifndef SYNTHESIS
  reg [159:0] io_input_payload_command_string;
  reg [159:0] io_outputs_0_payload_command_string;
  reg [159:0] io_outputs_1_payload_command_string;
  reg [159:0] io_outputs_2_payload_command_string;
  `endif


  `ifndef SYNTHESIS
  always @(*) begin
    case(io_input_payload_command)
      ControlCommand_UpdateMapperPre : io_input_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_input_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_input_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_input_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_input_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_input_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_input_payload_command_string = "UpdateBrainFlowState";
      default : io_input_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_outputs_0_payload_command)
      ControlCommand_UpdateMapperPre : io_outputs_0_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_outputs_0_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_outputs_0_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_outputs_0_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_outputs_0_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_outputs_0_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_outputs_0_payload_command_string = "UpdateBrainFlowState";
      default : io_outputs_0_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_outputs_1_payload_command)
      ControlCommand_UpdateMapperPre : io_outputs_1_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_outputs_1_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_outputs_1_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_outputs_1_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_outputs_1_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_outputs_1_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_outputs_1_payload_command_string = "UpdateBrainFlowState";
      default : io_outputs_1_payload_command_string = "????????????????????";
    endcase
  end
  always @(*) begin
    case(io_outputs_2_payload_command)
      ControlCommand_UpdateMapperPre : io_outputs_2_payload_command_string = "UpdateMapperPre     ";
      ControlCommand_UpdateMapperPost : io_outputs_2_payload_command_string = "UpdateMapperPost    ";
      ControlCommand_UpdateMapperNonExist : io_outputs_2_payload_command_string = "UpdateMapperNonExist";
      ControlCommand_CommitMapper : io_outputs_2_payload_command_string = "CommitMapper        ";
      ControlCommand_UpdateBrainEngine : io_outputs_2_payload_command_string = "UpdateBrainEngine   ";
      ControlCommand_UpdateBrainState : io_outputs_2_payload_command_string = "UpdateBrainState    ";
      ControlCommand_UpdateBrainFlowState : io_outputs_2_payload_command_string = "UpdateBrainFlowState";
      default : io_outputs_2_payload_command_string = "????????????????????";
    endcase
  end
  `endif

  always @(*) begin
    io_input_ready = 1'b1;
    if(when_Stream_l1253) begin
      io_input_ready = 1'b0;
    end
    if(when_Stream_l1253_1) begin
      io_input_ready = 1'b0;
    end
    if(when_Stream_l1253_2) begin
      io_input_ready = 1'b0;
    end
  end

  assign when_Stream_l1253 = ((! io_outputs_0_ready) && logic_linkEnable_0);
  assign when_Stream_l1253_1 = ((! io_outputs_1_ready) && logic_linkEnable_1);
  assign when_Stream_l1253_2 = ((! io_outputs_2_ready) && logic_linkEnable_2);
  assign io_outputs_0_valid = (io_input_valid && logic_linkEnable_0);
  assign io_outputs_0_payload_command = io_input_payload_command;
  assign io_outputs_0_payload_engineId = io_input_payload_engineId;
  assign io_outputs_0_payload_vPifoId = io_input_payload_vPifoId;
  assign io_outputs_0_payload_flowId = io_input_payload_flowId;
  assign io_outputs_0_payload_data = io_input_payload_data;
  assign io_outputs_0_fire = (io_outputs_0_valid && io_outputs_0_ready);
  assign io_outputs_1_valid = (io_input_valid && logic_linkEnable_1);
  assign io_outputs_1_payload_command = io_input_payload_command;
  assign io_outputs_1_payload_engineId = io_input_payload_engineId;
  assign io_outputs_1_payload_vPifoId = io_input_payload_vPifoId;
  assign io_outputs_1_payload_flowId = io_input_payload_flowId;
  assign io_outputs_1_payload_data = io_input_payload_data;
  assign io_outputs_1_fire = (io_outputs_1_valid && io_outputs_1_ready);
  assign io_outputs_2_valid = (io_input_valid && logic_linkEnable_2);
  assign io_outputs_2_payload_command = io_input_payload_command;
  assign io_outputs_2_payload_engineId = io_input_payload_engineId;
  assign io_outputs_2_payload_vPifoId = io_input_payload_vPifoId;
  assign io_outputs_2_payload_flowId = io_input_payload_flowId;
  assign io_outputs_2_payload_data = io_input_payload_data;
  assign io_outputs_2_fire = (io_outputs_2_valid && io_outputs_2_ready);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      logic_linkEnable_0 <= 1'b1;
      logic_linkEnable_1 <= 1'b1;
      logic_linkEnable_2 <= 1'b1;
    end else begin
      if(io_outputs_0_fire) begin
        logic_linkEnable_0 <= 1'b0;
      end
      if(io_outputs_1_fire) begin
        logic_linkEnable_1 <= 1'b0;
      end
      if(io_outputs_2_fire) begin
        logic_linkEnable_2 <= 1'b0;
      end
      if(io_input_ready) begin
        logic_linkEnable_0 <= 1'b1;
        logic_linkEnable_1 <= 1'b1;
        logic_linkEnable_2 <= 1'b1;
      end
    end
  end


endmodule

module StreamArbiter_4 (
  input  wire          io_inputs_0_valid,
  output wire          io_inputs_0_ready,
  input  wire [2:0]    io_inputs_0_payload_inputId,
  input  wire [31:0]   io_inputs_0_payload_outputId,
  input  wire          io_inputs_1_valid,
  output wire          io_inputs_1_ready,
  input  wire [2:0]    io_inputs_1_payload_inputId,
  input  wire [31:0]   io_inputs_1_payload_outputId,
  output wire          io_output_valid,
  input  wire          io_output_ready,
  output wire [2:0]    io_output_payload_inputId,
  output wire [31:0]   io_output_payload_outputId,
  output wire [0:0]    io_chosen,
  output wire [1:0]    io_chosenOH,
  input  wire          clk,
  input  wire          reset
);

  wire       [1:0]    _zz_maskProposal_1_1;
  wire       [1:0]    _zz_maskProposal_1_2;
  reg                 locked;
  wire                maskProposal_0;
  wire                maskProposal_1;
  reg                 maskLocked_0;
  reg                 maskLocked_1;
  wire                maskRouted_0;
  wire                maskRouted_1;
  wire       [1:0]    _zz_maskProposal_1;
  wire                io_output_fire;
  wire                _zz_io_chosen;

  assign _zz_maskProposal_1_1 = (_zz_maskProposal_1 & (~ _zz_maskProposal_1_2));
  assign _zz_maskProposal_1_2 = (_zz_maskProposal_1 - 2'b01);
  assign maskRouted_0 = (locked ? maskLocked_0 : maskProposal_0);
  assign maskRouted_1 = (locked ? maskLocked_1 : maskProposal_1);
  assign _zz_maskProposal_1 = {io_inputs_1_valid,io_inputs_0_valid};
  assign maskProposal_0 = io_inputs_0_valid;
  assign maskProposal_1 = _zz_maskProposal_1_1[1];
  assign io_output_fire = (io_output_valid && io_output_ready);
  assign io_output_valid = ((io_inputs_0_valid && maskRouted_0) || (io_inputs_1_valid && maskRouted_1));
  assign io_output_payload_inputId = (maskRouted_0 ? io_inputs_0_payload_inputId : io_inputs_1_payload_inputId);
  assign io_output_payload_outputId = (maskRouted_0 ? io_inputs_0_payload_outputId : io_inputs_1_payload_outputId);
  assign io_inputs_0_ready = ((1'b0 || maskRouted_0) && io_output_ready);
  assign io_inputs_1_ready = ((1'b0 || maskRouted_1) && io_output_ready);
  assign io_chosenOH = {maskRouted_1,maskRouted_0};
  assign _zz_io_chosen = io_chosenOH[1];
  assign io_chosen = _zz_io_chosen;
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      locked <= 1'b0;
    end else begin
      if(io_output_valid) begin
        locked <= 1'b1;
      end
      if(io_output_fire) begin
        locked <= 1'b0;
      end
    end
  end

  always @(posedge clk) begin
    if(io_output_valid) begin
      maskLocked_0 <= maskRouted_0;
      maskLocked_1 <= maskRouted_1;
    end
  end


endmodule

module StreamFifoLowLatency_4 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [2:0]    io_push_payload_inputId,
  input  wire [31:0]   io_push_payload_outputId,
  output wire          io_pop_valid,
  input  wire          io_pop_ready,
  output wire [2:0]    io_pop_payload_inputId,
  output wire [31:0]   io_pop_payload_outputId,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire                fifo_io_push_ready;
  wire                fifo_io_pop_valid;
  wire       [2:0]    fifo_io_pop_payload_inputId;
  wire       [31:0]   fifo_io_pop_payload_outputId;
  wire       [1:0]    fifo_io_occupancy;
  wire       [1:0]    fifo_io_availability;

  StreamFifo_5 fifo (
    .io_push_valid            (io_push_valid                     ), //i
    .io_push_ready            (fifo_io_push_ready                ), //o
    .io_push_payload_inputId  (io_push_payload_inputId[2:0]      ), //i
    .io_push_payload_outputId (io_push_payload_outputId[31:0]    ), //i
    .io_pop_valid             (fifo_io_pop_valid                 ), //o
    .io_pop_ready             (io_pop_ready                      ), //i
    .io_pop_payload_inputId   (fifo_io_pop_payload_inputId[2:0]  ), //o
    .io_pop_payload_outputId  (fifo_io_pop_payload_outputId[31:0]), //o
    .io_flush                 (io_flush                          ), //i
    .io_occupancy             (fifo_io_occupancy[1:0]            ), //o
    .io_availability          (fifo_io_availability[1:0]         ), //o
    .clk                      (clk                               ), //i
    .reset                    (reset                             )  //i
  );
  assign io_push_ready = fifo_io_push_ready;
  assign io_pop_valid = fifo_io_pop_valid;
  assign io_pop_payload_inputId = fifo_io_pop_payload_inputId;
  assign io_pop_payload_outputId = fifo_io_pop_payload_outputId;
  assign io_occupancy = fifo_io_occupancy;
  assign io_availability = fifo_io_availability;

endmodule

module Mapper_3 (
  input  wire          io_readReq_valid,
  input  wire [2:0]    io_readReq_payload,
  output wire          io_readRes_valid,
  output wire [31:0]   io_readRes_payload,
  input  wire          io_writeReq_valid,
  input  wire [2:0]    io_writeReq_payload_inputId,
  input  wire [31:0]   io_writeReq_payload_outputId,
  input  wire          clk,
  input  wire          reset
);

  reg        [31:0]   ram_spinal_port0;
  wire                _zz_ram_port;
  wire                _zz_io_readRes_payload;
  wire       [31:0]   _zz_ram_port_1;
  reg                 _zz_1;
  reg                 io_readReq_valid_regNext;
  reg [31:0] ram [0:7];

  assign _zz_io_readRes_payload = 1'b1;
  assign _zz_ram_port_1 = io_writeReq_payload_outputId;
  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_0_enque_brain_brainStateMem_ram.bin",ram);
  end
  always @(posedge clk) begin
    if(_zz_io_readRes_payload) begin
      ram_spinal_port0 <= ram[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_1) begin
      ram[io_writeReq_payload_inputId] <= _zz_ram_port_1;
    end
  end

  always @(*) begin
    _zz_1 = 1'b0;
    if(io_writeReq_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign io_readRes_valid = io_readReq_valid_regNext;
  assign io_readRes_payload = ram_spinal_port0;
  always @(posedge clk) begin
    io_readReq_valid_regNext <= io_readReq_valid;
  end


endmodule

module StreamArbiter_3 (
  input  wire          io_inputs_0_valid,
  output wire          io_inputs_0_ready,
  input  wire [7:0]    io_inputs_0_payload_inputId,
  input  wire [31:0]   io_inputs_0_payload_outputId,
  input  wire          io_inputs_1_valid,
  output wire          io_inputs_1_ready,
  input  wire [7:0]    io_inputs_1_payload_inputId,
  input  wire [31:0]   io_inputs_1_payload_outputId,
  output wire          io_output_valid,
  input  wire          io_output_ready,
  output wire [7:0]    io_output_payload_inputId,
  output wire [31:0]   io_output_payload_outputId,
  output wire [0:0]    io_chosen,
  output wire [1:0]    io_chosenOH,
  input  wire          clk,
  input  wire          reset
);

  wire       [1:0]    _zz_maskProposal_1_1;
  wire       [1:0]    _zz_maskProposal_1_2;
  reg                 locked;
  wire                maskProposal_0;
  wire                maskProposal_1;
  reg                 maskLocked_0;
  reg                 maskLocked_1;
  wire                maskRouted_0;
  wire                maskRouted_1;
  wire       [1:0]    _zz_maskProposal_1;
  wire                io_output_fire;
  wire                _zz_io_chosen;

  assign _zz_maskProposal_1_1 = (_zz_maskProposal_1 & (~ _zz_maskProposal_1_2));
  assign _zz_maskProposal_1_2 = (_zz_maskProposal_1 - 2'b01);
  assign maskRouted_0 = (locked ? maskLocked_0 : maskProposal_0);
  assign maskRouted_1 = (locked ? maskLocked_1 : maskProposal_1);
  assign _zz_maskProposal_1 = {io_inputs_1_valid,io_inputs_0_valid};
  assign maskProposal_0 = io_inputs_0_valid;
  assign maskProposal_1 = _zz_maskProposal_1_1[1];
  assign io_output_fire = (io_output_valid && io_output_ready);
  assign io_output_valid = ((io_inputs_0_valid && maskRouted_0) || (io_inputs_1_valid && maskRouted_1));
  assign io_output_payload_inputId = (maskRouted_0 ? io_inputs_0_payload_inputId : io_inputs_1_payload_inputId);
  assign io_output_payload_outputId = (maskRouted_0 ? io_inputs_0_payload_outputId : io_inputs_1_payload_outputId);
  assign io_inputs_0_ready = ((1'b0 || maskRouted_0) && io_output_ready);
  assign io_inputs_1_ready = ((1'b0 || maskRouted_1) && io_output_ready);
  assign io_chosenOH = {maskRouted_1,maskRouted_0};
  assign _zz_io_chosen = io_chosenOH[1];
  assign io_chosen = _zz_io_chosen;
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      locked <= 1'b0;
    end else begin
      if(io_output_valid) begin
        locked <= 1'b1;
      end
      if(io_output_fire) begin
        locked <= 1'b0;
      end
    end
  end

  always @(posedge clk) begin
    if(io_output_valid) begin
      maskLocked_0 <= maskRouted_0;
      maskLocked_1 <= maskRouted_1;
    end
  end


endmodule

module StreamFifoLowLatency_3 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [7:0]    io_push_payload_inputId,
  input  wire [31:0]   io_push_payload_outputId,
  output wire          io_pop_valid,
  input  wire          io_pop_ready,
  output wire [7:0]    io_pop_payload_inputId,
  output wire [31:0]   io_pop_payload_outputId,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire                fifo_io_push_ready;
  wire                fifo_io_pop_valid;
  wire       [7:0]    fifo_io_pop_payload_inputId;
  wire       [31:0]   fifo_io_pop_payload_outputId;
  wire       [1:0]    fifo_io_occupancy;
  wire       [1:0]    fifo_io_availability;

  StreamFifo_4 fifo (
    .io_push_valid            (io_push_valid                     ), //i
    .io_push_ready            (fifo_io_push_ready                ), //o
    .io_push_payload_inputId  (io_push_payload_inputId[7:0]      ), //i
    .io_push_payload_outputId (io_push_payload_outputId[31:0]    ), //i
    .io_pop_valid             (fifo_io_pop_valid                 ), //o
    .io_pop_ready             (io_pop_ready                      ), //i
    .io_pop_payload_inputId   (fifo_io_pop_payload_inputId[7:0]  ), //o
    .io_pop_payload_outputId  (fifo_io_pop_payload_outputId[31:0]), //o
    .io_flush                 (io_flush                          ), //i
    .io_occupancy             (fifo_io_occupancy[1:0]            ), //o
    .io_availability          (fifo_io_availability[1:0]         ), //o
    .clk                      (clk                               ), //i
    .reset                    (reset                             )  //i
  );
  assign io_push_ready = fifo_io_push_ready;
  assign io_pop_valid = fifo_io_pop_valid;
  assign io_pop_payload_inputId = fifo_io_pop_payload_inputId;
  assign io_pop_payload_outputId = fifo_io_pop_payload_outputId;
  assign io_occupancy = fifo_io_occupancy;
  assign io_availability = fifo_io_availability;

endmodule

module Mapper_2 (
  input  wire          io_readReq_valid,
  input  wire [7:0]    io_readReq_payload,
  output wire          io_readRes_valid,
  output wire [31:0]   io_readRes_payload,
  input  wire          io_writeReq_valid,
  input  wire [7:0]    io_writeReq_payload_inputId,
  input  wire [31:0]   io_writeReq_payload_outputId,
  input  wire          clk,
  input  wire          reset
);

  reg        [31:0]   ram_spinal_port0;
  wire                _zz_ram_port;
  wire                _zz_io_readRes_payload;
  wire       [31:0]   _zz_ram_port_1;
  reg                 _zz_1;
  reg                 io_readReq_valid_regNext;
  reg [31:0] ram [0:255];

  assign _zz_io_readRes_payload = 1'b1;
  assign _zz_ram_port_1 = io_writeReq_payload_outputId;
  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_0_enque_brain_engineCAM_ram.bin",ram);
  end
  always @(posedge clk) begin
    if(_zz_io_readRes_payload) begin
      ram_spinal_port0 <= ram[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_1) begin
      ram[io_writeReq_payload_inputId] <= _zz_ram_port_1;
    end
  end

  always @(*) begin
    _zz_1 = 1'b0;
    if(io_writeReq_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign io_readRes_valid = io_readReq_valid_regNext;
  assign io_readRes_payload = ram_spinal_port0;
  always @(posedge clk) begin
    io_readReq_valid_regNext <= io_readReq_valid;
  end


endmodule

module Mapper_1 (
  input  wire          io_readReq_valid,
  input  wire [2:0]    io_readReq_payload,
  output wire          io_readRes_valid,
  output wire [7:0]    io_readRes_payload,
  input  wire          io_writeReq_valid,
  input  wire [2:0]    io_writeReq_payload_inputId,
  input  wire [7:0]    io_writeReq_payload_outputId,
  input  wire          clk,
  input  wire          reset
);

  reg        [7:0]    ram_spinal_port0;
  wire                _zz_ram_port;
  wire                _zz_io_readRes_payload;
  wire       [7:0]    _zz_ram_port_1;
  reg                 _zz_1;
  reg                 io_readReq_valid_regNext;
  reg [7:0] ram [0:7];

  assign _zz_io_readRes_payload = 1'b1;
  assign _zz_ram_port_1 = io_writeReq_payload_outputId;
  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_0_enque_brain_lastVirtualMapper_ram.bin",ram);
  end
  always @(posedge clk) begin
    if(_zz_io_readRes_payload) begin
      ram_spinal_port0 <= ram[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_1) begin
      ram[io_writeReq_payload_inputId] <= _zz_ram_port_1;
    end
  end

  always @(*) begin
    _zz_1 = 1'b0;
    if(io_writeReq_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign io_readRes_valid = io_readReq_valid_regNext;
  assign io_readRes_payload = ram_spinal_port0;
  always @(posedge clk) begin
    io_readReq_valid_regNext <= io_readReq_valid;
  end


endmodule

module Mapper (
  input  wire          io_readReq_valid,
  input  wire [2:0]    io_readReq_payload,
  output wire          io_readRes_valid,
  output wire [1:0]    io_readRes_payload,
  input  wire          io_writeReq_valid,
  input  wire [2:0]    io_writeReq_payload_inputId,
  input  wire [1:0]    io_writeReq_payload_outputId,
  input  wire          clk,
  input  wire          reset
);

  reg        [1:0]    ram_spinal_port0;
  wire                _zz_ram_port;
  wire                _zz_io_readRes_payload;
  wire       [1:0]    _zz_ram_port_1;
  reg                 _zz_1;
  reg                 io_readReq_valid_regNext;
  reg [1:0] ram [0:7];

  assign _zz_io_readRes_payload = 1'b1;
  assign _zz_ram_port_1 = io_writeReq_payload_outputId;
  initial begin
    $readmemb("PifoMesh.v_toplevel_pifoEngines_0_enque_brain_engineMapper_ram.bin",ram);
  end
  always @(posedge clk) begin
    if(_zz_io_readRes_payload) begin
      ram_spinal_port0 <= ram[io_readReq_payload];
    end
  end

  always @(posedge clk) begin
    if(_zz_1) begin
      ram[io_writeReq_payload_inputId] <= _zz_ram_port_1;
    end
  end

  always @(*) begin
    _zz_1 = 1'b0;
    if(io_writeReq_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign io_readRes_valid = io_readReq_valid_regNext;
  assign io_readRes_payload = ram_spinal_port0;
  always @(posedge clk) begin
    io_readReq_valid_regNext <= io_readReq_valid;
  end


endmodule

module StreamFork (
  input  wire          io_input_valid,
  output reg           io_input_ready,
  input  wire [2:0]    io_input_payload_vpifoId,
  input  wire [4:0]    io_input_payload_flowId,
  output wire          io_outputs_0_valid,
  input  wire          io_outputs_0_ready,
  output wire [2:0]    io_outputs_0_payload_vpifoId,
  output wire [4:0]    io_outputs_0_payload_flowId,
  output wire          io_outputs_1_valid,
  input  wire          io_outputs_1_ready,
  output wire [2:0]    io_outputs_1_payload_vpifoId,
  output wire [4:0]    io_outputs_1_payload_flowId,
  output wire          io_outputs_2_valid,
  input  wire          io_outputs_2_ready,
  output wire [2:0]    io_outputs_2_payload_vpifoId,
  output wire [4:0]    io_outputs_2_payload_flowId,
  output wire          io_outputs_3_valid,
  input  wire          io_outputs_3_ready,
  output wire [2:0]    io_outputs_3_payload_vpifoId,
  output wire [4:0]    io_outputs_3_payload_flowId,
  output wire          io_outputs_4_valid,
  input  wire          io_outputs_4_ready,
  output wire [2:0]    io_outputs_4_payload_vpifoId,
  output wire [4:0]    io_outputs_4_payload_flowId,
  input  wire          clk,
  input  wire          reset
);

  reg                 logic_linkEnable_0;
  reg                 logic_linkEnable_1;
  reg                 logic_linkEnable_2;
  reg                 logic_linkEnable_3;
  reg                 logic_linkEnable_4;
  wire                when_Stream_l1253;
  wire                when_Stream_l1253_1;
  wire                when_Stream_l1253_2;
  wire                when_Stream_l1253_3;
  wire                when_Stream_l1253_4;
  wire                io_outputs_0_fire;
  wire                io_outputs_1_fire;
  wire                io_outputs_2_fire;
  wire                io_outputs_3_fire;
  wire                io_outputs_4_fire;

  always @(*) begin
    io_input_ready = 1'b1;
    if(when_Stream_l1253) begin
      io_input_ready = 1'b0;
    end
    if(when_Stream_l1253_1) begin
      io_input_ready = 1'b0;
    end
    if(when_Stream_l1253_2) begin
      io_input_ready = 1'b0;
    end
    if(when_Stream_l1253_3) begin
      io_input_ready = 1'b0;
    end
    if(when_Stream_l1253_4) begin
      io_input_ready = 1'b0;
    end
  end

  assign when_Stream_l1253 = ((! io_outputs_0_ready) && logic_linkEnable_0);
  assign when_Stream_l1253_1 = ((! io_outputs_1_ready) && logic_linkEnable_1);
  assign when_Stream_l1253_2 = ((! io_outputs_2_ready) && logic_linkEnable_2);
  assign when_Stream_l1253_3 = ((! io_outputs_3_ready) && logic_linkEnable_3);
  assign when_Stream_l1253_4 = ((! io_outputs_4_ready) && logic_linkEnable_4);
  assign io_outputs_0_valid = (io_input_valid && logic_linkEnable_0);
  assign io_outputs_0_payload_vpifoId = io_input_payload_vpifoId;
  assign io_outputs_0_payload_flowId = io_input_payload_flowId;
  assign io_outputs_0_fire = (io_outputs_0_valid && io_outputs_0_ready);
  assign io_outputs_1_valid = (io_input_valid && logic_linkEnable_1);
  assign io_outputs_1_payload_vpifoId = io_input_payload_vpifoId;
  assign io_outputs_1_payload_flowId = io_input_payload_flowId;
  assign io_outputs_1_fire = (io_outputs_1_valid && io_outputs_1_ready);
  assign io_outputs_2_valid = (io_input_valid && logic_linkEnable_2);
  assign io_outputs_2_payload_vpifoId = io_input_payload_vpifoId;
  assign io_outputs_2_payload_flowId = io_input_payload_flowId;
  assign io_outputs_2_fire = (io_outputs_2_valid && io_outputs_2_ready);
  assign io_outputs_3_valid = (io_input_valid && logic_linkEnable_3);
  assign io_outputs_3_payload_vpifoId = io_input_payload_vpifoId;
  assign io_outputs_3_payload_flowId = io_input_payload_flowId;
  assign io_outputs_3_fire = (io_outputs_3_valid && io_outputs_3_ready);
  assign io_outputs_4_valid = (io_input_valid && logic_linkEnable_4);
  assign io_outputs_4_payload_vpifoId = io_input_payload_vpifoId;
  assign io_outputs_4_payload_flowId = io_input_payload_flowId;
  assign io_outputs_4_fire = (io_outputs_4_valid && io_outputs_4_ready);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      logic_linkEnable_0 <= 1'b1;
      logic_linkEnable_1 <= 1'b1;
      logic_linkEnable_2 <= 1'b1;
      logic_linkEnable_3 <= 1'b1;
      logic_linkEnable_4 <= 1'b1;
    end else begin
      if(io_outputs_0_fire) begin
        logic_linkEnable_0 <= 1'b0;
      end
      if(io_outputs_1_fire) begin
        logic_linkEnable_1 <= 1'b0;
      end
      if(io_outputs_2_fire) begin
        logic_linkEnable_2 <= 1'b0;
      end
      if(io_outputs_3_fire) begin
        logic_linkEnable_3 <= 1'b0;
      end
      if(io_outputs_4_fire) begin
        logic_linkEnable_4 <= 1'b0;
      end
      if(io_input_ready) begin
        logic_linkEnable_0 <= 1'b1;
        logic_linkEnable_1 <= 1'b1;
        logic_linkEnable_2 <= 1'b1;
        logic_linkEnable_3 <= 1'b1;
        logic_linkEnable_4 <= 1'b1;
      end
    end
  end


endmodule

module StreamFifo_3 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [1:0]    io_push_payload_engineId,
  input  wire [2:0]    io_push_payload_vPifoId,
  output reg           io_pop_valid,
  input  wire          io_pop_ready,
  output reg  [1:0]    io_pop_payload_engineId,
  output reg  [2:0]    io_pop_payload_vPifoId,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire       [4:0]    logic_ram_spinal_port1;
  wire       [4:0]    _zz_logic_ram_port;
  reg                 _zz_1;
  reg                 logic_ptr_doPush;
  wire                logic_ptr_doPop;
  wire                logic_ptr_full;
  wire                logic_ptr_empty;
  reg        [1:0]    logic_ptr_push;
  reg        [1:0]    logic_ptr_pop;
  wire       [1:0]    logic_ptr_occupancy;
  wire       [1:0]    logic_ptr_popOnIo;
  wire                when_Stream_l1455;
  reg                 logic_ptr_wentUp;
  wire                io_push_fire;
  wire                logic_push_onRam_write_valid;
  wire       [0:0]    logic_push_onRam_write_payload_address;
  wire       [1:0]    logic_push_onRam_write_payload_data_engineId;
  wire       [2:0]    logic_push_onRam_write_payload_data_vPifoId;
  wire                logic_pop_addressGen_valid;
  wire                logic_pop_addressGen_ready;
  wire       [0:0]    logic_pop_addressGen_payload;
  wire                logic_pop_addressGen_fire;
  wire       [1:0]    logic_pop_async_readed_engineId;
  wire       [2:0]    logic_pop_async_readed_vPifoId;
  wire       [4:0]    _zz_logic_pop_async_readed_engineId;
  wire                logic_pop_addressGen_translated_valid;
  wire                logic_pop_addressGen_translated_ready;
  wire       [1:0]    logic_pop_addressGen_translated_payload_engineId;
  wire       [2:0]    logic_pop_addressGen_translated_payload_vPifoId;
  (* ram_style = "distributed" *) reg [4:0] logic_ram [0:1];

  assign _zz_logic_ram_port = {logic_push_onRam_write_payload_data_vPifoId,logic_push_onRam_write_payload_data_engineId};
  always @(posedge clk) begin
    if(_zz_1) begin
      logic_ram[logic_push_onRam_write_payload_address] <= _zz_logic_ram_port;
    end
  end

  assign logic_ram_spinal_port1 = logic_ram[logic_pop_addressGen_payload];
  always @(*) begin
    _zz_1 = 1'b0;
    if(logic_push_onRam_write_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign when_Stream_l1455 = (logic_ptr_doPush != logic_ptr_doPop);
  assign logic_ptr_full = (((logic_ptr_push ^ logic_ptr_popOnIo) ^ 2'b10) == 2'b00);
  assign logic_ptr_empty = (logic_ptr_push == logic_ptr_pop);
  assign logic_ptr_occupancy = (logic_ptr_push - logic_ptr_popOnIo);
  assign io_push_ready = (! logic_ptr_full);
  assign io_push_fire = (io_push_valid && io_push_ready);
  always @(*) begin
    logic_ptr_doPush = io_push_fire;
    if(logic_ptr_empty) begin
      if(io_pop_ready) begin
        logic_ptr_doPush = 1'b0;
      end
    end
  end

  assign logic_push_onRam_write_valid = io_push_fire;
  assign logic_push_onRam_write_payload_address = logic_ptr_push[0:0];
  assign logic_push_onRam_write_payload_data_engineId = io_push_payload_engineId;
  assign logic_push_onRam_write_payload_data_vPifoId = io_push_payload_vPifoId;
  assign logic_pop_addressGen_valid = (! logic_ptr_empty);
  assign logic_pop_addressGen_payload = logic_ptr_pop[0:0];
  assign logic_pop_addressGen_fire = (logic_pop_addressGen_valid && logic_pop_addressGen_ready);
  assign logic_ptr_doPop = logic_pop_addressGen_fire;
  assign _zz_logic_pop_async_readed_engineId = logic_ram_spinal_port1;
  assign logic_pop_async_readed_engineId = _zz_logic_pop_async_readed_engineId[1 : 0];
  assign logic_pop_async_readed_vPifoId = _zz_logic_pop_async_readed_engineId[4 : 2];
  assign logic_pop_addressGen_translated_valid = logic_pop_addressGen_valid;
  assign logic_pop_addressGen_ready = logic_pop_addressGen_translated_ready;
  assign logic_pop_addressGen_translated_payload_engineId = logic_pop_async_readed_engineId;
  assign logic_pop_addressGen_translated_payload_vPifoId = logic_pop_async_readed_vPifoId;
  always @(*) begin
    io_pop_valid = logic_pop_addressGen_translated_valid;
    if(logic_ptr_empty) begin
      io_pop_valid = io_push_valid;
    end
  end

  assign logic_pop_addressGen_translated_ready = io_pop_ready;
  always @(*) begin
    io_pop_payload_engineId = logic_pop_addressGen_translated_payload_engineId;
    if(logic_ptr_empty) begin
      io_pop_payload_engineId = io_push_payload_engineId;
    end
  end

  always @(*) begin
    io_pop_payload_vPifoId = logic_pop_addressGen_translated_payload_vPifoId;
    if(logic_ptr_empty) begin
      io_pop_payload_vPifoId = io_push_payload_vPifoId;
    end
  end

  assign logic_ptr_popOnIo = logic_ptr_pop;
  assign io_occupancy = logic_ptr_occupancy;
  assign io_availability = (2'b10 - logic_ptr_occupancy);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      logic_ptr_push <= 2'b00;
      logic_ptr_pop <= 2'b00;
      logic_ptr_wentUp <= 1'b0;
    end else begin
      if(when_Stream_l1455) begin
        logic_ptr_wentUp <= logic_ptr_doPush;
      end
      if(io_flush) begin
        logic_ptr_wentUp <= 1'b0;
      end
      if(logic_ptr_doPush) begin
        logic_ptr_push <= (logic_ptr_push + 2'b01);
      end
      if(logic_ptr_doPop) begin
        logic_ptr_pop <= (logic_ptr_pop + 2'b01);
      end
      if(io_flush) begin
        logic_ptr_push <= 2'b00;
        logic_ptr_pop <= 2'b00;
      end
    end
  end


endmodule

//StreamFifo_2 replaced by StreamFifo

//StreamFifo_1 replaced by StreamFifo

module StreamFifo (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [1:0]    io_push_payload_engineId,
  input  wire [2:0]    io_push_payload_vPifoId,
  output wire          io_pop_valid,
  input  wire          io_pop_ready,
  output wire [1:0]    io_pop_payload_engineId,
  output wire [2:0]    io_pop_payload_vPifoId,
  input  wire          io_flush,
  output wire [3:0]    io_occupancy,
  output wire [3:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire       [4:0]    logic_ram_spinal_port1;
  wire       [4:0]    _zz_logic_ram_port;
  reg                 _zz_1;
  wire                logic_ptr_doPush;
  wire                logic_ptr_doPop;
  wire                logic_ptr_full;
  wire                logic_ptr_empty;
  reg        [3:0]    logic_ptr_push;
  reg        [3:0]    logic_ptr_pop;
  wire       [3:0]    logic_ptr_occupancy;
  wire       [3:0]    logic_ptr_popOnIo;
  wire                when_Stream_l1455;
  reg                 logic_ptr_wentUp;
  wire                io_push_fire;
  wire                logic_push_onRam_write_valid;
  wire       [2:0]    logic_push_onRam_write_payload_address;
  wire       [1:0]    logic_push_onRam_write_payload_data_engineId;
  wire       [2:0]    logic_push_onRam_write_payload_data_vPifoId;
  wire                logic_pop_addressGen_valid;
  wire                logic_pop_addressGen_ready;
  wire       [2:0]    logic_pop_addressGen_payload;
  wire                logic_pop_addressGen_fire;
  wire       [1:0]    logic_pop_async_readed_engineId;
  wire       [2:0]    logic_pop_async_readed_vPifoId;
  wire       [4:0]    _zz_logic_pop_async_readed_engineId;
  wire                logic_pop_addressGen_translated_valid;
  wire                logic_pop_addressGen_translated_ready;
  wire       [1:0]    logic_pop_addressGen_translated_payload_engineId;
  wire       [2:0]    logic_pop_addressGen_translated_payload_vPifoId;
  (* ram_style = "distributed" *) reg [4:0] logic_ram [0:7];

  assign _zz_logic_ram_port = {logic_push_onRam_write_payload_data_vPifoId,logic_push_onRam_write_payload_data_engineId};
  always @(posedge clk) begin
    if(_zz_1) begin
      logic_ram[logic_push_onRam_write_payload_address] <= _zz_logic_ram_port;
    end
  end

  assign logic_ram_spinal_port1 = logic_ram[logic_pop_addressGen_payload];
  always @(*) begin
    _zz_1 = 1'b0;
    if(logic_push_onRam_write_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign when_Stream_l1455 = (logic_ptr_doPush != logic_ptr_doPop);
  assign logic_ptr_full = (((logic_ptr_push ^ logic_ptr_popOnIo) ^ 4'b1000) == 4'b0000);
  assign logic_ptr_empty = (logic_ptr_push == logic_ptr_pop);
  assign logic_ptr_occupancy = (logic_ptr_push - logic_ptr_popOnIo);
  assign io_push_ready = (! logic_ptr_full);
  assign io_push_fire = (io_push_valid && io_push_ready);
  assign logic_ptr_doPush = io_push_fire;
  assign logic_push_onRam_write_valid = io_push_fire;
  assign logic_push_onRam_write_payload_address = logic_ptr_push[2:0];
  assign logic_push_onRam_write_payload_data_engineId = io_push_payload_engineId;
  assign logic_push_onRam_write_payload_data_vPifoId = io_push_payload_vPifoId;
  assign logic_pop_addressGen_valid = (! logic_ptr_empty);
  assign logic_pop_addressGen_payload = logic_ptr_pop[2:0];
  assign logic_pop_addressGen_fire = (logic_pop_addressGen_valid && logic_pop_addressGen_ready);
  assign logic_ptr_doPop = logic_pop_addressGen_fire;
  assign _zz_logic_pop_async_readed_engineId = logic_ram_spinal_port1;
  assign logic_pop_async_readed_engineId = _zz_logic_pop_async_readed_engineId[1 : 0];
  assign logic_pop_async_readed_vPifoId = _zz_logic_pop_async_readed_engineId[4 : 2];
  assign logic_pop_addressGen_translated_valid = logic_pop_addressGen_valid;
  assign logic_pop_addressGen_ready = logic_pop_addressGen_translated_ready;
  assign logic_pop_addressGen_translated_payload_engineId = logic_pop_async_readed_engineId;
  assign logic_pop_addressGen_translated_payload_vPifoId = logic_pop_async_readed_vPifoId;
  assign io_pop_valid = logic_pop_addressGen_translated_valid;
  assign logic_pop_addressGen_translated_ready = io_pop_ready;
  assign io_pop_payload_engineId = logic_pop_addressGen_translated_payload_engineId;
  assign io_pop_payload_vPifoId = logic_pop_addressGen_translated_payload_vPifoId;
  assign logic_ptr_popOnIo = logic_ptr_pop;
  assign io_occupancy = logic_ptr_occupancy;
  assign io_availability = (4'b1000 - logic_ptr_occupancy);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      logic_ptr_push <= 4'b0000;
      logic_ptr_pop <= 4'b0000;
      logic_ptr_wentUp <= 1'b0;
    end else begin
      if(when_Stream_l1455) begin
        logic_ptr_wentUp <= logic_ptr_doPush;
      end
      if(io_flush) begin
        logic_ptr_wentUp <= 1'b0;
      end
      if(logic_ptr_doPush) begin
        logic_ptr_push <= (logic_ptr_push + 4'b0001);
      end
      if(logic_ptr_doPop) begin
        logic_ptr_pop <= (logic_ptr_pop + 4'b0001);
      end
      if(io_flush) begin
        logic_ptr_push <= 4'b0000;
        logic_ptr_pop <= 4'b0000;
      end
    end
  end


endmodule

//StreamFifo_19 replaced by StreamFifo_10

//StreamFifo_18 replaced by StreamFifo_9

//StreamFifo_17 replaced by StreamFifo_7

//StreamFifo_16 replaced by StreamFifo_7

//StreamFifo_15 replaced by StreamFifo_6

//StreamFifo_14 replaced by StreamFifo_5

//StreamFifo_13 replaced by StreamFifo_4

module StreamFifo_10 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [2:0]    io_push_payload_vpifoId,
  input  wire [4:0]    io_push_payload_flowId,
  output reg           io_pop_valid,
  input  wire          io_pop_ready,
  output reg  [2:0]    io_pop_payload_vpifoId,
  output reg  [4:0]    io_pop_payload_flowId,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire       [7:0]    logic_ram_spinal_port1;
  wire       [7:0]    _zz_logic_ram_port;
  reg                 _zz_1;
  reg                 logic_ptr_doPush;
  wire                logic_ptr_doPop;
  wire                logic_ptr_full;
  wire                logic_ptr_empty;
  reg        [1:0]    logic_ptr_push;
  reg        [1:0]    logic_ptr_pop;
  wire       [1:0]    logic_ptr_occupancy;
  wire       [1:0]    logic_ptr_popOnIo;
  wire                when_Stream_l1455;
  reg                 logic_ptr_wentUp;
  wire                io_push_fire;
  wire                logic_push_onRam_write_valid;
  wire       [0:0]    logic_push_onRam_write_payload_address;
  wire       [2:0]    logic_push_onRam_write_payload_data_vpifoId;
  wire       [4:0]    logic_push_onRam_write_payload_data_flowId;
  wire                logic_pop_addressGen_valid;
  wire                logic_pop_addressGen_ready;
  wire       [0:0]    logic_pop_addressGen_payload;
  wire                logic_pop_addressGen_fire;
  wire       [2:0]    logic_pop_async_readed_vpifoId;
  wire       [4:0]    logic_pop_async_readed_flowId;
  wire       [7:0]    _zz_logic_pop_async_readed_vpifoId;
  wire                logic_pop_addressGen_translated_valid;
  wire                logic_pop_addressGen_translated_ready;
  wire       [2:0]    logic_pop_addressGen_translated_payload_vpifoId;
  wire       [4:0]    logic_pop_addressGen_translated_payload_flowId;
  (* ram_style = "distributed" *) reg [7:0] logic_ram [0:1];

  assign _zz_logic_ram_port = {logic_push_onRam_write_payload_data_flowId,logic_push_onRam_write_payload_data_vpifoId};
  always @(posedge clk) begin
    if(_zz_1) begin
      logic_ram[logic_push_onRam_write_payload_address] <= _zz_logic_ram_port;
    end
  end

  assign logic_ram_spinal_port1 = logic_ram[logic_pop_addressGen_payload];
  always @(*) begin
    _zz_1 = 1'b0;
    if(logic_push_onRam_write_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign when_Stream_l1455 = (logic_ptr_doPush != logic_ptr_doPop);
  assign logic_ptr_full = (((logic_ptr_push ^ logic_ptr_popOnIo) ^ 2'b10) == 2'b00);
  assign logic_ptr_empty = (logic_ptr_push == logic_ptr_pop);
  assign logic_ptr_occupancy = (logic_ptr_push - logic_ptr_popOnIo);
  assign io_push_ready = (! logic_ptr_full);
  assign io_push_fire = (io_push_valid && io_push_ready);
  always @(*) begin
    logic_ptr_doPush = io_push_fire;
    if(logic_ptr_empty) begin
      if(io_pop_ready) begin
        logic_ptr_doPush = 1'b0;
      end
    end
  end

  assign logic_push_onRam_write_valid = io_push_fire;
  assign logic_push_onRam_write_payload_address = logic_ptr_push[0:0];
  assign logic_push_onRam_write_payload_data_vpifoId = io_push_payload_vpifoId;
  assign logic_push_onRam_write_payload_data_flowId = io_push_payload_flowId;
  assign logic_pop_addressGen_valid = (! logic_ptr_empty);
  assign logic_pop_addressGen_payload = logic_ptr_pop[0:0];
  assign logic_pop_addressGen_fire = (logic_pop_addressGen_valid && logic_pop_addressGen_ready);
  assign logic_ptr_doPop = logic_pop_addressGen_fire;
  assign _zz_logic_pop_async_readed_vpifoId = logic_ram_spinal_port1;
  assign logic_pop_async_readed_vpifoId = _zz_logic_pop_async_readed_vpifoId[2 : 0];
  assign logic_pop_async_readed_flowId = _zz_logic_pop_async_readed_vpifoId[7 : 3];
  assign logic_pop_addressGen_translated_valid = logic_pop_addressGen_valid;
  assign logic_pop_addressGen_ready = logic_pop_addressGen_translated_ready;
  assign logic_pop_addressGen_translated_payload_vpifoId = logic_pop_async_readed_vpifoId;
  assign logic_pop_addressGen_translated_payload_flowId = logic_pop_async_readed_flowId;
  always @(*) begin
    io_pop_valid = logic_pop_addressGen_translated_valid;
    if(logic_ptr_empty) begin
      io_pop_valid = io_push_valid;
    end
  end

  assign logic_pop_addressGen_translated_ready = io_pop_ready;
  always @(*) begin
    io_pop_payload_vpifoId = logic_pop_addressGen_translated_payload_vpifoId;
    if(logic_ptr_empty) begin
      io_pop_payload_vpifoId = io_push_payload_vpifoId;
    end
  end

  always @(*) begin
    io_pop_payload_flowId = logic_pop_addressGen_translated_payload_flowId;
    if(logic_ptr_empty) begin
      io_pop_payload_flowId = io_push_payload_flowId;
    end
  end

  assign logic_ptr_popOnIo = logic_ptr_pop;
  assign io_occupancy = logic_ptr_occupancy;
  assign io_availability = (2'b10 - logic_ptr_occupancy);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      logic_ptr_push <= 2'b00;
      logic_ptr_pop <= 2'b00;
      logic_ptr_wentUp <= 1'b0;
    end else begin
      if(when_Stream_l1455) begin
        logic_ptr_wentUp <= logic_ptr_doPush;
      end
      if(io_flush) begin
        logic_ptr_wentUp <= 1'b0;
      end
      if(logic_ptr_doPush) begin
        logic_ptr_push <= (logic_ptr_push + 2'b01);
      end
      if(logic_ptr_doPop) begin
        logic_ptr_pop <= (logic_ptr_pop + 2'b01);
      end
      if(io_flush) begin
        logic_ptr_push <= 2'b00;
        logic_ptr_pop <= 2'b00;
      end
    end
  end


endmodule

module StreamFifo_9 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [7:0]    io_push_payload,
  output reg           io_pop_valid,
  input  wire          io_pop_ready,
  output reg  [7:0]    io_pop_payload,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire       [7:0]    logic_ram_spinal_port1;
  wire       [7:0]    _zz_logic_ram_port;
  reg                 _zz_1;
  reg                 logic_ptr_doPush;
  wire                logic_ptr_doPop;
  wire                logic_ptr_full;
  wire                logic_ptr_empty;
  reg        [1:0]    logic_ptr_push;
  reg        [1:0]    logic_ptr_pop;
  wire       [1:0]    logic_ptr_occupancy;
  wire       [1:0]    logic_ptr_popOnIo;
  wire                when_Stream_l1455;
  reg                 logic_ptr_wentUp;
  wire                io_push_fire;
  wire                logic_push_onRam_write_valid;
  wire       [0:0]    logic_push_onRam_write_payload_address;
  wire       [7:0]    logic_push_onRam_write_payload_data;
  wire                logic_pop_addressGen_valid;
  wire                logic_pop_addressGen_ready;
  wire       [0:0]    logic_pop_addressGen_payload;
  wire                logic_pop_addressGen_fire;
  wire       [7:0]    logic_pop_async_readed;
  wire                logic_pop_addressGen_translated_valid;
  wire                logic_pop_addressGen_translated_ready;
  wire       [7:0]    logic_pop_addressGen_translated_payload;
  (* ram_style = "distributed" *) reg [7:0] logic_ram [0:1];

  assign _zz_logic_ram_port = logic_push_onRam_write_payload_data;
  always @(posedge clk) begin
    if(_zz_1) begin
      logic_ram[logic_push_onRam_write_payload_address] <= _zz_logic_ram_port;
    end
  end

  assign logic_ram_spinal_port1 = logic_ram[logic_pop_addressGen_payload];
  always @(*) begin
    _zz_1 = 1'b0;
    if(logic_push_onRam_write_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign when_Stream_l1455 = (logic_ptr_doPush != logic_ptr_doPop);
  assign logic_ptr_full = (((logic_ptr_push ^ logic_ptr_popOnIo) ^ 2'b10) == 2'b00);
  assign logic_ptr_empty = (logic_ptr_push == logic_ptr_pop);
  assign logic_ptr_occupancy = (logic_ptr_push - logic_ptr_popOnIo);
  assign io_push_ready = (! logic_ptr_full);
  assign io_push_fire = (io_push_valid && io_push_ready);
  always @(*) begin
    logic_ptr_doPush = io_push_fire;
    if(logic_ptr_empty) begin
      if(io_pop_ready) begin
        logic_ptr_doPush = 1'b0;
      end
    end
  end

  assign logic_push_onRam_write_valid = io_push_fire;
  assign logic_push_onRam_write_payload_address = logic_ptr_push[0:0];
  assign logic_push_onRam_write_payload_data = io_push_payload;
  assign logic_pop_addressGen_valid = (! logic_ptr_empty);
  assign logic_pop_addressGen_payload = logic_ptr_pop[0:0];
  assign logic_pop_addressGen_fire = (logic_pop_addressGen_valid && logic_pop_addressGen_ready);
  assign logic_ptr_doPop = logic_pop_addressGen_fire;
  assign logic_pop_async_readed = logic_ram_spinal_port1;
  assign logic_pop_addressGen_translated_valid = logic_pop_addressGen_valid;
  assign logic_pop_addressGen_ready = logic_pop_addressGen_translated_ready;
  assign logic_pop_addressGen_translated_payload = logic_pop_async_readed;
  always @(*) begin
    io_pop_valid = logic_pop_addressGen_translated_valid;
    if(logic_ptr_empty) begin
      io_pop_valid = io_push_valid;
    end
  end

  assign logic_pop_addressGen_translated_ready = io_pop_ready;
  always @(*) begin
    io_pop_payload = logic_pop_addressGen_translated_payload;
    if(logic_ptr_empty) begin
      io_pop_payload = io_push_payload;
    end
  end

  assign logic_ptr_popOnIo = logic_ptr_pop;
  assign io_occupancy = logic_ptr_occupancy;
  assign io_availability = (2'b10 - logic_ptr_occupancy);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      logic_ptr_push <= 2'b00;
      logic_ptr_pop <= 2'b00;
      logic_ptr_wentUp <= 1'b0;
    end else begin
      if(when_Stream_l1455) begin
        logic_ptr_wentUp <= logic_ptr_doPush;
      end
      if(io_flush) begin
        logic_ptr_wentUp <= 1'b0;
      end
      if(logic_ptr_doPush) begin
        logic_ptr_push <= (logic_ptr_push + 2'b01);
      end
      if(logic_ptr_doPop) begin
        logic_ptr_pop <= (logic_ptr_pop + 2'b01);
      end
      if(io_flush) begin
        logic_ptr_push <= 2'b00;
        logic_ptr_pop <= 2'b00;
      end
    end
  end


endmodule

//StreamFifo_8 replaced by StreamFifo_7

module StreamFifo_7 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [31:0]   io_push_payload,
  output reg           io_pop_valid,
  input  wire          io_pop_ready,
  output reg  [31:0]   io_pop_payload,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire       [31:0]   logic_ram_spinal_port1;
  wire       [31:0]   _zz_logic_ram_port;
  reg                 _zz_1;
  reg                 logic_ptr_doPush;
  wire                logic_ptr_doPop;
  wire                logic_ptr_full;
  wire                logic_ptr_empty;
  reg        [1:0]    logic_ptr_push;
  reg        [1:0]    logic_ptr_pop;
  wire       [1:0]    logic_ptr_occupancy;
  wire       [1:0]    logic_ptr_popOnIo;
  wire                when_Stream_l1455;
  reg                 logic_ptr_wentUp;
  wire                io_push_fire;
  wire                logic_push_onRam_write_valid;
  wire       [0:0]    logic_push_onRam_write_payload_address;
  wire       [31:0]   logic_push_onRam_write_payload_data;
  wire                logic_pop_addressGen_valid;
  wire                logic_pop_addressGen_ready;
  wire       [0:0]    logic_pop_addressGen_payload;
  wire                logic_pop_addressGen_fire;
  wire       [31:0]   logic_pop_async_readed;
  wire                logic_pop_addressGen_translated_valid;
  wire                logic_pop_addressGen_translated_ready;
  wire       [31:0]   logic_pop_addressGen_translated_payload;
  (* ram_style = "distributed" *) reg [31:0] logic_ram [0:1];

  assign _zz_logic_ram_port = logic_push_onRam_write_payload_data;
  always @(posedge clk) begin
    if(_zz_1) begin
      logic_ram[logic_push_onRam_write_payload_address] <= _zz_logic_ram_port;
    end
  end

  assign logic_ram_spinal_port1 = logic_ram[logic_pop_addressGen_payload];
  always @(*) begin
    _zz_1 = 1'b0;
    if(logic_push_onRam_write_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign when_Stream_l1455 = (logic_ptr_doPush != logic_ptr_doPop);
  assign logic_ptr_full = (((logic_ptr_push ^ logic_ptr_popOnIo) ^ 2'b10) == 2'b00);
  assign logic_ptr_empty = (logic_ptr_push == logic_ptr_pop);
  assign logic_ptr_occupancy = (logic_ptr_push - logic_ptr_popOnIo);
  assign io_push_ready = (! logic_ptr_full);
  assign io_push_fire = (io_push_valid && io_push_ready);
  always @(*) begin
    logic_ptr_doPush = io_push_fire;
    if(logic_ptr_empty) begin
      if(io_pop_ready) begin
        logic_ptr_doPush = 1'b0;
      end
    end
  end

  assign logic_push_onRam_write_valid = io_push_fire;
  assign logic_push_onRam_write_payload_address = logic_ptr_push[0:0];
  assign logic_push_onRam_write_payload_data = io_push_payload;
  assign logic_pop_addressGen_valid = (! logic_ptr_empty);
  assign logic_pop_addressGen_payload = logic_ptr_pop[0:0];
  assign logic_pop_addressGen_fire = (logic_pop_addressGen_valid && logic_pop_addressGen_ready);
  assign logic_ptr_doPop = logic_pop_addressGen_fire;
  assign logic_pop_async_readed = logic_ram_spinal_port1;
  assign logic_pop_addressGen_translated_valid = logic_pop_addressGen_valid;
  assign logic_pop_addressGen_ready = logic_pop_addressGen_translated_ready;
  assign logic_pop_addressGen_translated_payload = logic_pop_async_readed;
  always @(*) begin
    io_pop_valid = logic_pop_addressGen_translated_valid;
    if(logic_ptr_empty) begin
      io_pop_valid = io_push_valid;
    end
  end

  assign logic_pop_addressGen_translated_ready = io_pop_ready;
  always @(*) begin
    io_pop_payload = logic_pop_addressGen_translated_payload;
    if(logic_ptr_empty) begin
      io_pop_payload = io_push_payload;
    end
  end

  assign logic_ptr_popOnIo = logic_ptr_pop;
  assign io_occupancy = logic_ptr_occupancy;
  assign io_availability = (2'b10 - logic_ptr_occupancy);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      logic_ptr_push <= 2'b00;
      logic_ptr_pop <= 2'b00;
      logic_ptr_wentUp <= 1'b0;
    end else begin
      if(when_Stream_l1455) begin
        logic_ptr_wentUp <= logic_ptr_doPush;
      end
      if(io_flush) begin
        logic_ptr_wentUp <= 1'b0;
      end
      if(logic_ptr_doPush) begin
        logic_ptr_push <= (logic_ptr_push + 2'b01);
      end
      if(logic_ptr_doPop) begin
        logic_ptr_pop <= (logic_ptr_pop + 2'b01);
      end
      if(io_flush) begin
        logic_ptr_push <= 2'b00;
        logic_ptr_pop <= 2'b00;
      end
    end
  end


endmodule

module StreamFifo_6 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [1:0]    io_push_payload,
  output reg           io_pop_valid,
  input  wire          io_pop_ready,
  output reg  [1:0]    io_pop_payload,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire       [1:0]    logic_ram_spinal_port1;
  wire       [1:0]    _zz_logic_ram_port;
  reg                 _zz_1;
  reg                 logic_ptr_doPush;
  wire                logic_ptr_doPop;
  wire                logic_ptr_full;
  wire                logic_ptr_empty;
  reg        [1:0]    logic_ptr_push;
  reg        [1:0]    logic_ptr_pop;
  wire       [1:0]    logic_ptr_occupancy;
  wire       [1:0]    logic_ptr_popOnIo;
  wire                when_Stream_l1455;
  reg                 logic_ptr_wentUp;
  wire                io_push_fire;
  wire                logic_push_onRam_write_valid;
  wire       [0:0]    logic_push_onRam_write_payload_address;
  wire       [1:0]    logic_push_onRam_write_payload_data;
  wire                logic_pop_addressGen_valid;
  wire                logic_pop_addressGen_ready;
  wire       [0:0]    logic_pop_addressGen_payload;
  wire                logic_pop_addressGen_fire;
  wire       [1:0]    logic_pop_async_readed;
  wire                logic_pop_addressGen_translated_valid;
  wire                logic_pop_addressGen_translated_ready;
  wire       [1:0]    logic_pop_addressGen_translated_payload;
  (* ram_style = "distributed" *) reg [1:0] logic_ram [0:1];

  assign _zz_logic_ram_port = logic_push_onRam_write_payload_data;
  always @(posedge clk) begin
    if(_zz_1) begin
      logic_ram[logic_push_onRam_write_payload_address] <= _zz_logic_ram_port;
    end
  end

  assign logic_ram_spinal_port1 = logic_ram[logic_pop_addressGen_payload];
  always @(*) begin
    _zz_1 = 1'b0;
    if(logic_push_onRam_write_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign when_Stream_l1455 = (logic_ptr_doPush != logic_ptr_doPop);
  assign logic_ptr_full = (((logic_ptr_push ^ logic_ptr_popOnIo) ^ 2'b10) == 2'b00);
  assign logic_ptr_empty = (logic_ptr_push == logic_ptr_pop);
  assign logic_ptr_occupancy = (logic_ptr_push - logic_ptr_popOnIo);
  assign io_push_ready = (! logic_ptr_full);
  assign io_push_fire = (io_push_valid && io_push_ready);
  always @(*) begin
    logic_ptr_doPush = io_push_fire;
    if(logic_ptr_empty) begin
      if(io_pop_ready) begin
        logic_ptr_doPush = 1'b0;
      end
    end
  end

  assign logic_push_onRam_write_valid = io_push_fire;
  assign logic_push_onRam_write_payload_address = logic_ptr_push[0:0];
  assign logic_push_onRam_write_payload_data = io_push_payload;
  assign logic_pop_addressGen_valid = (! logic_ptr_empty);
  assign logic_pop_addressGen_payload = logic_ptr_pop[0:0];
  assign logic_pop_addressGen_fire = (logic_pop_addressGen_valid && logic_pop_addressGen_ready);
  assign logic_ptr_doPop = logic_pop_addressGen_fire;
  assign logic_pop_async_readed = logic_ram_spinal_port1;
  assign logic_pop_addressGen_translated_valid = logic_pop_addressGen_valid;
  assign logic_pop_addressGen_ready = logic_pop_addressGen_translated_ready;
  assign logic_pop_addressGen_translated_payload = logic_pop_async_readed;
  always @(*) begin
    io_pop_valid = logic_pop_addressGen_translated_valid;
    if(logic_ptr_empty) begin
      io_pop_valid = io_push_valid;
    end
  end

  assign logic_pop_addressGen_translated_ready = io_pop_ready;
  always @(*) begin
    io_pop_payload = logic_pop_addressGen_translated_payload;
    if(logic_ptr_empty) begin
      io_pop_payload = io_push_payload;
    end
  end

  assign logic_ptr_popOnIo = logic_ptr_pop;
  assign io_occupancy = logic_ptr_occupancy;
  assign io_availability = (2'b10 - logic_ptr_occupancy);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      logic_ptr_push <= 2'b00;
      logic_ptr_pop <= 2'b00;
      logic_ptr_wentUp <= 1'b0;
    end else begin
      if(when_Stream_l1455) begin
        logic_ptr_wentUp <= logic_ptr_doPush;
      end
      if(io_flush) begin
        logic_ptr_wentUp <= 1'b0;
      end
      if(logic_ptr_doPush) begin
        logic_ptr_push <= (logic_ptr_push + 2'b01);
      end
      if(logic_ptr_doPop) begin
        logic_ptr_pop <= (logic_ptr_pop + 2'b01);
      end
      if(io_flush) begin
        logic_ptr_push <= 2'b00;
        logic_ptr_pop <= 2'b00;
      end
    end
  end


endmodule

module StreamFifo_5 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [2:0]    io_push_payload_inputId,
  input  wire [31:0]   io_push_payload_outputId,
  output reg           io_pop_valid,
  input  wire          io_pop_ready,
  output reg  [2:0]    io_pop_payload_inputId,
  output reg  [31:0]   io_pop_payload_outputId,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire       [34:0]   logic_ram_spinal_port1;
  wire       [34:0]   _zz_logic_ram_port;
  reg                 _zz_1;
  reg                 logic_ptr_doPush;
  wire                logic_ptr_doPop;
  wire                logic_ptr_full;
  wire                logic_ptr_empty;
  reg        [1:0]    logic_ptr_push;
  reg        [1:0]    logic_ptr_pop;
  wire       [1:0]    logic_ptr_occupancy;
  wire       [1:0]    logic_ptr_popOnIo;
  wire                when_Stream_l1455;
  reg                 logic_ptr_wentUp;
  wire                io_push_fire;
  wire                logic_push_onRam_write_valid;
  wire       [0:0]    logic_push_onRam_write_payload_address;
  wire       [2:0]    logic_push_onRam_write_payload_data_inputId;
  wire       [31:0]   logic_push_onRam_write_payload_data_outputId;
  wire                logic_pop_addressGen_valid;
  wire                logic_pop_addressGen_ready;
  wire       [0:0]    logic_pop_addressGen_payload;
  wire                logic_pop_addressGen_fire;
  wire       [2:0]    logic_pop_async_readed_inputId;
  wire       [31:0]   logic_pop_async_readed_outputId;
  wire       [34:0]   _zz_logic_pop_async_readed_inputId;
  wire                logic_pop_addressGen_translated_valid;
  wire                logic_pop_addressGen_translated_ready;
  wire       [2:0]    logic_pop_addressGen_translated_payload_inputId;
  wire       [31:0]   logic_pop_addressGen_translated_payload_outputId;
  (* ram_style = "distributed" *) reg [34:0] logic_ram [0:1];

  assign _zz_logic_ram_port = {logic_push_onRam_write_payload_data_outputId,logic_push_onRam_write_payload_data_inputId};
  always @(posedge clk) begin
    if(_zz_1) begin
      logic_ram[logic_push_onRam_write_payload_address] <= _zz_logic_ram_port;
    end
  end

  assign logic_ram_spinal_port1 = logic_ram[logic_pop_addressGen_payload];
  always @(*) begin
    _zz_1 = 1'b0;
    if(logic_push_onRam_write_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign when_Stream_l1455 = (logic_ptr_doPush != logic_ptr_doPop);
  assign logic_ptr_full = (((logic_ptr_push ^ logic_ptr_popOnIo) ^ 2'b10) == 2'b00);
  assign logic_ptr_empty = (logic_ptr_push == logic_ptr_pop);
  assign logic_ptr_occupancy = (logic_ptr_push - logic_ptr_popOnIo);
  assign io_push_ready = (! logic_ptr_full);
  assign io_push_fire = (io_push_valid && io_push_ready);
  always @(*) begin
    logic_ptr_doPush = io_push_fire;
    if(logic_ptr_empty) begin
      if(io_pop_ready) begin
        logic_ptr_doPush = 1'b0;
      end
    end
  end

  assign logic_push_onRam_write_valid = io_push_fire;
  assign logic_push_onRam_write_payload_address = logic_ptr_push[0:0];
  assign logic_push_onRam_write_payload_data_inputId = io_push_payload_inputId;
  assign logic_push_onRam_write_payload_data_outputId = io_push_payload_outputId;
  assign logic_pop_addressGen_valid = (! logic_ptr_empty);
  assign logic_pop_addressGen_payload = logic_ptr_pop[0:0];
  assign logic_pop_addressGen_fire = (logic_pop_addressGen_valid && logic_pop_addressGen_ready);
  assign logic_ptr_doPop = logic_pop_addressGen_fire;
  assign _zz_logic_pop_async_readed_inputId = logic_ram_spinal_port1;
  assign logic_pop_async_readed_inputId = _zz_logic_pop_async_readed_inputId[2 : 0];
  assign logic_pop_async_readed_outputId = _zz_logic_pop_async_readed_inputId[34 : 3];
  assign logic_pop_addressGen_translated_valid = logic_pop_addressGen_valid;
  assign logic_pop_addressGen_ready = logic_pop_addressGen_translated_ready;
  assign logic_pop_addressGen_translated_payload_inputId = logic_pop_async_readed_inputId;
  assign logic_pop_addressGen_translated_payload_outputId = logic_pop_async_readed_outputId;
  always @(*) begin
    io_pop_valid = logic_pop_addressGen_translated_valid;
    if(logic_ptr_empty) begin
      io_pop_valid = io_push_valid;
    end
  end

  assign logic_pop_addressGen_translated_ready = io_pop_ready;
  always @(*) begin
    io_pop_payload_inputId = logic_pop_addressGen_translated_payload_inputId;
    if(logic_ptr_empty) begin
      io_pop_payload_inputId = io_push_payload_inputId;
    end
  end

  always @(*) begin
    io_pop_payload_outputId = logic_pop_addressGen_translated_payload_outputId;
    if(logic_ptr_empty) begin
      io_pop_payload_outputId = io_push_payload_outputId;
    end
  end

  assign logic_ptr_popOnIo = logic_ptr_pop;
  assign io_occupancy = logic_ptr_occupancy;
  assign io_availability = (2'b10 - logic_ptr_occupancy);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      logic_ptr_push <= 2'b00;
      logic_ptr_pop <= 2'b00;
      logic_ptr_wentUp <= 1'b0;
    end else begin
      if(when_Stream_l1455) begin
        logic_ptr_wentUp <= logic_ptr_doPush;
      end
      if(io_flush) begin
        logic_ptr_wentUp <= 1'b0;
      end
      if(logic_ptr_doPush) begin
        logic_ptr_push <= (logic_ptr_push + 2'b01);
      end
      if(logic_ptr_doPop) begin
        logic_ptr_pop <= (logic_ptr_pop + 2'b01);
      end
      if(io_flush) begin
        logic_ptr_push <= 2'b00;
        logic_ptr_pop <= 2'b00;
      end
    end
  end


endmodule

module StreamFifo_4 (
  input  wire          io_push_valid,
  output wire          io_push_ready,
  input  wire [7:0]    io_push_payload_inputId,
  input  wire [31:0]   io_push_payload_outputId,
  output reg           io_pop_valid,
  input  wire          io_pop_ready,
  output reg  [7:0]    io_pop_payload_inputId,
  output reg  [31:0]   io_pop_payload_outputId,
  input  wire          io_flush,
  output wire [1:0]    io_occupancy,
  output wire [1:0]    io_availability,
  input  wire          clk,
  input  wire          reset
);

  wire       [39:0]   logic_ram_spinal_port1;
  wire       [39:0]   _zz_logic_ram_port;
  reg                 _zz_1;
  reg                 logic_ptr_doPush;
  wire                logic_ptr_doPop;
  wire                logic_ptr_full;
  wire                logic_ptr_empty;
  reg        [1:0]    logic_ptr_push;
  reg        [1:0]    logic_ptr_pop;
  wire       [1:0]    logic_ptr_occupancy;
  wire       [1:0]    logic_ptr_popOnIo;
  wire                when_Stream_l1455;
  reg                 logic_ptr_wentUp;
  wire                io_push_fire;
  wire                logic_push_onRam_write_valid;
  wire       [0:0]    logic_push_onRam_write_payload_address;
  wire       [7:0]    logic_push_onRam_write_payload_data_inputId;
  wire       [31:0]   logic_push_onRam_write_payload_data_outputId;
  wire                logic_pop_addressGen_valid;
  wire                logic_pop_addressGen_ready;
  wire       [0:0]    logic_pop_addressGen_payload;
  wire                logic_pop_addressGen_fire;
  wire       [7:0]    logic_pop_async_readed_inputId;
  wire       [31:0]   logic_pop_async_readed_outputId;
  wire       [39:0]   _zz_logic_pop_async_readed_inputId;
  wire                logic_pop_addressGen_translated_valid;
  wire                logic_pop_addressGen_translated_ready;
  wire       [7:0]    logic_pop_addressGen_translated_payload_inputId;
  wire       [31:0]   logic_pop_addressGen_translated_payload_outputId;
  (* ram_style = "distributed" *) reg [39:0] logic_ram [0:1];

  assign _zz_logic_ram_port = {logic_push_onRam_write_payload_data_outputId,logic_push_onRam_write_payload_data_inputId};
  always @(posedge clk) begin
    if(_zz_1) begin
      logic_ram[logic_push_onRam_write_payload_address] <= _zz_logic_ram_port;
    end
  end

  assign logic_ram_spinal_port1 = logic_ram[logic_pop_addressGen_payload];
  always @(*) begin
    _zz_1 = 1'b0;
    if(logic_push_onRam_write_valid) begin
      _zz_1 = 1'b1;
    end
  end

  assign when_Stream_l1455 = (logic_ptr_doPush != logic_ptr_doPop);
  assign logic_ptr_full = (((logic_ptr_push ^ logic_ptr_popOnIo) ^ 2'b10) == 2'b00);
  assign logic_ptr_empty = (logic_ptr_push == logic_ptr_pop);
  assign logic_ptr_occupancy = (logic_ptr_push - logic_ptr_popOnIo);
  assign io_push_ready = (! logic_ptr_full);
  assign io_push_fire = (io_push_valid && io_push_ready);
  always @(*) begin
    logic_ptr_doPush = io_push_fire;
    if(logic_ptr_empty) begin
      if(io_pop_ready) begin
        logic_ptr_doPush = 1'b0;
      end
    end
  end

  assign logic_push_onRam_write_valid = io_push_fire;
  assign logic_push_onRam_write_payload_address = logic_ptr_push[0:0];
  assign logic_push_onRam_write_payload_data_inputId = io_push_payload_inputId;
  assign logic_push_onRam_write_payload_data_outputId = io_push_payload_outputId;
  assign logic_pop_addressGen_valid = (! logic_ptr_empty);
  assign logic_pop_addressGen_payload = logic_ptr_pop[0:0];
  assign logic_pop_addressGen_fire = (logic_pop_addressGen_valid && logic_pop_addressGen_ready);
  assign logic_ptr_doPop = logic_pop_addressGen_fire;
  assign _zz_logic_pop_async_readed_inputId = logic_ram_spinal_port1;
  assign logic_pop_async_readed_inputId = _zz_logic_pop_async_readed_inputId[7 : 0];
  assign logic_pop_async_readed_outputId = _zz_logic_pop_async_readed_inputId[39 : 8];
  assign logic_pop_addressGen_translated_valid = logic_pop_addressGen_valid;
  assign logic_pop_addressGen_ready = logic_pop_addressGen_translated_ready;
  assign logic_pop_addressGen_translated_payload_inputId = logic_pop_async_readed_inputId;
  assign logic_pop_addressGen_translated_payload_outputId = logic_pop_async_readed_outputId;
  always @(*) begin
    io_pop_valid = logic_pop_addressGen_translated_valid;
    if(logic_ptr_empty) begin
      io_pop_valid = io_push_valid;
    end
  end

  assign logic_pop_addressGen_translated_ready = io_pop_ready;
  always @(*) begin
    io_pop_payload_inputId = logic_pop_addressGen_translated_payload_inputId;
    if(logic_ptr_empty) begin
      io_pop_payload_inputId = io_push_payload_inputId;
    end
  end

  always @(*) begin
    io_pop_payload_outputId = logic_pop_addressGen_translated_payload_outputId;
    if(logic_ptr_empty) begin
      io_pop_payload_outputId = io_push_payload_outputId;
    end
  end

  assign logic_ptr_popOnIo = logic_ptr_pop;
  assign io_occupancy = logic_ptr_occupancy;
  assign io_availability = (2'b10 - logic_ptr_occupancy);
  always @(posedge clk or posedge reset) begin
    if(reset) begin
      logic_ptr_push <= 2'b00;
      logic_ptr_pop <= 2'b00;
      logic_ptr_wentUp <= 1'b0;
    end else begin
      if(when_Stream_l1455) begin
        logic_ptr_wentUp <= logic_ptr_doPush;
      end
      if(io_flush) begin
        logic_ptr_wentUp <= 1'b0;
      end
      if(logic_ptr_doPush) begin
        logic_ptr_push <= (logic_ptr_push + 2'b01);
      end
      if(logic_ptr_doPop) begin
        logic_ptr_pop <= (logic_ptr_pop + 2'b01);
      end
      if(io_flush) begin
        logic_ptr_push <= 2'b00;
        logic_ptr_pop <= 2'b00;
      end
    end
  end


endmodule
